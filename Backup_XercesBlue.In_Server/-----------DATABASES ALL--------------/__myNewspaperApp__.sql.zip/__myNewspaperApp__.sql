-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: 166.62.8.12
-- Generation Time: Aug 22, 2015 at 03:13 AM
-- Server version: 5.5.43
-- PHP Version: 5.1.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `myNewspaperApp`
--
CREATE DATABASE `myNewspaperApp` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `myNewspaperApp`;

-- --------------------------------------------------------

--
-- Table structure for table `advt`
--

CREATE TABLE `advt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `image` text COLLATE utf8_unicode_ci NOT NULL,
  `weburl` text COLLATE utf8_unicode_ci NOT NULL,
  `datetime` datetime NOT NULL,
  `advttype` int(11) NOT NULL,
  `areacode` int(11) NOT NULL,
  `isactive` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `advt`
--

INSERT INTO `advt` VALUES(2, ' ', '14291882341429188652.jpg', 'http://xercesblue.in', '0000-00-00 00:00:00', 1, 0, 1);
INSERT INTO `advt` VALUES(3, ' ', '14291882571429188492.jpg', 'http://xercesblue.in', '0000-00-00 00:00:00', 2, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `advttypes`
--

CREATE TABLE `advttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typename` text COLLATE utf8_unicode_ci NOT NULL,
  `detail` text COLLATE utf8_unicode_ci NOT NULL,
  `eventname` text COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `currentadvtid` int(11) NOT NULL,
  `intervalvalue` int(11) NOT NULL,
  `intervalfield` text COLLATE utf8_unicode_ci NOT NULL,
  `clientid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `advttypes`
--

INSERT INTO `advttypes` VALUES(1, 'Frontpage main Advertisement', 'This advertisement consists of image and text and would be placed on front page. This is main advertisement of the website. Its dimensions are 250px x 520px.', 'frontpagemainadvt', 1, 1, 5, 'SECOND', 1);
INSERT INTO `advttypes` VALUES(2, 'Detailpage main Advertisement', 'This advertisement consists of image and text and would be placed on news detail page. Its dimensions are XxY.', 'detailpagemainadvt', 1, 0, 5, 'MINUTE', 1);

-- --------------------------------------------------------

--
-- Table structure for table `appconfig`
--

CREATE TABLE `appconfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `version` int(11) NOT NULL,
  `clientid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `appconfig`
--

INSERT INTO `appconfig` VALUES(1, 'newsimagespath', 'uploaded-images/', 1, 1);
INSERT INTO `appconfig` VALUES(2, 'categoryimagespath', 'category-uploaded-images/', 1, 1);
INSERT INTO `appconfig` VALUES(3, 'advtimagespath', 'advt-uploaded-images/', 1, 1);
INSERT INTO `appconfig` VALUES(4, 'epaperfilespath', 'epaper-uploaded-files/', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `area`
--

CREATE TABLE `area` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `areacode` int(11) DEFAULT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `areacode` (`areacode`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=101 ;

--
-- Dumping data for table `area`
--

INSERT INTO `area` VALUES(1, 25263, 'Anantapur', 1);
INSERT INTO `area` VALUES(2, 85748, 'Chittoor', 1);
INSERT INTO `area` VALUES(3, NULL, 'East Godavari', 1);
INSERT INTO `area` VALUES(4, NULL, 'Guntur', 1);
INSERT INTO `area` VALUES(5, NULL, 'Kadapa', 1);
INSERT INTO `area` VALUES(6, NULL, 'Krishna', 1);
INSERT INTO `area` VALUES(7, NULL, 'Kurnool', 1);
INSERT INTO `area` VALUES(8, NULL, 'Prakasam', 1);
INSERT INTO `area` VALUES(9, NULL, 'Nellore', 1);
INSERT INTO `area` VALUES(10, NULL, 'Srikakulam', 1);
INSERT INTO `area` VALUES(11, NULL, 'Visakhapatnam', 1);
INSERT INTO `area` VALUES(12, NULL, 'Vizianagaram', 1);
INSERT INTO `area` VALUES(13, NULL, 'West Godavari', 1);
INSERT INTO `area` VALUES(14, NULL, 'Anjaw', 2);
INSERT INTO `area` VALUES(15, NULL, 'Changlang', 2);
INSERT INTO `area` VALUES(16, NULL, 'East Kameng', 2);
INSERT INTO `area` VALUES(17, NULL, 'East Siang', 2);
INSERT INTO `area` VALUES(18, NULL, 'Lohit', 2);
INSERT INTO `area` VALUES(19, NULL, 'Longding', 2);
INSERT INTO `area` VALUES(20, NULL, 'Lower Subansiri', 2);
INSERT INTO `area` VALUES(21, NULL, 'Papum Pare', 2);
INSERT INTO `area` VALUES(22, NULL, 'Tawang', 2);
INSERT INTO `area` VALUES(23, NULL, 'Tirap', 2);
INSERT INTO `area` VALUES(24, NULL, 'Lower Dibang Valley', 2);
INSERT INTO `area` VALUES(25, NULL, 'Upper Siang', 2);
INSERT INTO `area` VALUES(26, NULL, 'Upper Subansiri', 2);
INSERT INTO `area` VALUES(27, NULL, 'West Kameng', 2);
INSERT INTO `area` VALUES(28, NULL, 'West Siang', 2);
INSERT INTO `area` VALUES(29, NULL, 'Upper Dibang Valley', 2);
INSERT INTO `area` VALUES(30, NULL, 'Kurung Kumey', 2);
INSERT INTO `area` VALUES(31, NULL, 'Barpeta', 3);
INSERT INTO `area` VALUES(32, NULL, 'Bongaigaon', 3);
INSERT INTO `area` VALUES(33, NULL, 'Cachar', 3);
INSERT INTO `area` VALUES(34, NULL, 'Darrang', 3);
INSERT INTO `area` VALUES(35, NULL, 'Dhemaji', 3);
INSERT INTO `area` VALUES(36, NULL, 'Dhubri', 3);
INSERT INTO `area` VALUES(37, NULL, 'Dibrugarh', 3);
INSERT INTO `area` VALUES(38, NULL, 'Goalpara', 3);
INSERT INTO `area` VALUES(39, NULL, 'Golaghat', 3);
INSERT INTO `area` VALUES(40, NULL, 'Hailakandi', 3);
INSERT INTO `area` VALUES(41, NULL, 'Jorhat', 3);
INSERT INTO `area` VALUES(42, NULL, 'Karbi Anglong', 3);
INSERT INTO `area` VALUES(43, NULL, 'Karimganj', 3);
INSERT INTO `area` VALUES(44, NULL, 'Kokrajhar', 3);
INSERT INTO `area` VALUES(45, NULL, 'Lakhimpur', 3);
INSERT INTO `area` VALUES(46, NULL, 'Morigaon', 3);
INSERT INTO `area` VALUES(47, NULL, 'Nagaon', 3);
INSERT INTO `area` VALUES(48, NULL, 'Nalbari', 3);
INSERT INTO `area` VALUES(49, NULL, 'Dima Hasao', 3);
INSERT INTO `area` VALUES(50, NULL, 'Sivasagar', 3);
INSERT INTO `area` VALUES(51, NULL, 'Sonitpur', 3);
INSERT INTO `area` VALUES(52, NULL, 'Tinsukia', 3);
INSERT INTO `area` VALUES(53, NULL, 'Kamrup', 3);
INSERT INTO `area` VALUES(54, NULL, 'Kamrup Metropolitan', 3);
INSERT INTO `area` VALUES(55, NULL, 'Baksa', 3);
INSERT INTO `area` VALUES(56, NULL, 'Udalguri', 3);
INSERT INTO `area` VALUES(57, NULL, 'Chirang', 3);
INSERT INTO `area` VALUES(58, NULL, 'Araria', 4);
INSERT INTO `area` VALUES(59, NULL, 'Arwal', 4);
INSERT INTO `area` VALUES(60, NULL, 'Aurangabad', 4);
INSERT INTO `area` VALUES(61, NULL, 'Banka', 4);
INSERT INTO `area` VALUES(62, NULL, 'Begusarai', 4);
INSERT INTO `area` VALUES(63, NULL, 'Bhagalpur', 4);
INSERT INTO `area` VALUES(64, NULL, 'Bhojpur', 4);
INSERT INTO `area` VALUES(65, NULL, 'Buxar', 4);
INSERT INTO `area` VALUES(66, NULL, 'Darbhanga', 4);
INSERT INTO `area` VALUES(67, NULL, 'East Champaran', 4);
INSERT INTO `area` VALUES(68, NULL, 'Gaya', 4);
INSERT INTO `area` VALUES(69, NULL, 'Gopalganj', 4);
INSERT INTO `area` VALUES(70, NULL, 'Jamui', 4);
INSERT INTO `area` VALUES(71, NULL, 'Jehanabad', 4);
INSERT INTO `area` VALUES(72, NULL, 'Khagaria', 4);
INSERT INTO `area` VALUES(73, NULL, 'Kishanganj', 4);
INSERT INTO `area` VALUES(74, NULL, 'Kaimur', 4);
INSERT INTO `area` VALUES(75, NULL, 'Katihar', 4);
INSERT INTO `area` VALUES(76, NULL, 'Lakhisarai', 4);
INSERT INTO `area` VALUES(77, NULL, 'Madhubani', 4);
INSERT INTO `area` VALUES(78, NULL, 'Munger', 4);
INSERT INTO `area` VALUES(79, NULL, 'Madhepura', 4);
INSERT INTO `area` VALUES(80, NULL, 'Muzaffarpur', 4);
INSERT INTO `area` VALUES(81, NULL, 'Nalanda', 4);
INSERT INTO `area` VALUES(82, NULL, 'Nawada', 4);
INSERT INTO `area` VALUES(83, NULL, 'Patna', 4);
INSERT INTO `area` VALUES(84, NULL, 'Purnia', 4);
INSERT INTO `area` VALUES(85, NULL, 'Rohtas', 4);
INSERT INTO `area` VALUES(86, NULL, 'Saharsa', 4);
INSERT INTO `area` VALUES(87, NULL, 'Samastipur', 4);
INSERT INTO `area` VALUES(88, NULL, 'Sheohar', 4);
INSERT INTO `area` VALUES(89, NULL, 'Sheikhpura', 4);
INSERT INTO `area` VALUES(90, NULL, 'Saran', 4);
INSERT INTO `area` VALUES(91, NULL, 'Sitamarhi', 4);
INSERT INTO `area` VALUES(92, NULL, 'Supaul', 4);
INSERT INTO `area` VALUES(93, NULL, 'Siwan', 4);
INSERT INTO `area` VALUES(94, NULL, 'Vaishali', 4);
INSERT INTO `area` VALUES(95, NULL, 'West Champaran', 4);
INSERT INTO `area` VALUES(96, NULL, 'Balod', 5);
INSERT INTO `area` VALUES(97, NULL, 'Baloda Bazar', 5);
INSERT INTO `area` VALUES(98, NULL, 'Balrampur', 5);
INSERT INTO `area` VALUES(99, NULL, 'Bastar', 5);
INSERT INTO `area` VALUES(100, NULL, 'Bemetara', 5);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `image` text COLLATE utf8_unicode_ci NOT NULL,
  `parentid` int(11) NOT NULL,
  `clientid` int(11) NOT NULL,
  `menu` tinyint(1) NOT NULL DEFAULT '0',
  `isactive` tinyint(1) NOT NULL DEFAULT '0',
  `isroot` int(11) NOT NULL DEFAULT '0',
  `topnewsid` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` VALUES(1, 'TOP NEWS', '', 0, 1, 0, 1, 1, 119);
INSERT INTO `category` VALUES(2, 'Sports', '1426783098ic_launcher-web.png', 0, 1, 0, 0, 0, 0);
INSERT INTO `category` VALUES(3, 'SPORTS', '', 0, 1, 0, 0, 0, 121);
INSERT INTO `category` VALUES(4, 'CRICKET', 'undefined', 3, 1, 0, 0, 0, 53);
INSERT INTO `category` VALUES(5, 'HOCKEY', 'undefined', 3, 1, 0, 0, 0, 0);
INSERT INTO `category` VALUES(6, 'FOOTBALL', 'undefined', 3, 1, 0, 0, 0, 0);
INSERT INTO `category` VALUES(7, 'SRI GANGANAGAR', '', 0, 1, 0, 1, 0, 124);
INSERT INTO `category` VALUES(8, 'INDIA', '', 0, 1, 0, 1, 0, 56);
INSERT INTO `category` VALUES(9, 'तेस्त रज्निति', '1427538644xRay.png', 7, 1, 0, 0, 0, 0);
INSERT INTO `category` VALUES(10, 'स्फ्द्', '', 1, 1, 0, 0, 0, 0);
INSERT INTO `category` VALUES(11, 'RAJASTHAN', '', 0, 1, 0, 1, 0, 127);
INSERT INTO `category` VALUES(12, 'EDITORIAL', '', 0, 1, 0, 1, 0, 0);
INSERT INTO `category` VALUES(13, 'WEEKLY', '', 0, 1, 0, 1, 0, 0);
INSERT INTO `category` VALUES(14, 'थर्स-डे टॉक', '', 13, 1, 0, 1, 0, 0);
INSERT INTO `category` VALUES(15, 'विधानसभा चुनाव-इतिहास के झरोखे से', '', 13, 1, 0, 1, 0, 131);
INSERT INTO `category` VALUES(16, 'बीच-बाजार', '', 13, 1, 0, 0, 0, 0);
INSERT INTO `category` VALUES(17, 'हेत री हताई', '', 13, 1, 0, 0, 0, 0);
INSERT INTO `category` VALUES(18, 'हेत री हताई', '', 13, 1, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `ip_address` varchar(45) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `user_agent` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` VALUES('0b07411a8f093d08a88a0da11c1d8c39', '66.249.79.82', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', 1439334629, '');
INSERT INTO `ci_sessions` VALUES('2139b028cf2a6c2b27a4d2ad26134235', '66.249.79.82', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', 1438885550, '');
INSERT INTO `ci_sessions` VALUES('21ba9677ede543dd7e0b7f2fbd2e1f8a', '66.249.79.82', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', 1438885551, '');
INSERT INTO `ci_sessions` VALUES('239b3bb8117bef965508d7e8626e71d5', '66.249.79.97', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', 1438802509, '');
INSERT INTO `ci_sessions` VALUES('25128517031aa7379282bdd9ecf38364', '66.249.79.110', 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e', 1438966634, '');
INSERT INTO `ci_sessions` VALUES('3a8999a22015036340ae1b82fafa512c', '182.19.13.234', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.130 Safari/537.36', 1439459021, '');
INSERT INTO `ci_sessions` VALUES('3baaa8094deb994bab30881e9bb69415', '66.249.79.95', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', 1439309654, '');
INSERT INTO `ci_sessions` VALUES('52b04bdf13ec2e77fa1f129930f3ee03', '66.249.79.82', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', 1438880906, '');
INSERT INTO `ci_sessions` VALUES('56c78d36c3144dc73111bc63c5dc1f69', '64.246.165.190', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en; rv:1.9.0.13) Gecko/2009073022 Firefox/3.5.2 (.NET CLR 3.5.30729) SurveyBot/', 1439244030, '');
INSERT INTO `ci_sessions` VALUES('835d32e6b3d5f4b682717f9f2c4462e4', '66.249.79.108', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', 1439203783, '');
INSERT INTO `ci_sessions` VALUES('862e86ad9e4d088fac6b7948ef25a004', '66.249.79.82', 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e', 1438875832, '');
INSERT INTO `ci_sessions` VALUES('8a0a609684a84668cecf7f32b430609d', '66.249.79.108', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', 1438885549, '');
INSERT INTO `ci_sessions` VALUES('8bbbf163b092e66d63f4b54bf3321218', '66.249.79.95', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', 1438877518, '');
INSERT INTO `ci_sessions` VALUES('901890a9506f4d52a842b182a6ef0551', '66.249.79.97', 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e', 1439303429, '');
INSERT INTO `ci_sessions` VALUES('903ddd6d947e872952e1f59d0b3c579b', '66.249.79.108', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', 1439334623, '');
INSERT INTO `ci_sessions` VALUES('9e37ce50d1ad1020cba27c3d8a4e389a', '66.249.79.95', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', 1438880905, '');
INSERT INTO `ci_sessions` VALUES('bbdf0a2d6482ad88feed0ee0cb358677', '66.249.79.97', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', 1439126922, '');
INSERT INTO `ci_sessions` VALUES('c2a441ed91d09202e0d6981571003250', '66.249.79.108', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', 1438880900, '');
INSERT INTO `ci_sessions` VALUES('d07e5edf1278f31a9e6be3a2eba99d27', '182.19.13.234', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36', 1439458971, '');
INSERT INTO `ci_sessions` VALUES('db2c2f2b7f280d3ee40ec2c9aacc76f8', '66.249.79.84', 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e', 1438932337, '');
INSERT INTO `ci_sessions` VALUES('e99a9b3c7b7ac01cd49381c04bf745bd', '66.249.79.108', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', 1439307933, '');
INSERT INTO `ci_sessions` VALUES('f0ab5e303b50adfc7a8c497fd03be2c9', '66.249.79.82', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', 1439334628, '');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `companyname` text COLLATE utf8_unicode_ci NOT NULL,
  `contactperson` text COLLATE utf8_unicode_ci NOT NULL,
  `foldername` text COLLATE utf8_unicode_ci NOT NULL,
  `rootpath` text COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci NOT NULL,
  `contact` text COLLATE utf8_unicode_ci NOT NULL,
  `dealdate` datetime NOT NULL,
  `domainname` text COLLATE utf8_unicode_ci NOT NULL,
  `dealprice` text COLLATE utf8_unicode_ci NOT NULL,
  `maintenanceprice` text COLLATE utf8_unicode_ci NOT NULL,
  `freemaintenancetime` datetime NOT NULL,
  `deliverydate` datetime NOT NULL,
  `isactive` int(11) NOT NULL DEFAULT '0',
  `contractimage` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `client`
--

INSERT INTO `client` VALUES(1, 'localhostDummy', 'dummy', 'newspaper1/', 'newsci/', 'dummy', '22222222222', '2015-02-25 00:00:00', 'http://newstest2.tk', '80000', '2000', '0000-00-00 00:00:00', '2015-03-16 00:00:00', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `client_settings`
--

CREATE TABLE `client_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `category_version` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `client_settings`
--

INSERT INTO `client_settings` VALUES(1, 1, 51);

-- --------------------------------------------------------

--
-- Table structure for table `clientareamapping`
--

CREATE TABLE `clientareamapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL,
  `areacodeid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `clientareamapping`
--

INSERT INTO `clientareamapping` VALUES(1, 1, 1);
INSERT INTO `clientareamapping` VALUES(2, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `epaper`
--

CREATE TABLE `epaper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `publishdate` date NOT NULL,
  `areacodeid` int(11) NOT NULL,
  `clientid` int(11) NOT NULL,
  `filename` text COLLATE utf8_unicode_ci NOT NULL,
  `previewimage` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=48 ;

--
-- Dumping data for table `epaper`
--

INSERT INTO `epaper` VALUES(27, '0000-00-00', 0, 0, '', '');
INSERT INTO `epaper` VALUES(44, '2015-04-07', 1, 1, '14284095211428409833.pdf', '14284096821428410293prev.jpg');
INSERT INTO `epaper` VALUES(45, '2015-04-07', 2, 1, '14284105001428410771.pdf', '14284105781428411374prev.jpg');
INSERT INTO `epaper` VALUES(46, '2015-04-21', 1, 1, '14286670241428667231.pdf', '14286670341428667904prev.jpg');
INSERT INTO `epaper` VALUES(47, '2015-04-20', 2, 1, '14286725711428672710.pdf', '14286727431428673387prev.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `gcm_user`
--

CREATE TABLE `gcm_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gcm_id` text COLLATE utf8_unicode_ci NOT NULL,
  `device_id` text COLLATE utf8_unicode_ci NOT NULL,
  `app_version` text COLLATE utf8_unicode_ci NOT NULL,
  `client_id` int(11) NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `contact` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=27 ;

--
-- Dumping data for table `gcm_user`
--

INSERT INTO `gcm_user` VALUES(26, 'APA91bG0oCD8mUcjsi3CAReZKP66Ko7W1o40RF23tFVPalc4D49_paslJ70o0Y6OW7wyMVse9S3EGd1iqf1Zt3wAtlWFG7rEqU4FQnVvve-vFxUMPy_onQpuq2BzFtO6JHhJJ9aElsYXxP76U-FUCyO-nyBa0UHDzA', '911424850538018', '1', 2, '', '');
INSERT INTO `gcm_user` VALUES(25, 'APA91bE7804mpdB26ulegaJ8p-_HeKPk9UNrfA_6KgqEO_4R9FRwP6uZOzavPz1cgfr7QNzYv1ghhDGhq9qS04bUFm7eB6MgwAvx2DiZ8XJC_YJoGUhWOzXauqloKDV_cHj2IJ-Jsur62F0Ahui9IChPDedV_rtwuw', '356554063623892', '1', 2, '', '');
INSERT INTO `gcm_user` VALUES(24, 'APA91bFUIIyByRTW7mL3crtP2Ayhy4QEn752wT2ZuF-Nk3TBtrLtzzjDftIa7YXjAsL2y3fZ2H3YXoSkkEOCsnhjk4yCZzOaWe0hNG8vLaU4AxRP3QtJUQZIgsm5FuZKCraSeGOYqyzG4vwVFsQlvOvy41N4wZzSGQ', '356554063623892', '1', 1, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `joke`
--

CREATE TABLE `joke` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `text` text COLLATE utf8_unicode_ci,
  `image` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `joke`
--

INSERT INTO `joke` VALUES(1, 1, 'दिस इस टेस्ट ', '14289289291428929172.jpg');
INSERT INTO `joke` VALUES(2, 1, '', '14289906321428991083.png');
INSERT INTO `joke` VALUES(3, 1, '', '14289910791428991384.jpg');
INSERT INTO `joke` VALUES(4, 1, '', '14289911171428991504.jpg');
INSERT INTO `joke` VALUES(5, 1, '', '14289912621428991604.jpg');
INSERT INTO `joke` VALUES(6, 1, '', '14289915551428991712.png');
INSERT INTO `joke` VALUES(7, 1, '', '14289945011428994625.png');
INSERT INTO `joke` VALUES(8, 1, '', '14289947231428995131.png');
INSERT INTO `joke` VALUES(9, 1, '', '14289951991428995454.png');
INSERT INTO `joke` VALUES(10, 1, '', '14289954941428995893.png');
INSERT INTO `joke` VALUES(11, 1, '', '14289955661428995861.png');
INSERT INTO `joke` VALUES(12, 1, '', '14289955761428995925.png');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `heading` text COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `image` text COLLATE utf8_unicode_ci NOT NULL,
  `video` text COLLATE utf8_unicode_ci NOT NULL,
  `imgtagline` text COLLATE utf8_unicode_ci NOT NULL,
  `parentnewsid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=134 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` VALUES(1, 'This is top news ONE', 'This is content for top news', '1426768927KHEL-JAGAT.png', '', 'tag ', 0);
INSERT INTO `news` VALUES(2, 'This is top news ONE', '', '1426768941CRICKET.png', '', 'cricket', 1);
INSERT INTO `news` VALUES(3, 'News Heading from Reporter change', 'This is news content of reporter', '1426785418jango.png', '', 'jango', 0);
INSERT INTO `news` VALUES(4, 'News Heading from Reporter', '', '1426785431cool-HD-wallpapers-04.jpg', '', 'hi', 3);
INSERT INTO `news` VALUES(5, 'this is loading test', 'loading test', '1426858474HISTORY.png', '', 'history', 0);
INSERT INTO `news` VALUES(6, 'णेव्स विथ गूद इमगे', 'अफ्स्द्फ्स्द्फ स्द्फ्स्द्फ्', '1426876183shiva2.jpg', '', 'शिव', 0);
INSERT INTO `news` VALUES(7, 'णेव्स विथ गूद इमगे', '', '1426876210lord-shiva-41v.jpg', '', '', 6);
INSERT INTO `news` VALUES(8, 'णेव्स विथ गूद इमगे', '', '0', '', '', 6);
INSERT INTO `news` VALUES(9, 'णेव्स विथ गूद इमगे', '', '1426876236Lord-Shiva-5.jpg', '', '', 6);
INSERT INTO `news` VALUES(24, 'णेव्स तेस्त ८', 'हिओ थेरे', '1427001826Billboard.png', '', '', 0);
INSERT INTO `news` VALUES(26, 'श्पोर्त्स तोप नेव्स्', 'ज़्क्ष्च्ज़्क्ष्च्व्ज़्व्', '1427014526jango.png', '', '', 0);
INSERT INTO `news` VALUES(27, 'this is test', 'this is test content', '1427035797Penguins.jpg', '', '', 0);
INSERT INTO `news` VALUES(28, 'ठिस इस नेव टोप नेव्स ओफ षिव', 'अस्द द्फ्द्फ्स्द द्फ्स्द्फ्स स्द्फेरे व्रेर्तेर्ग्वेव स्द फ्स्गेत ', '1427045218shiva1.jpg', '', '', 0);
INSERT INTO `news` VALUES(38, 'मोदी का ''दूत'' बन गए जफर सुरेशवाला को मुस्लिम लॉ बोर्ड ने बैठक से निकाला', 'जयपुर/नई दिल्ली. प्रधानमंत्री नरेंद्र मोदी के बड़े समर्थक माने जाने वाले बिजनेसमैन जफर सुरेशवाला को ऑल इंडिया मुस्लिम पर्सनल लॉ बोर्ड की बैठक से निकाल दिया गया। राजस्थान के जयपुर में रविवार को हुई ऑल इंडिया मुस्लिम पर्सनल लॉ बोर्ड बैठक में सुरेशवाला मुस्लिम नेताओं से मुलाकात करने गए थे और उन्होंने खुद को ''पीएम के दूत'' रूप में पेश किया था। हालांकि, अहमदाबाद के बिजनेसमैन ने इस बात से इनकार किया कि वह बैठक में पीएम के दूत के रूप में गए थे।\nएक अंग्रेजी अखबार में छपी खबर के मुताबिक, पीएम मोदी से नजदीकी के चलते सुरेशवाला से मुस्लिम नेता नाराज हैं। रविवार को जैसे ही सुरेशवाला वहां पहुंचे, बोर्ड के सदस्यों ने उनके खिलाफ नारेबाजी शुरू कर दी। गुस्साए सदस्यों ने सुरेशवाला से बैठक से निकल जाने को कह दिया। बोर्ड के सचिव मौलाना अब्दुल रहीम कुरैशी ने कहा, ''''सुरेशवाला पर्सनल लॉ बोर्ड के सदस्य नहीं हैं। वह एक घुसपैठिए थे। जैसे ही वह परिसर में दाखिल हुए, उनका जोरदार विरोध शुरू हो गया। बोर्ड के सदस्य सुरेशवाला को हैदराबाद की आजाद राष्ट्रीय ऊर्दू यूनिवर्सिटी का चांसलर बनाने से हैरान हैं।'''' सदस्यों के दावे के मुताबिक, सुरेशवाला दो महीने से बोर्ड के संपर्क में हैं। वो बोर्ड और पीएम मोदी की मुलाकात कराना चाहते हैं, लेकिन बोर्ड ने मना कर दिया।', '1427105246modi-sureshwala_142708687.jpg', '', 'जयपुर में हुई ऑल इंडिया मुस्लिम पर्सनल लॉ बोर्ड की बैठक से मोदी समर्थक को निकाला', 0);
INSERT INTO `news` VALUES(39, 'मोदी का ''दूत'' बन गए जफर सुरेशवाला को मुस्लिम लॉ बोर्ड ने बैठक से निकाला', '', '1427105343images.jpg', '', 'हमारे मोदी', 38);
INSERT INTO `news` VALUES(40, 'Sangakara retires from cricket', 'Sri Lankan Cricketer retires', '1427106867download.jpg', '', '', 0);
INSERT INTO `news` VALUES(41, 'फाइनल की दौड़ : क्या इन ''सुपर 5'' का सामना कर पाएगी साउथ अफ्रीका?', 'खेल डेस्क. न्यूजीलैंड और साउथ अफ्रीका के बीच मंगलवार को वर्ल्ड कप का पहला सेमीफाइनल मुकाबला खेला जाना है। टूर्नामेंट में अब तक अपने सभी मुकाबले जीतने वाली न्यूजीलैंड का पलड़ा भारी दिख रहा है। न्यूजीलैंड के ''सुपर 5'' जबरदस्त फॉर्म में हैं', '1427106984guptillmain_1427103288.jpg', '', '', 0);
INSERT INTO `news` VALUES(45, 'बिहार में नकल पर लालू बोले- मेरा राज होता तो परीक्षा में किताब दे देता', 'बक्सर. मैट्रिक परीक्षा में खुलेआम हो रही नकल को लेकर बिहार की पूरे देश में भद्द पिट रही है। हाईकोर्ट ने भी इसे गंभीरता से लेते हुए स्वत: संज्ञान लेते हुए नकल रोकने के इंतजाम करने के निर्देश दिए। चारों ओर से हुई आलोचना के बाद राज्य सरकार भी नकल रोकने के लिए सक्रिय हुई। लेकिन इस सबके बावजूद आरजेडी सुप्रीमो लालू प्रसाद ने अजीब बयान दिया है। उन्होंने\nकहा, "हमारा राज रहता तो हम परीक्षा में किताब दे देते। जो पढ़ा रहेगा, वही न लिखेगा। मेरे राज में पांचवीं और आठवीं में भी बोर्ड परीक्षा ली जाती थी। हम तो सब को परीक्षा में पूरी अजादी दे दिए थे। नकल के लिए छात्रों की पूरी किताब ही दे देते थे। लेकिन अब तो सब कुछ बदल गया है। बिहार की शिक्षा कैसी हो गई है, यह सभी देख रहे हैं। लोग तीन तल्ला पर चढ़कर नकल करवा रहे हैं।"', '1427107715cheeting_1427103602.jpg', '', '', 0);
INSERT INTO `news` VALUES(46, 'बिहार में नकल पर लालू बोले- मेरा राज होता तो परीक्षा में किताब दे देता', '', '1427107719nakal4_1427103621.jpg', '', '', 45);
INSERT INTO `news` VALUES(47, 'ANALYSIS: ...तो इसलिए इस बार भी है भारत के वर्ल्‍ड कप जीतने की उम्‍मीद', 'रिसर्च डेस्क. सात में से सात मैच जीतकर टीम इंडिया क्रिकेट वर्ल्ड कप के सेमीफाइनल में है। टीम का परफॉर्मेंस 2011 जैसा ही है। तब टीम सचिन, सहवाग और गंभीर जैसे बैट्समैन और युवराज सिंह के ऑलराउंड परफॉर्मेंस के बूते जीती थी। इस बार टीम की लगातार जीत में बैट्समैन के साथ ही बॉलर्स का योगदान ज्यादा नजर आ रहा है। टीम एक यूनिट की तरह खेल रही है।\nपिछले वर्ल्ड कप में इंडिया के टॉप-6 बैट्समैन ने 9 मैचों में 2140 रन बनाए थे। इस बार 7 मैचों में टॉप बैट्समैन ने 1580 रन बनाए हैं। तब बॉलर्स ने 9 मैचों में 60 विकेट लिए थे। जबकि इस बार 7 मैचों में 63 विकेट लिए हैं। बाकी 7 विकेट रन आउट के जरिए मिले हैं। सचिन की कमी शिखर धवन पूरी करते दिख रहे हैं। वहीं, सुरेश रैना अपने बल्ले से और रवींद्र जडेजा गेंद से युवराज सिंह की कमी पूरी करते नजर आ रहे हैं। जानिए क्या कहते हैं आंकड़े', '1427108919team-india-2011-and-2015_.jpg', '', 'टीम का परफॉर्मेंस 2011 जैसा ही है', 0);
INSERT INTO `news` VALUES(48, 'ANALYSIS: ...तो इसलिए इस बार भी है भारत के वर्ल्‍ड कप जीतने की उम्‍मीद', '', '1427109040team-india-2011-and-2015-.jpg', '', 'सचिन की कमी पूरी करते दिख रहे हैं धवन', 47);
INSERT INTO `news` VALUES(49, 'पाकिस्‍तान की अलगाववादियों से बात पर भड़की शिवसेना, सरकार ने दी सफाई', 'नई दिल्ली. नेशनल डे के मौके पर पाकिस्‍तान की ओर से अलगाववादी नेताओं को बुलाए जाने को लेकर भारत सरकार ने बयान जारी किया है। विदेश मंत्रालय ने सोमवार को साफ किया कि दोनों देशों के बीच शिमला और लाहौर समझौते के तहत ही वार्ता होगी। हुर्रियत कॉन्‍फ्रेंस को लेकर भारत के रुख पर कोई असमंजस नहीं होना चाहिए। उनके नेताओं से पाकिस्‍तान मिलता है तो मिलता रहे, वे भारत सरकार के प्रतिनिधि नहीं हो सकते। पाकिस्‍तान ने अलगाववादियों से मुलाकात को सामान्‍य बात बताया, तो शिवसेना ने इसे भारत के लिए चिंता का विषय बताया। शिवसेना ने कहा कि भारत सरकार को इस पर ध्यान देना चाहिए और एक्शन लेना चाहिए। शिवसेना ने इसे लेकर विरोध-प्रदर्शन भी किया।\nमोदी ने दी बधाई\nसोमवार को पड़ोसी मुल्क पाकिस्तान के नेशनल डे पर प्रधानमंत्री नरेंद्र मोदी ने पाकिस्तान के पीएम नवाज शरीफ को बधाई दी। पीएम ने ट्वीट कर इसकी जानकारी दी। मोदी ने बधाई के साथ ही शरीफ को आतंकवाद और हिंसा को लेकर नसीहत भी दी।', '1427109408pm-modi-with-sharif_142711.jpg', '', 'पाक और अलगाववादी नेताओं की मुलाकात का विरोध करते शिवसेना के कार्यकर्ता।', 0);
INSERT INTO `news` VALUES(50, 'पाकिस्‍तान की अलगाववादियों से बात पर भड़की शिवसेना, सरकार ने दी सफाई', 'पीएम मोदी ने अपने बधाई संदेश में लिखा, ''''मुझे उम्मीद है कि दोनों देशों के बीच लंबित मामलों और विवादों को हिंसा और आतंकवाद से मुक्त माहौल में द्विपक्षीय वार्ता के जरिए सुलझा लिया जाएगा।'''' पीएम मोदी का जोर इस बात पर ज्यादा है कि जब तक सीमा पार से आतंकवाद नहीं बंद होता तब तक दोनों देशों के बीच बेहतर आपसी बातचीत का मौहाल नहीं बन पाएगा।\nबता दें कि पिछले दिनों जम्मू-कश्मीर के सांबा और कठुआ में आतंकी हमले के बाद विपक्षी दलों ने मोदी सरकार पर सवाल उठाया था कि एक ओर केंद्र सरकार पड़ोसी देश से वार्ता करना चाह रही है तो दूसरी ओर पाकिस्तान लगातार आतंकवाद को समर्थन दे रहा है। इसके कारण कश्मीर में हमले की घटनाएं हो रही हैं। जम्मू-कश्मीर में आतंकवादी हमले की घटना के बाद गृह मंत्री राजनाथ सिंह ने भी स्पष्ट कहा था कि हर बार पाकिस्तान की ओर दोस्ती का हाथ बढ़ाने पर दगाबाजी ही मिली है। बीते दिनों पाकिस्तान यात्रा पर गए विदेश सचिव एस. जयशंकर ने भी दोनों देशों के बीच बेहतर रिश्तों के लिए द्वि‍पक्षीय बातचीत को ही अहम बताया था।', '1427109417pm-modi-tweet_1427103602.jpg', '', 'पाक नेशनल डे पर पीएम मोदी का ट्वीट।', 49);
INSERT INTO `news` VALUES(51, 'शहीद भगत सिंह के जूते, घड़ी और शर्ट आज भी हैं सुरक्षित', 'नई दिल्ली. शहीद भगत सिंह ने देश के लिए आज ही के दिन 1931 में अपना बलिदान दिया था। उनकी कुछ चीजें आज भी सुरक्षित रखी गई हैं, जिब्ब्', '1427109560bhagat-singh-cover-update.jpg', '', 'भगत सिंह द्वारा लिखा खत, 1929 में खींची गई भगत सिंह और सुखदेव की तस्वीर', 0);
INSERT INTO `news` VALUES(52, 'शहीद भगत सिंह के जूते, घड़ी और शर्ट आज भी हैं सुरक्षित है', '', '1427109583bhagat-singh001_142708951.jpg', '', 'फोटोः (ऊपर से नीचे) भगत सिंह के जूते, बम का खोल, उनकी शर्ट और घड़ी।', 51);
INSERT INTO `news` VALUES(53, 'LIVE NZ vs SA: कीवी टीम को तीसरा झटका, विलियम्सन के बाद गुप्टिल आउट', 'वर्ल्ड कप-2015 के पहले सेमीफाइनल मुकाबले में साउथ अफ्रीका द्वारा दिए गए 298 रनों के टारगेट का पीछा करते हुए न्यूजीलैंड ने तीन विकेट के नुकसान पर 133 रन बना लिए हैं। रोस टेलर और ग्रांट इलियट क्रीज पर हैं। कीवी टीम को पहला झटका ब्रेंडन मैक्कुलम के रूप में लगा। इसके बाद केन विलियम्सन को भी मोर्ने मोर्कल ने ही आउट किया।\n', '1427184128live-match-lead_1427.jpg', '', 'हाफ सेन्चुरी लगाने के बाद जश्न की मुद्रा में ब्रेंडन मैक्कुलम।', 0);
INSERT INTO `news` VALUES(54, 'मोदी सरकार से कार्यकर्ता नाराज, आरएसएस ने दी नीतीश से दोस्ती की सलाह', 'नई दिल्ली. राष्ट्रीय स्वयंसेवक संघ (आरएसएस) का कहना है कि बीजेपी के कार्यकर्ता केंद्र में मोदी सरकार से नाराज हैं। मोदी सरकार के कामकाज पर भाजपा कार्यकर्ता की निराशा भारी पड़ रही है। इस निराशा को दूर करने के लिए संघ स्वयं मॉनिटरिंग करेगा। दिल्ली में सोमवार को भाजपा और संघ की समन्वय बैठक हुई। समझा जा रहा है इसी बैठक में संघ की ओर से यह संदेश दिया गया है। साथ ही, इसी साल बिहार में होने वाले विधानसभा चुनाव को देखते हुए संघ ने बीजेपी को नीतीश कुमार से दोस्ती की सलाह दी है। लोकसभा चुनाव से पहले बीजेपी-जदयू के बीच गठबंधन खत्म हो गया था। हालांकि, संघ की ओर से केवल इस संबंध में सलाह मात्र दी गई है और नीतीश की पार्टी के साथ गठबंधन करना है या नहीं, इसका पूरा फैसला बीजेपी पर ही छोड़ दिया गया है।\nकार्यकर्ताओं की शिकायत, मंत्रियों तक पहुंचना हो गया है मुश्किल\nकेंद्रीय परिवहन मंत्री नितिन गडकरी के निवास पर संघ और भाजपा की समन्वय बैठक हुई। इसमें भाजपा अध्यक्ष अमित शाह, महासचिव संगठन रामलाल, केंद्रीय मंत्री राजनाथ सिंह, अरुण जेटली और स्वयं गडकरी मौजूद थे। संघ की तरफ से भैय्याजी जोशी, कृष्ण गोपाल, सुरेश सोनी आदि उपस्थित थे। भाजपा के कार्यकर्ता हर राज्य से शिकायत कर रहे हैं कि उन्हें लगता ही नहीं कि उनकी सरकार केंद्र में है। यह शिकायत आम है कि मंत्रियों तक पहुंच कठिन हो गई है। पार्टी में भी कमोबेश यही स्थिति है। सूत्रों का कहना है कि संघ ने इस शिकायत के निवारण के लिए एक अलग टीम बनाने का आग्रह भाजपा से किया है। इस टीम ने क्या किया, इसकी मॉनिटरिंग संघ खुद करेगा।\nभूमि अधिग्रहण मुद्दे पर बीजेपी के साथ खड़ा है संघ\nसूत्रों के मुताबिक, आरएसएस नेताओं ने भूमि अधिग्रहण बिल पर बीजेपी के आक्रामक तेवर की तारीफ की। हालांकि, संघ नहीं चाहता कि बीजेपी पर किसान विरोधी होने का ठप्पा लगे, इसलिए इस मसले पर संभल कर चलने की सलाह दी गई है। कहा जा रहा है कि दिल्ली में हुई बैठक के दौरान संघ के प्रतिनिधियों ने बीजेपी नेताओं से कहा कि बिल को लेकर पार्टी का तेवर ठीक है, लेकिन किसान संघ और उससे जुड़े हुए किसानों का नुकसान नहीं होना चाहिए। संघ के कार्यकर्ता इस बिल के सकारात्मक पहलुओं को उजागर करने का काम करेंगे, ताकि गांवों और किसानों को इस बारे में अवगत कराया जा सके।', '1427185021rss-meeting_1427167447.jpg', '', 'मोदी सरकार से कार्यकर्ता नाराज, आरएसएस ने दी नीतीश से दोस्ती की सलाह', 0);
INSERT INTO `news` VALUES(55, 'गब्बर इज बैक'' का ट्रेलर रिलीज, एक्शन अवतार में अक्षय कुमार', 'मुंबई: अक्षय कुमार और श्रुति हासन स्टारर फिल्म ''गब्बर इज बैक'' का ट्रेलर रिलीज हो गया है। ट्रेलर में अक्षय जबरदस्त एक्शन और तालीमार डायलॉग्स बोलते नजर आ रहे हैं।\nसंजय लीला भंसाली और वायकॉम 18 मोशन पिक्चर्स की इस फिल्म को कृष ने डायरेक्ट किया है। फिल्म में भ्रष्टाचार का मुद्दा उठाया गया है। फिल्म की टैगलाइन है ''अब करप्शन की उल्टी गिनती शुरू।''\nफिल्म में अक्षय कुमार हैं तो विलेन, लेकिन वे हीरो की तरह दिखाई पड़ रहे है। फिल्म के पोस्टर पर भी लिखा है ''नाम विलेन का काम हीरो का''। फिल्म में अक्षय कुमार और श्रुति हसन के साथ सोनू सूद, प्रकाश राज, गोविंद नामदेव, सुनिल ग्रोवर भी हैं। करीना कपूर खान और चित्रागंदा सिंह फिल्म में कैमियो करती दिखेंगी। यह फिल्म 1 मई को फ्लोर पर उतरेगी।  न्म्न्ब्', '1427185408gabbar-is-back-2_14271726.jpg', '', 'फ़िल्म गब्बर के एक सीन मे श्रुति ह्सन', 0);
INSERT INTO `news` VALUES(56, 'द्फ्घ्द्फ्ग्', 'द्फ्ग्ज्द्फ्ग्जेर्त्', '1427436685banappt4.jpg', '', 'ह्स्फ्ग्ज्व्र्त्जेर्त्ज्', 0);
INSERT INTO `news` VALUES(57, 'अस्द्फस्द्फ्', 'अस्द्गस्द्फ्', '1427440558calpud.jpg', '', '', 0);
INSERT INTO `news` VALUES(59, 'this is heading of news notification', 'this is content of news notification....', '', '', '', 0);
INSERT INTO `news` VALUES(63, 'द्च्ग्स्द्घ्फ्घ्ज्', 'च ब्म्न्फ्घ्ज्स्द्फ्गवेर्त ह्ग्द्फ्त्फ्ह्वेर्त्फ्ग्क़स्द्फ्व्स्द य्त्त्झ्द ह्य्ग्च्र्त ह्य्तेर्त्येफ्द्स्द्फ्ग्', '14277100741507795_10155589447985508_1819597370282725771_n.jpg', '', 'स्द्फ्ग्क्ष्च्व्ब्', 0);
INSERT INTO `news` VALUES(64, 'i20 Active new modal', 'new modal of i20 is launched on 9th march', '1427710157hyundai-i20-active-2_678x352_61424838469.jpg', '', 'i20 Ative', 0);
INSERT INTO `news` VALUES(65, 'i20 Active new modal', '', '142771020728hyundai2.jpg', '', '', 64);
INSERT INTO `news` VALUES(66, 'अस्द्फ्', 'अस्द्फ्', '14277171220390_republic-day-co.jpg', '', 'स्द्फ्ग्स्द्फ्ग्स्द्फ्ग्', 0);
INSERT INTO `news` VALUES(67, 'अस्द्फ्', 'स्द्फ्ह्स्ग्ज्म्न्व्स्फ्ग स्द्फ्ग्ज ह्र्त ज्व्र्त व्र्त्झ्न्व र्त्ज्न्व्र्त्', '14277171289883_r-day3_this_is_just_to_make_the_name_of_image_long.jpg', '', 'स झ्व र्त्ज र्फ्त्ग्स्क्ष्न त्ज्व र्य्ज्र्क़्जुझ ', 66);
INSERT INTO `news` VALUES(68, 'अस्द्फ्', 'एद्र्ह वेर्झ व्य्', '14277171389887_r-day5.jpg', '', 'व र्त्झ्व र्ज्त्च्फ्', 66);
INSERT INTO `news` VALUES(69, 'स स्द्फ ह्स स्फ्द्ग्ज स्', 'फ्ज द्र ग्द्त्य्क इद्त्य्क द्त्य द्र्तुक ', '14277173149887_r-day5.jpg', '', '', 0);
INSERT INTO `news` VALUES(70, 'स स्द्फ ह्स स्फ्द्ग्ज स्', '', '14277173159883_r-day3_this_is_just_to_make_the_name_of_image_long.jpg', '', '', 69);
INSERT INTO `news` VALUES(71, 'स स्द्फ ह्स स्फ्द्ग्ज स्', '', '14277173180390_republic-day-co.jpg', '', '', 69);
INSERT INTO `news` VALUES(72, 'कभी सचिन से होती थी तुलना, एक झगड़े ने बर्बाद किया रायुडू का करियर', 'खेल डेस्क. आईपीएल-८ ८ अप्रैल से शुरू हो रहा है। पहला मैच कोलकाता नाइटराइडर्स और मुंबई इंडियंस के बीच खेला जाएगा। आईपीएल (इंडियन प्रीमियर लीग) का लाख विरोध हो, बीसीसीआई को कोई फर्क नहीं पड़ता। इसके पीछे कई कारण है। इस टूर्नामेंट से कई खिलाड़ियों का करियर संवारा है। उदाहरण के रूप में अंबाती रायुडू को ही ले लें। पूर्व भारतीय क्रिकेटर शिवलाल यादव के क्रिकेटर बेटे अर्जुन यादव के साथ एक झगड़े ने रायुडू के क्रिकेट करियर को पूरी तरह बर्बाद कर दिया था। ढ्ढक्करु की मुंबई इंडियंस टीम की ओर से मिले मौके ने रायुडू की किस्मत बदल दी। करियर के शुरुआती दिनों में अंबाती रायुडू की तुलना सचिन तेंडुलकर से की जाती थी।\nकुछ यूं हुई झगड़े की शुरुआत\nदिसंबर २००५ की घटना है। अनंतपुर के मैदान पर आंध्र प्रदेश और हैदराबाद के बीच रणजी ट्रॉफी का मैच खेला जा रहा था। अर्जुन यादव और रायुडू आंध्र प्रदेश की ओर से खेल रहे थे। पहली पारी में अंबाती रायुडू मात्र २० रन के स्कोर पर प्रज्ञान ओझा की गेंद पर आउट हो गए। दूसरी पारी में रायुडू ने जबरदस्त शुरुआत की, लेकिन पांच चौका और १ छक्का लगाने के बाद एकबार फिर वे ओझा के शिकार बन गए।', '14279806381427980888.jpg', '', 'मास्टर ब्लास्टर सचिन तेंडुलकर और अंबाती रायुडू। (फाइल फोटो)', 0);
INSERT INTO `news` VALUES(75, 'sushil solanki', 'this is a news test', '1428389722Koala.jpg', '', 'koyala', 0);
INSERT INTO `news` VALUES(86, 'vbnvbdfdfhyhdfh', 'nvbvbnvbnvb', '1428472640Penguins.jpg', '', 'ncvbndfhdh', 0);
INSERT INTO `news` VALUES(116, 'Openers of india', 'comparison 2015 vs 2011', '1428483721temporary_file.jpg', '', 'sachin vs shikar', 0);
INSERT INTO `news` VALUES(120, 'छणढढ', 'दतढढ', '1428561150temporary_file.jpg', '', 'कगकी', 0);
INSERT INTO `news` VALUES(127, 'अमिताभ की भतीजी के रिसेप्शन में इंदिरा की 50 साल पुरानी साड़ी में दिखीं प्रियंका', 'हाल के चुनावों में कांग्रेस की करारी हार और प्रियंका गांधी को पार्टी में सक्रिय भूमिका देने की उठती मांग के बीच पिछले दिनों बॉलीवुड स्टार अमिताभ बच्चन की भतीजी के रिसेप्शन में प्रियंका अपनी दादी इंदिरा गांधी की साड़ी में नजर आईं। बच्चन परिवार की ओर से दिल्ली के फार्म हाउस में आयोजित रिसेप्शन में प्रियंका अपने पति रॉबर्ट वाड्रा के साथ पहुंची थीं। इस दौरान उन्होंने पूर्व प्रधानमंत्री इंदिरा गांधी की करीब 50 साल पुरानी साड़ी पहन रखी थी। यह पहला मौका नहीं है, जब वे अपनी दादी की साड़ी में नजर आईं। इससे पहले भी कई बार प्रियंका अपनी दादी की साड़ियों में नजर आ चुकी हैं। बता दें कि पिछले हफ्ते अमिताभ बच्चन के भाई अजिताभ बच्चन की बेटी नैना और एक्टर कुणाल की शादी की दिल्ली में पार्टी थी, जहां बच्चन परिवार ने परिवार के करीबियों और कई मशहूर हस्तियों को आमंत्रित किया था।', '14290966521429096949.jpg', '', '', 0);
INSERT INTO `news` VALUES(128, 'बॉश कंपनी में डकैती, सुरक्षाकर्मियों को बंधक बनाकर 25 लाख का माल ले भागे डकैत', 'ये हैं वो 5 बातें जो पेरेंट्स और उनके टीनएजर बच्चों में ला कर सकती हैं फासले', '14290968551429096987.jpg', '', '', 0);
INSERT INTO `news` VALUES(129, 'प्रधानमंत्री ने कहा- बदल रहा है देश...', 'तीन देशों की यात्रा के आखिरी पड़ाव में प्रधानमंत्री नरेंद्र मोदी ने टोरंटो के रिकोह स्टेडियम में भारतीय समुदाय के लोगों को संबोधित किया। उन्‍होंने अपने भाषण में दैनिक भास्कर के ''नो निगेटिव मंडे'' कैंपेन का उदाहरण दिया। उन्होंने कहा, ''आपको एक हैरानी की बात बताता हूं। यह सबसे बड़ा सरप्राइज है। मेरे लिए भी सरप्राइज है, लेकिन मेरे लिए यह एक सुखद आश्चर्य है। एक अखबार के मालिक ने मुझे चिठ्ठी लिखी है। उसमें लिखा गया है कि देश का जो मूड है, उससे हमने हमारे अखबार की एक नीति बनाई है, वह नीति यह है कि सप्ताह में एक दिन हमारा अखबार, सिर्फ और सिर्फ पॉजिटिव न्यूज ही छापेगा। यह छोटी घटना नहीं है मित्रों। भले ही आज एक अखबार ने यह काम शुरू किया है, लेकिन खुद इसे कहना बड़ी बात है। यह विचार मैंने नहीं दिया, हमारे पूर्व राष्ट्रपति अब्दुल कलाम बार-बार कहते थे कि पॉजिटिव न्यूज का एक कॉलम बनाइए। यह मैंने कहने की हिम्मत नहीं की। मुझे खुशी हुई कि बदले हुए जन-मन का कहां-कहां फैलाव हो रहा है। उससे लगता है कि आप जिन सपनों को लेकर जीते हैं, उन सपनों को साकार होते देखेंगे।''', '14291713401429171561.jpg', '', '', 0);
INSERT INTO `news` VALUES(130, 'प्रधानमंत्री ने कहा- बदल रहा है देश...', 'मोदी ने कनाडा में भास्कर के नो निगेटिव मंडे का उदाहरण दिया', '14291713891429171639.jpg', '', '', 129);
INSERT INTO `news` VALUES(131, 'मोदी ने कनाडा में भास्कर के नो निगेटिव मंडे का उदाहरण दिया', 'तीन देशों की यात्रा के आखिरी पड़ाव में प्रधानमंत्री नरेंद्र मोदी ने टोरंटो के रिकोह स्टेडियम में भारतीय समुदाय के लोगों को संबोधित किया। उन्‍होंने अपने भाषण में दैनिक भास्कर के ''नो निगेटिव मंडे'' कैंपेन का उदाहरण दिया। उन्होंने कहा, ''आपको एक हैरानी की बात बताता हूं। यह सबसे बड़ा सरप्राइज है। मेरे लिए भी सरप्राइज है, लेकिन मेरे लिए यह एक सुखद आश्चर्य है। एक अखबार के मालिक ने मुझे चिठ्ठी लिखी है। उसमें लिखा गया है कि देश का जो मूड है, उससे हमने हमारे अखबार की एक नीति बनाई है, वह नीति यह है कि सप्ताह में एक दिन हमारा अखबार, सिर्फ और सिर्फ पॉजिटिव न्यूज ही छापेगा। यह छोटी घटना नहीं है मित्रों। भले ही आज एक अखबार ने यह काम शुरू किया है, लेकिन खुद इसे कहना बड़ी बात है। यह विचार मैंने नहीं दिया, हमारे पूर्व राष्ट्रपति अब्दुल कलाम बार-बार कहते थे कि पॉजिटिव न्यूज का एक कॉलम बनाइए। यह मैंने कहने की हिम्मत नहीं की। मुझे खुशी हुई कि बदले हुए जन-मन का कहां-कहां फैलाव हो रहा है। उससे लगता है कि आप जिन सपनों को लेकर जीते हैं, उन सपनों को साकार होते देखेंगे।''', '14291714291429171727.jpg', '', '', 0);
INSERT INTO `news` VALUES(132, 'मोदी ने कनाडा में भास्कर के नो निगेटिव मंडे का उदाहरण दिया', ' विश्व का ऐसा पहला अखबार है, जिसने इसी साल 19 जनवरी (उस दिन का पेज देखने के लिए यहां क्लिक करें) को ''नो निगेटिव न्यूज'' कैंपेन की शुरुआत की थी। इसके तहत अखबार के सोमवार के संस्करण में केवल पॉजीटिव खबरों को महत्‍व दिया जाता है। निगेटिव न्‍यूज को केवल सूचनात्‍मक रूप में छापा जाता है। साथ में टैग भी लगता है कि यह निगेटिव न्‍यूज है, लेकिन आपके लिए जानना जरूरी है।', '14291714581429171561.jpg', '', '', 131);
INSERT INTO `news` VALUES(133, 'आगरा में चर्च पर हमला: मरियम को पहनाया कुत्ते का बेल्ट, यीशू की मूर्ति भी तोड़ी', 'आगरा के सेंट मैरी पर चर्च पर बुधवार देर रात अज्ञात लोगों ने हमला कर तोड़फोड़ की। हमलावरों ने चर्च परिसर में लगी मरियम स्टैचू के गले में कुत्ते का बेल्ट पहना दिया जबकि यीशू स्टैचू का सिर तोड़ दिया। रात करीब ढाई बजे हुए इस हमले की रिपोर्ट पादरी ने पुलिस में दर्ज करा दी है।\n\nपादरी के मुताबिक हमलावर चर्च के गेट को तोड़कर अंदर भी आने की कोशिश कर रहे थे लेकिन वे इसमें सफल नहीं हो सके। हमलावरों ने मरियम की स्टैचू के गले में कुत्ते का बेल्ट पहनाने के बाद बाल यीशू की मूर्ति का सिर तोड़ दिया। चर्च के बाहर खड़ी गाडि़यों को भी तोड़ दिया गया। गाडि़यों में तोड़फोड़ के दौरान ही किसी गाड़ी का सायरन बज गया और इसके बाद हमलावर वहां से भाग गए। स्थानीय ईसाईयों ने हमले का विरोध किया है।', '14291721971429172462.jpg', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `newsdetail`
--

CREATE TABLE `newsdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL,
  `newsid` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `reporterid` int(11) NOT NULL,
  `approvedbyadminid` int(11) NOT NULL DEFAULT '0',
  `isactive` int(11) NOT NULL DEFAULT '0',
  `isimportant` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=100 ;

--
-- Dumping data for table `newsdetail`
--

INSERT INTO `newsdetail` VALUES(1, 1, 1, '2015-03-19 12:42:27', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(2, 1, 3, '2015-03-19 17:17:25', 3, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(3, 1, 5, '2015-03-20 13:34:57', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(4, 1, 6, '2015-03-20 18:30:38', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(19, 1, 24, '2015-03-22 05:23:54', 1, 1, 1, 1);
INSERT INTO `newsdetail` VALUES(21, 3, 26, '2015-03-22 08:55:32', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(22, 1, 27, '2015-03-22 14:50:07', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(23, 1, 28, '2015-03-22 17:27:12', 1, 1, 1, 1);
INSERT INTO `newsdetail` VALUES(33, 1, 38, '2015-03-23 10:10:17', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(34, 4, 40, '2015-03-23 10:35:14', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(35, 4, 41, '2015-03-23 10:36:29', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(38, 1, 45, '2015-03-23 10:48:42', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(39, 1, 47, '2015-03-23 11:11:02', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(40, 1, 49, '2015-03-23 11:18:09', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(41, 1, 51, '2015-03-23 11:20:04', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(42, 4, 53, '2015-03-24 08:02:25', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(43, 7, 54, '2015-03-24 08:17:27', 1, 1, 1, 1);
INSERT INTO `newsdetail` VALUES(44, 8, 55, '2015-03-24 08:24:33', 1, 1, 1, 1);
INSERT INTO `newsdetail` VALUES(45, 8, 56, '2015-03-27 06:11:28', 1, 1, 1, 1);
INSERT INTO `newsdetail` VALUES(46, 7, 57, '2015-03-27 07:16:00', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(48, 7, 59, '2015-03-27 07:20:55', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(52, 5, 63, '2015-03-30 10:08:04', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(53, 1, 64, '2015-03-30 10:10:09', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(54, 9, 66, '2015-03-30 12:05:46', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(55, 9, 69, '2015-03-30 12:08:39', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(56, 1, 72, '2015-04-02 13:17:50', 1, 1, 1, 1);
INSERT INTO `newsdetail` VALUES(59, 1, 75, '2015-04-07 06:55:25', 3, 0, 0, 0);
INSERT INTO `newsdetail` VALUES(66, 1, 86, '2015-04-08 05:57:23', 3, 0, 0, 0);
INSERT INTO `newsdetail` VALUES(77, 1, 106, '2015-04-08 07:55:45', 3, 0, 0, 0);
INSERT INTO `newsdetail` VALUES(78, 1, 107, '2015-04-08 08:15:14', 3, 0, 0, 0);
INSERT INTO `newsdetail` VALUES(79, 1, 108, '2015-04-08 08:15:39', 3, 0, 0, 0);
INSERT INTO `newsdetail` VALUES(80, 1, 110, '2015-04-08 08:44:29', 3, 0, 0, 0);
INSERT INTO `newsdetail` VALUES(81, 1, 111, '2015-04-08 08:45:04', 3, 0, 0, 0);
INSERT INTO `newsdetail` VALUES(84, 1, 116, '2015-04-08 09:02:02', 1, 1, 1, 1);
INSERT INTO `newsdetail` VALUES(88, 7, 120, '2015-04-09 06:32:30', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(93, 3, 125, '2015-04-15 10:50:00', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(95, 11, 127, '2015-04-15 11:17:44', 1, 1, 1, 1);
INSERT INTO `newsdetail` VALUES(96, 12, 128, '2015-04-15 11:21:02', 1, 1, 1, 1);
INSERT INTO `newsdetail` VALUES(97, 15, 129, '2015-04-16 08:03:17', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(98, 15, 131, '2015-04-16 08:04:30', 1, 1, 1, 0);
INSERT INTO `newsdetail` VALUES(99, 14, 133, '2015-04-16 08:16:59', 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=37 ;

--
-- Dumping data for table `states`
--

INSERT INTO `states` VALUES(1, 'Andhra Pradesh');
INSERT INTO `states` VALUES(2, 'Arunachal Pradesh');
INSERT INTO `states` VALUES(3, 'Assam');
INSERT INTO `states` VALUES(4, 'Bihar');
INSERT INTO `states` VALUES(5, 'Chhattisgarh');
INSERT INTO `states` VALUES(6, 'Goa');
INSERT INTO `states` VALUES(7, 'Gujarat');
INSERT INTO `states` VALUES(8, 'Haryana');
INSERT INTO `states` VALUES(9, 'Himachal Pradesh');
INSERT INTO `states` VALUES(10, 'Jammu and Kashmir');
INSERT INTO `states` VALUES(11, 'Jharkhand');
INSERT INTO `states` VALUES(12, 'Karnataka');
INSERT INTO `states` VALUES(13, 'Kerala');
INSERT INTO `states` VALUES(14, 'Madhya Pradesh');
INSERT INTO `states` VALUES(15, 'Maharashtra');
INSERT INTO `states` VALUES(16, 'Manipur');
INSERT INTO `states` VALUES(17, 'Meghalaya');
INSERT INTO `states` VALUES(18, 'Mizoram');
INSERT INTO `states` VALUES(19, 'Nagaland');
INSERT INTO `states` VALUES(20, 'Odisha');
INSERT INTO `states` VALUES(21, 'Punjab');
INSERT INTO `states` VALUES(22, 'Rajasthan');
INSERT INTO `states` VALUES(23, 'Sikkim');
INSERT INTO `states` VALUES(24, 'Tamil Nadu');
INSERT INTO `states` VALUES(25, 'Telangana');
INSERT INTO `states` VALUES(26, 'Uttar Pradesh');
INSERT INTO `states` VALUES(27, 'Uttarakhand');
INSERT INTO `states` VALUES(28, 'Tripura');
INSERT INTO `states` VALUES(29, 'West Bengal');
INSERT INTO `states` VALUES(30, 'Andaman and Nicobar');
INSERT INTO `states` VALUES(31, 'Chandigarh');
INSERT INTO `states` VALUES(32, 'Dadra and Nagar Haveli');
INSERT INTO `states` VALUES(33, 'Daman and Diu');
INSERT INTO `states` VALUES(34, 'Lakshadweep');
INSERT INTO `states` VALUES(35, 'National Capital Territory of Delhi');
INSERT INTO `states` VALUES(36, 'Puducherry');

-- --------------------------------------------------------

--
-- Table structure for table `suggestions`
--

CREATE TABLE `suggestions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `contact_detail` text COLLATE utf8_unicode_ci NOT NULL,
  `device_uid` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `suggestions`
--


-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usertype` int(11) NOT NULL,
  `parentid` int(11) NOT NULL,
  `userinfo` int(11) NOT NULL,
  `clientid` int(11) NOT NULL,
  `isactive` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` VALUES(1, 1, 0, 1, 1, 1);
INSERT INTO `user` VALUES(2, 2, 1, 2, 1, 1);
INSERT INTO `user` VALUES(3, 3, 2, 3, 1, 1);
INSERT INTO `user` VALUES(4, 3, 2, 4, 1, 1);
INSERT INTO `user` VALUES(5, 2, 1, 5, 1, 0);
INSERT INTO `user` VALUES(6, 3, 5, 6, 1, 0);
INSERT INTO `user` VALUES(7, 3, 5, 7, 1, 0);
INSERT INTO `user` VALUES(9, 2, 1, 9, 1, 1);
INSERT INTO `user` VALUES(10, 2, 1, 10, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

CREATE TABLE `userinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `dob` date NOT NULL,
  `username` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `contact` text COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci NOT NULL,
  `areacode` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` VALUES(1, 'Jaspal Singh', '1992-07-29', 'jaspal.singh', '5f4dcc3b5aa765d61d8327deb882cf99', 'jaspal.s@xercesblue.in', '7891384482', 'shiv colony', 1);
INSERT INTO `userinfo` VALUES(2, 'Vikas Sharma', '2015-02-26', 'vikas.sharma', '5f4dcc3b5aa765d61d8327deb882cf99', 'vikas.s@xercesblue.in', '9782908308', 'purani abadi', 2);
INSERT INTO `userinfo` VALUES(3, 'Sushil Solanki', '2015-03-05', 'sushil.solanki', '5f4dcc3b5aa765d61d8327deb882cf99', 'sushil.s@xercesblue.in', '9638529635', 'lalgarh', 3);
INSERT INTO `userinfo` VALUES(4, 'Abhinav Bherav', '2015-03-03', 'abhinav.bherav', '5f4dcc3b5aa765d61d8327deb882cf99', 'abhinav.b@xercesblue.in', '7538521589', 'company', 4);
INSERT INTO `userinfo` VALUES(5, 'karni singh', '2015-03-02', 'karni.singh', '5f4dcc3b5aa765d61d8327deb882cf99', 'karni.s@xercesblue.in', '4587458965', 'company', 5);
INSERT INTO `userinfo` VALUES(6, 'pankaj kumar', '2015-03-08', 'pankaj.kumar', '5f4dcc3b5aa765d61d8327deb882cf99', 'pankaj.k@xercesblue.in', '2525363584', 'company', 6);
INSERT INTO `userinfo` VALUES(7, 'hitesh tantia', '2015-03-21', 'hitesh.tantia', '5f4dcc3b5aa765d61d8327deb882cf99', 'hitesh.t@xercesblue.in', '7474858596', 'company', 6);
INSERT INTO `userinfo` VALUES(8, 'abhinav', '2015-03-19', 'abhinav', 'ba1d63b653b24a565ed436a0cfc5b3c9', '', '9782908308', '', 1);
INSERT INTO `userinfo` VALUES(9, 'vikas', '2015-03-20', 'vikas', '34a873df827cb961493373aa317d2147', '', '9782908308', '', 0);
INSERT INTO `userinfo` VALUES(10, 'test', '2015-06-04', 'testuser', '5f4dcc3b5aa765d61d8327deb882cf99', 'test@user.com', '7575757589', '3rd shiv colony', 1);

-- --------------------------------------------------------

--
-- Table structure for table `usertype`
--

CREATE TABLE `usertype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `usertype`
--

INSERT INTO `usertype` VALUES(1, 'superAdmin', 'This the It Admin of the company!');
INSERT INTO `usertype` VALUES(2, 'admin', 'This is Editor of newspaper company, depending of areas');
INSERT INTO `usertype` VALUES(3, 'reporter', 'this is reporter under admin');
