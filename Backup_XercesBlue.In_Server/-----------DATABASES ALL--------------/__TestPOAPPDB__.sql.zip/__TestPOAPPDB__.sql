-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: 166.62.8.2
-- Generation Time: Aug 22, 2015 at 03:25 AM
-- Server version: 5.5.43
-- PHP Version: 5.1.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `TestPOAPPDB`
--
CREATE DATABASE `TestPOAPPDB` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `TestPOAPPDB`;

-- --------------------------------------------------------

--
-- Table structure for table `catappmapping`
--

CREATE TABLE `catappmapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CatId` int(11) NOT NULL,
  `CatSendId` int(11) NOT NULL,
  `AppId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `catappmapping`
--

INSERT INTO `catappmapping` VALUES(1, 1, 1, 1);
INSERT INTO `catappmapping` VALUES(2, 2, 2, 1);
INSERT INTO `catappmapping` VALUES(3, 3, 3, 1);
INSERT INTO `catappmapping` VALUES(4, 4, 4, 1);
INSERT INTO `catappmapping` VALUES(5, 5, 5, 1);
INSERT INTO `catappmapping` VALUES(6, 1, 1, 2);
INSERT INTO `catappmapping` VALUES(7, 2, 2, 2);
INSERT INTO `catappmapping` VALUES(8, 3, 3, 2);
INSERT INTO `catappmapping` VALUES(9, 4, 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `dataentryusers`
--

CREATE TABLE `dataentryusers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `dataentryusers`
--

INSERT INTO `dataentryusers` VALUES(1, 'Jaspal', 'jaspal.s@xercesblue.in', 'jaspals');
INSERT INTO `dataentryusers` VALUES(2, 'sankalp', 'sankalp', 'sankalp');

-- --------------------------------------------------------

--
-- Table structure for table `language`
--

CREATE TABLE `language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Lang` text COLLATE utf8_unicode_ci NOT NULL,
  `Code` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `language`
--

INSERT INTO `language` VALUES(1, 'English', 'en');
INSERT INTO `language` VALUES(2, 'Hindi', 'hi');
INSERT INTO `language` VALUES(3, 'Punjabi', 'pa');
INSERT INTO `language` VALUES(4, 'Bangla', 'bn');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `OptionId` int(11) NOT NULL AUTO_INCREMENT,
  `QuesId` int(11) NOT NULL,
  `OptionText` text COLLATE utf8_unicode_ci,
  `OptionNo` int(11) NOT NULL,
  `image` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`OptionId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=186 ;

--
-- Dumping data for table `options`
--

INSERT INTO `options` VALUES(1, 1, 'Only A', 1, NULL);
INSERT INTO `options` VALUES(2, 1, 'Only C', 2, NULL);
INSERT INTO `options` VALUES(3, 1, 'A and C', 3, NULL);
INSERT INTO `options` VALUES(4, 1, 'F and C', 4, NULL);
INSERT INTO `options` VALUES(5, 1, 'G and A', 5, NULL);
INSERT INTO `options` VALUES(6, 2, 'Only D', 1, NULL);
INSERT INTO `options` VALUES(7, 2, 'B and F', 2, NULL);
INSERT INTO `options` VALUES(8, 2, 'Only E', 3, NULL);
INSERT INTO `options` VALUES(9, 2, 'Only B', 4, NULL);
INSERT INTO `options` VALUES(10, 2, 'B and E', 5, NULL);
INSERT INTO `options` VALUES(11, 3, 'G and F', 1, NULL);
INSERT INTO `options` VALUES(12, 3, 'D and G', 2, NULL);
INSERT INTO `options` VALUES(13, 3, 'Only A', 3, NULL);
INSERT INTO `options` VALUES(14, 3, 'Only G', 4, NULL);
INSERT INTO `options` VALUES(15, 3, 'B and F', 5, NULL);
INSERT INTO `options` VALUES(16, 4, 'Only F', 1, NULL);
INSERT INTO `options` VALUES(17, 4, 'F and G', 2, NULL);
INSERT INTO `options` VALUES(18, 4, 'B, F and G', 3, NULL);
INSERT INTO `options` VALUES(19, 4, 'A and G', 4, NULL);
INSERT INTO `options` VALUES(20, 4, 'Only G', 5, NULL);
INSERT INTO `options` VALUES(21, 5, 'Only D', 1, NULL);
INSERT INTO `options` VALUES(22, 5, 'B, D, F and G', 2, NULL);
INSERT INTO `options` VALUES(23, 5, 'Only F', 3, NULL);
INSERT INTO `options` VALUES(24, 5, 'B, D and G', 4, NULL);
INSERT INTO `options` VALUES(25, 5, 'B, F and G', 5, NULL);
INSERT INTO `options` VALUES(26, 6, 'None', 1, NULL);
INSERT INTO `options` VALUES(27, 6, 'Three', 2, NULL);
INSERT INTO `options` VALUES(28, 6, 'Four', 3, NULL);
INSERT INTO `options` VALUES(29, 6, 'One', 4, NULL);
INSERT INTO `options` VALUES(30, 6, 'Two', 5, NULL);
INSERT INTO `options` VALUES(31, 7, 'None', 1, NULL);
INSERT INTO `options` VALUES(32, 7, 'One', 2, NULL);
INSERT INTO `options` VALUES(33, 7, 'Two', 3, NULL);
INSERT INTO `options` VALUES(34, 7, 'Three', 4, NULL);
INSERT INTO `options` VALUES(35, 7, 'More than three', 5, NULL);
INSERT INTO `options` VALUES(36, 8, 'LIFJ', 1, NULL);
INSERT INTO `options` VALUES(37, 8, 'PRTV', 2, NULL);
INSERT INTO `options` VALUES(38, 8, 'LRFV', 3, NULL);
INSERT INTO `options` VALUES(39, 8, 'PITJ', 4, NULL);
INSERT INTO `options` VALUES(40, 8, 'None of these', 5, NULL);
INSERT INTO `options` VALUES(41, 9, 'JL', 1, NULL);
INSERT INTO `options` VALUES(42, 9, 'OL', 2, NULL);
INSERT INTO `options` VALUES(43, 9, 'TL', 3, NULL);
INSERT INTO `options` VALUES(44, 9, 'TO', 4, NULL);
INSERT INTO `options` VALUES(45, 9, 'None of these', 5, NULL);
INSERT INTO `options` VALUES(46, 10, 'V', 1, NULL);
INSERT INTO `options` VALUES(47, 10, 'I', 2, NULL);
INSERT INTO `options` VALUES(48, 10, 'U', 3, NULL);
INSERT INTO `options` VALUES(49, 10, 'M', 4, NULL);
INSERT INTO `options` VALUES(50, 10, 'None of these', 5, NULL);
INSERT INTO `options` VALUES(51, 11, 'Fourth to the left', 1, NULL);
INSERT INTO `options` VALUES(52, 11, 'Third to the left', 2, NULL);
INSERT INTO `options` VALUES(53, 11, 'Third to the right', 3, NULL);
INSERT INTO `options` VALUES(54, 11, 'Second to the left', 4, NULL);
INSERT INTO `options` VALUES(55, 11, 'Second to the right', 5, NULL);
INSERT INTO `options` VALUES(56, 12, 'N', 1, NULL);
INSERT INTO `options` VALUES(57, 12, 'M', 2, NULL);
INSERT INTO `options` VALUES(58, 12, 'L', 3, NULL);
INSERT INTO `options` VALUES(59, 12, 'P', 4, NULL);
INSERT INTO `options` VALUES(60, 12, 'K', 5, NULL);
INSERT INTO `options` VALUES(61, 13, 'P', 1, NULL);
INSERT INTO `options` VALUES(62, 13, 'O', 2, NULL);
INSERT INTO `options` VALUES(63, 13, 'Q', 3, NULL);
INSERT INTO `options` VALUES(64, 13, 'L', 4, NULL);
INSERT INTO `options` VALUES(65, 13, 'None of these', 5, NULL);
INSERT INTO `options` VALUES(66, 14, 'N', 1, NULL);
INSERT INTO `options` VALUES(67, 14, 'J', 2, NULL);
INSERT INTO `options` VALUES(68, 14, 'P', 3, NULL);
INSERT INTO `options` VALUES(69, 14, 'O', 4, NULL);
INSERT INTO `options` VALUES(70, 14, 'None of these', 5, NULL);
INSERT INTO `options` VALUES(71, 15, 'JL', 1, NULL);
INSERT INTO `options` VALUES(72, 15, 'NQ', 2, NULL);
INSERT INTO `options` VALUES(73, 15, 'ML', 3, NULL);
INSERT INTO `options` VALUES(74, 15, 'OK', 4, NULL);
INSERT INTO `options` VALUES(75, 15, 'PJ', 5, NULL);
INSERT INTO `options` VALUES(76, 16, 'E', 1, NULL);
INSERT INTO `options` VALUES(77, 16, 'B', 2, NULL);
INSERT INTO `options` VALUES(78, 16, 'D', 3, NULL);
INSERT INTO `options` VALUES(79, 16, 'A', 4, NULL);
INSERT INTO `options` VALUES(80, 16, 'Cannot be determined', 5, NULL);
INSERT INTO `options` VALUES(81, 17, 'Numbered 2', 1, NULL);
INSERT INTO `options` VALUES(82, 17, 'Numbered 3', 2, NULL);
INSERT INTO `options` VALUES(83, 17, 'Numbered 5', 3, NULL);
INSERT INTO `options` VALUES(84, 17, 'Numbered 4', 4, NULL);
INSERT INTO `options` VALUES(85, 17, 'None of these', 5, NULL);
INSERT INTO `options` VALUES(86, 18, 'A', 1, NULL);
INSERT INTO `options` VALUES(87, 18, 'C', 2, NULL);
INSERT INTO `options` VALUES(88, 18, 'F', 3, NULL);
INSERT INTO `options` VALUES(89, 18, 'B', 4, NULL);
INSERT INTO `options` VALUES(90, 18, 'Cannot be determined', 5, NULL);
INSERT INTO `options` VALUES(91, 19, 'Only conclusiion I follows', 1, NULL);
INSERT INTO `options` VALUES(92, 19, 'Only conclusiion II follows', 2, NULL);
INSERT INTO `options` VALUES(93, 19, 'Either conclusion I or II', 3, NULL);
INSERT INTO `options` VALUES(94, 19, 'Neither conclusion I nor II follows.', 4, NULL);
INSERT INTO `options` VALUES(95, 19, 'Both conclusions I and II follow', 5, NULL);
INSERT INTO `options` VALUES(96, 20, 'Only conclusiion I follows', 1, NULL);
INSERT INTO `options` VALUES(97, 20, 'Only conclusiion II follows', 2, NULL);
INSERT INTO `options` VALUES(98, 20, 'Either conclusion I or II', 3, NULL);
INSERT INTO `options` VALUES(99, 20, 'Neither conclusion I nor II follows.', 4, NULL);
INSERT INTO `options` VALUES(100, 20, 'Both conclusions I and II follow', 5, NULL);
INSERT INTO `options` VALUES(101, 21, 'Only conclusiion I follows', 1, NULL);
INSERT INTO `options` VALUES(102, 21, 'Only conclusiion II follows', 2, NULL);
INSERT INTO `options` VALUES(103, 21, 'Either conclusion I or II', 3, NULL);
INSERT INTO `options` VALUES(104, 21, 'Neither conclusion I nor II follows.', 4, NULL);
INSERT INTO `options` VALUES(105, 21, 'Both conclusions I and II follow', 5, NULL);
INSERT INTO `options` VALUES(106, 22, 'Only conclusiion I follows', 1, NULL);
INSERT INTO `options` VALUES(107, 22, 'Only conclusiion II follows', 2, NULL);
INSERT INTO `options` VALUES(108, 22, 'Either conclusion I or II', 3, NULL);
INSERT INTO `options` VALUES(109, 22, 'Neither conclusion I nor II follows.', 4, NULL);
INSERT INTO `options` VALUES(110, 22, 'Both conclusions I and II follow', 5, NULL);
INSERT INTO `options` VALUES(111, 23, 'Only conclusiion I follows', 1, NULL);
INSERT INTO `options` VALUES(112, 23, 'Only conclusiion II follows', 2, NULL);
INSERT INTO `options` VALUES(113, 23, 'Either conclusion I or II', 3, NULL);
INSERT INTO `options` VALUES(114, 23, 'Neither conclusion I nor II follows.', 4, NULL);
INSERT INTO `options` VALUES(115, 23, 'Both conclusions I and II follow', 5, NULL);
INSERT INTO `options` VALUES(116, 24, 'Only conclusiion I follows', 1, NULL);
INSERT INTO `options` VALUES(117, 24, 'Only conclusiion II follows', 2, NULL);
INSERT INTO `options` VALUES(118, 24, 'Either conclusion I or II follows', 3, NULL);
INSERT INTO `options` VALUES(119, 24, 'Neither conclusion I nor II follows.', 4, NULL);
INSERT INTO `options` VALUES(120, 24, 'Both conclusions I and II follow', 5, NULL);
INSERT INTO `options` VALUES(121, 25, 'Only conclusiion I follows', 1, NULL);
INSERT INTO `options` VALUES(122, 25, 'Only conclusiion II follows', 2, NULL);
INSERT INTO `options` VALUES(123, 25, 'Either conclusion I or II follows', 3, NULL);
INSERT INTO `options` VALUES(124, 25, 'Neither conclusion I nor II follows.', 4, NULL);
INSERT INTO `options` VALUES(125, 25, 'Both conclusions I and II follow', 5, NULL);
INSERT INTO `options` VALUES(126, 26, 'Only conclusiion I follows', 1, NULL);
INSERT INTO `options` VALUES(127, 26, 'Only conclusiion II follows', 2, NULL);
INSERT INTO `options` VALUES(128, 26, 'Either conclusion I or II follows', 3, NULL);
INSERT INTO `options` VALUES(129, 26, 'Neither conclusion I nor II follows.', 4, NULL);
INSERT INTO `options` VALUES(130, 26, 'Both conclusions I and II follow', 5, NULL);
INSERT INTO `options` VALUES(131, 27, 'Only conclusiion I follows', 1, NULL);
INSERT INTO `options` VALUES(132, 27, 'Only conclusiion II follows', 2, NULL);
INSERT INTO `options` VALUES(133, 27, 'Either conclusion I or II follows', 3, NULL);
INSERT INTO `options` VALUES(134, 27, 'Neither conclusion I nor II follows.', 4, NULL);
INSERT INTO `options` VALUES(135, 27, 'Both conclusions I and II follow', 5, NULL);
INSERT INTO `options` VALUES(136, 28, 'Only conclusiion I follows', 1, NULL);
INSERT INTO `options` VALUES(137, 28, 'Only conclusiion II follows', 2, NULL);
INSERT INTO `options` VALUES(138, 28, 'Either conclusion I or II follows', 3, NULL);
INSERT INTO `options` VALUES(139, 28, 'Neither conclusion I nor II follows.', 4, NULL);
INSERT INTO `options` VALUES(140, 28, 'Both conclusions I and II follow', 5, NULL);
INSERT INTO `options` VALUES(141, 29, 'R or T', 1, NULL);
INSERT INTO `options` VALUES(142, 29, 'T', 2, NULL);
INSERT INTO `options` VALUES(143, 29, 'R', 3, NULL);
INSERT INTO `options` VALUES(144, 29, 'Q', 4, NULL);
INSERT INTO `options` VALUES(145, 29, 'None of these', 5, NULL);
INSERT INTO `options` VALUES(146, 30, 'R', 1, NULL);
INSERT INTO `options` VALUES(147, 30, 'Q', 2, NULL);
INSERT INTO `options` VALUES(148, 30, 'P', 3, NULL);
INSERT INTO `options` VALUES(149, 30, 'S', 4, NULL);
INSERT INTO `options` VALUES(150, 30, 'None of these', 5, NULL);
INSERT INTO `options` VALUES(151, 31, 'The data in Statement I alone are sufficient to answer the question. While the data in statement II alone are not sufficient to answer the question.', 1, NULL);
INSERT INTO `options` VALUES(152, 31, 'The data in Statement II alone are sufficient to answer the question, while the data in statement I alone are not sufficient to answer the question.', 2, NULL);
INSERT INTO `options` VALUES(153, 31, 'The data in either Statement I alone or statement II alone are sufficient to answer the question.', 3, NULL);
INSERT INTO `options` VALUES(154, 31, 'The data in both the Statement I and II together are not sufficient to answer the question.', 4, NULL);
INSERT INTO `options` VALUES(155, 31, 'The data in both the Statement I and II are together necessary to answer the question.', 5, NULL);
INSERT INTO `options` VALUES(156, 32, 'The data in Statement I alone are sufficient to answer the question. While the data in statement II alone are not sufficient to answer the question.', 1, NULL);
INSERT INTO `options` VALUES(157, 32, 'The data in Statement II alone are sufficient to answer the question, while the data in statement I alone are not sufficient to answer the question.', 2, NULL);
INSERT INTO `options` VALUES(158, 32, 'The data in either Statement I alone or statement II alone are sufficient to answer the question.', 3, NULL);
INSERT INTO `options` VALUES(159, 32, 'The data in both the Statement I and II together are not sufficient to answer the question.', 4, NULL);
INSERT INTO `options` VALUES(160, 32, 'The data in both the Statement I and II are together necessary to answer the question.', 5, NULL);
INSERT INTO `options` VALUES(161, 33, 'None', 1, NULL);
INSERT INTO `options` VALUES(162, 33, 'One', 2, NULL);
INSERT INTO `options` VALUES(163, 33, 'Two', 3, NULL);
INSERT INTO `options` VALUES(164, 33, 'Three', 4, NULL);
INSERT INTO `options` VALUES(165, 33, 'More than three', 5, NULL);
INSERT INTO `options` VALUES(166, 34, 'Only A', 1, NULL);
INSERT INTO `options` VALUES(167, 34, 'Only B', 2, NULL);
INSERT INTO `options` VALUES(168, 34, 'Only C', 3, NULL);
INSERT INTO `options` VALUES(169, 34, 'Only A and C', 4, NULL);
INSERT INTO `options` VALUES(170, 34, 'None', 5, NULL);
INSERT INTO `options` VALUES(171, 35, 'Government cannot withdraw subsidies provided to various items.', 1, NULL);
INSERT INTO `options` VALUES(172, 35, 'Government subsidy on cooking gas is purely a political decision', 2, NULL);
INSERT INTO `options` VALUES(173, 35, 'Government can compensate the expenditure incurred on subsidy by raising the various taxes', 3, NULL);
INSERT INTO `options` VALUES(174, 35, 'Subsidy provided by the government under various heads to the citizens increases the cost of capital', 4, NULL);
INSERT INTO `options` VALUES(175, 35, 'None of these', 5, NULL);
INSERT INTO `options` VALUES(176, 36, 'have the force to', 1, NULL);
INSERT INTO `options` VALUES(177, 36, 'be forced into', 2, NULL);
INSERT INTO `options` VALUES(178, 36, 'forcibly have', 3, NULL);
INSERT INTO `options` VALUES(179, 36, 'forcefully', 4, NULL);
INSERT INTO `options` VALUES(180, 36, 'No correction required', 5, NULL);
INSERT INTO `options` VALUES(181, 37, 'nothing better than', 1, NULL);
INSERT INTO `options` VALUES(182, 37, 'anything else unless', 2, NULL);
INSERT INTO `options` VALUES(183, 37, 'nothing but having', 3, NULL);
INSERT INTO `options` VALUES(184, 37, 'nothing else than', 4, NULL);
INSERT INTO `options` VALUES(185, 37, 'No correction required', 5, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `qrecord`
--

CREATE TABLE `qrecord` (
  `QuesId` int(11) NOT NULL AUTO_INCREMENT,
  `QuesCatId` int(11) NOT NULL,
  `QuesSubCatId` int(11) NOT NULL,
  `Question` text COLLATE utf8_unicode_ci NOT NULL,
  `CorrectOption` int(11) NOT NULL,
  `Hint` text COLLATE utf8_unicode_ci,
  `Solution` text COLLATE utf8_unicode_ci,
  `solutionImage` text COLLATE utf8_unicode_ci,
  `LangId` text COLLATE utf8_unicode_ci NOT NULL,
  `IsFav` int(11) DEFAULT NULL,
  `image` text COLLATE utf8_unicode_ci,
  `bankName` text COLLATE utf8_unicode_ci,
  `Year` text COLLATE utf8_unicode_ci,
  `userid` int(11) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`QuesId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=38 ;

--
-- Dumping data for table `qrecord`
--

INSERT INTO `qrecord` VALUES(1, 1, 0, 'Each of the questions given below is based on the given diagram. The diagram shows three circles each representing Doctors, Experienced Hospital Employee and Post Graduates.\r\n Doctors      D\r\n                                    G                     A  Experienced Hospittal Emplyees\r\n                       B           F           C\r\n                                     \r\n                                 E\r\nWhich of the following represents such people who are Experienced- Hospital Employees but are not doctors ?', 3, NULL, 'Experienced Hospital Employees who are not doctors can be repesented by A anc C.', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:14:55');
INSERT INTO `qrecord` VALUES(2, 1, 0, 'Each of the questions given below is based on the given diagram. The diagram shows three circles each representing Doctors, Experienced Hospital Employee and Post Graduates.\r\n Doctors      D\r\n                                    G                     A  Experienced Hospittal Emplyees\r\n                       B           F           C\r\n                                     \r\n                                 E\r\nWhich of the followingh represents such people who are Doctors and Post Graduates but not Experienced-Hospital Employees?', 4, NULL, 'Such people who are doctors as well as Post Graduate but not the experienced Hospital employees can be represented by B.', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:14:55');
INSERT INTO `qrecord` VALUES(3, 1, 0, 'Each of the questions given below is based on the given diagram. The diagram shows three circles each representing Doctors, Experienced Hospital Employee and Post Graduates.\r\n Doctors      D\r\n                                    G                     A  Experienced Hospittal Emplyees\r\n                       B           F           C\r\n                                     \r\n                                 E\r\nWhich of the following represents such Doctors who are also Experienced-Hospital Employees ?', 1, NULL, 'Such doctors who are also experienced Hospital employees can be represented by G and F.', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:14:55');
INSERT INTO `qrecord` VALUES(4, 1, 0, 'Each of the questions given below is based on the given diagram. The diagram shows three circles each representing Doctors, Experienced Hospital Employee and Post Graduates.\r\n Doctors      D\r\n                                    G                     A  Experienced Hospittal Emplyees\r\n                       B           F           C\r\n                                     \r\n                                 E\r\nWhich of the following represents Experienced-Hospital Employees who are Doctors but are not Post Graduates ?', 5, NULL, 'Experienced Hospital Employees who are Doctors but not Post Graduates can be represented by only G', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:14:55');
INSERT INTO `qrecord` VALUES(5, 1, 0, 'Each of the questions given below is based on the given diagram. The diagram shows three circles each representing Doctors, Experienced Hospital Employee and Post Graduates.\r\n Doctors      D\r\n                                    G                     A  Experienced Hospittal Emplyees\r\n                       B           F           C\r\n                                     \r\n                                 E\r\nWhich of the following represents all such people who are Doctors ?', 2, NULL, 'Doctor can be represented by B, D, F and G', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:14:55');
INSERT INTO `qrecord` VALUES(6, 1, 0, 'Study the following arrangement carefully and answer the questions given below :\r\nQ   S  R  U  I  V  p  j  l  g  n  f  m  t  o  k  e  a  h  d  b  c\r\n\r\nHow many such vowels are there in the above arrangement each of which is immediately preceded by a Consonant and also immediately followed by a Vowel?', 5, NULL, 'Consonant  Vowel     Vowel\r\nSuch combinations are :\r\nRUI  :   KEA', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:14:55');
INSERT INTO `qrecord` VALUES(7, 1, 0, 'Study the following arrangement carefully and answer the questions given below :\r\nQ   S  R  U  I  V   p  j  l  g  n  f  m  t  o  k  e  a  h  d  b  c\r\n\r\nHow many such pairs of alphabets are there in the series of alphabets given in CAPS LOCK in the above arrangement each of which has as many letters between them (in both forward and backward directions) as they have between them in the English alphabetical series ?', 4, NULL, '17      19    18     21      9      22\r\nQ         S     R       U       I        V', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:14:55');
INSERT INTO `qrecord` VALUES(8, 1, 0, 'Study the following arrangement carefully and answer the questions given below :\r\nQ   S  R  U  I  V   p  j  l  g  n  f  m  t  o  k  e  a  h  d  b  c\r\n\r\nOn the basis of above series of alphabets DECK is written as BABE and BARS is written as CHSR, then how will JUMP be written ?', 1, NULL, 'D  E   C   K            B    A   R   S              J    U    M  P\r\n+1 +1+1-1             +1  +1  -1 +1             +1  +1  -1  +1\r\nB   A  B  E             C    H   S  R              L    I      F    J', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:14:55');
INSERT INTO `qrecord` VALUES(9, 1, 0, 'Study the following arrangement carefully and answer the questions given below :\r\nQ   S  R  U  I  V   p  j  l  g  n  f  m  t  o  k  e  a  h  d  b  c\r\n\r\nOn the basis of above series of alphabets if PJ is related to GI, EA is related to DO, then NF is related to DO, then NF is related to-', 3, NULL, 'P           +3         G  \r\n\r\nJ           -3            I\r\n\r\nE          +3            D\r\n\r\nA           -3           O\r\n   Therefore.    N                 +3           T\r\n                              F                  -3            L', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:14:55');
INSERT INTO `qrecord` VALUES(10, 1, 0, 'Study the following arrangement carefully and answer the questions given below :\r\nQ   S  R  U  I  V   p  j  l  g  n  f  m  t  o  k  e  a  h  d  b  c\r\n\r\nWhich of the following is the fourth to the left of the ninth from the left end of the above arrangment?', 2, NULL, '4th to the left of ninth from the left means 5the from the left. i.e. I.', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:14:55');
INSERT INTO `qrecord` VALUES(11, 1, 0, 'Study the following information carefully and answer the questions given below :\r\nJ,  K,  L,  M,  N,  O,  P  and Q are sitting around a circular table facing the centre but not necessarily in the same order. O is immediate neighbour of both K and Q only one person sits between K and J, L and M are neighbours but are not immediate neightbours of Q. Two persons sit between M and P, P does not sit to the immediate right of K\r\n\r\nWhat is the position of P with respect to Q ?', 2, NULL, 'N=>Q=>O=>K=>P=>J=>L=>M\r\n\r\nP is third to the left of Q.', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:17:43');
INSERT INTO `qrecord` VALUES(12, 1, 0, 'Study the following information carefully and answer the questions given below :\r\nJ,  K,  L,  M,  N,  O,  P  and Q are sitting around a circular table facing the centre but not necessarily in the same order. O is immediate neighbour of both K and Q only one person sits between K and J, L and M are neighbours but are not immediate neightbours of Q. Two persons sit between M and P, P does not sit to the immediate right of K\r\n\r\nWho amongst the following is sitting to the right of J ?', 4, NULL, 'N=>Q=>O=>K=>P=>J=>L=>M\r\n\r\nP is sitting to the right of J.', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:17:43');
INSERT INTO `qrecord` VALUES(13, 1, 0, 'Study the following information carefully and answer the questions given below :\r\nJ,  K,  L,  M,  N,  O,  P  and Q are sitting around a circular table facing the centre but not necessarily in the same order. O is immediate neighbour of both K and Q only one person sits between K and J, L and M are neighbours but are not immediate neightbours of Q. Two persons sit between M and P, P does not sit to the immediate right of K\r\n\r\nWho amongst the following sits exactly between K and J ?', 1, NULL, 'P sits exactly between K and J.\r\n\r\nN=>Q=>O=>K=>P=>J=>L=>M', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:17:43');
INSERT INTO `qrecord` VALUES(14, 1, 0, 'Study the following information carefully and answer the questions given below :\r\nJ,  K,  L,  M,  N,  O,  P  and Q are sitting around a circular table facing the centre but not necessarily in the same order. O is immediate neighbour of both K and Q only one person sits between K and J, L and M are neighbours but are not immediate neightbours of Q. Two persons sit between M and P, P does not sit to the immediate right of K\r\n\r\nWho amonst the following sits forth to the left of M ?', 5, NULL, 'K sits fourth to the left of M.\r\n\r\nN=>Q=>O=>K=>P=>J=>L=>M', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:17:43');
INSERT INTO `qrecord` VALUES(15, 1, 0, 'Study the following information carefully and answer the questions given below :\r\nJ,  K,  L,  M,  N,  O,  P  and Q are sitting around a circular table facing the centre but not necessarily in the same order. O is immediate neighbour of both K and Q only one person sits between K and J, L and M are neighbours but are not immediate neightbours of Q. Two persons sit between M and P, P does not sit to the immediate right of K\r\n\r\nFour of the following five are alike in acertain way and thus form a group. Which is the one that DOES NOT belong to that group ?', 3, NULL, 'Except in ML, in all others the first person is sitting to the immediate right of the second person.\r\n\r\nN=>Q=>O=>K=>P=>J=>L=>M', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:17:43');
INSERT INTO `qrecord` VALUES(16, 1, 0, 'Study the following information to answer the given questions.\r\nIn a six storeyed building the ground floor is numbered one, the floor avove it is numbered one, the floor above it is numbered two and so on such that the topmost floor is numbered six. One out of six people viz, A, B, C, D, E, and F lives on each floor. No one lives between C and F. There are two floors between the floors on which A and D live. A lives on floor above the floor on which D lives. E lives on odd numbered floor. B does not live on a floor immediately above or below E''s floor.\r\n\r\nWho lives on the ground floor ?', 1, NULL, 'Floor No.                             Person\r\n  6                                               B\r\n  5                                                A\r\n  4                                               F/C\r\n  3                                              F/C\r\n  2                                                D\r\n  1                                                E\r\n\r\nE lives on the Ground Floor numbered ''1''', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:17:43');
INSERT INTO `qrecord` VALUES(17, 1, 0, 'Study the following information to answer the given questions.\r\nIn a six storeyed building the ground floor is numbered one, the floor avove it is numbered one, the floor above it is numbered two and so on such that the topmost floor is numbered six. One out of six people viz, A, B, C, D, E, and F lives on each floor. No one lives between C and F. There are two floors between the floors on which A and D live. A lives on floor above the floor on which D lives. E lives on odd numbered floor. B does not live on a floor immediately above or below E''s floor.\r\n\r\nWhere does A live ?', 3, NULL, 'Floor No.                             Person\r\n  6                                               B\r\n  5                                                A\r\n  4                                               F/C\r\n  3                                              F/C\r\n  2                                                D\r\n  1                                                E\r\n\r\nA lives on the follr numbered ''5''', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:17:43');
INSERT INTO `qrecord` VALUES(18, 1, 0, 'Study the following information to answer the given questions.\r\nIn a six storeyed building the ground floor is numbered one, the floor avove it is numbered one, the floor above it is numbered two and so on such that the topmost floor is numbered six. One out of six people viz, A, B, C, D, E, and F lives on each floor. No one lives between C and F. There are two floors between the floors on which A and D live. A lives on floor above the floor on which D lives. E lives on odd numbered floor. B does not live on a floor immediately above or below E''s floor.\r\n\r\nWho lives immediately above D''s floor ?', 5, NULL, 'Floor No.                             Person\r\n  6                                               B\r\n  5                                                A\r\n  4                                               F/C\r\n  3                                              F/C\r\n  2                                                D\r\n  1                                                E\r\n\r\nEither C or F lives on the floor immediately above D''s foor', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:17:43');
INSERT INTO `qrecord` VALUES(19, 1, 0, 'In each question below are two statements followed by two conclusions numbered I and II. You have to take the two given statements to be true even if they seem to be at variance from known facts and then decide which of the given conclusions logically commonly follows from the given statements disregarding commonly known facts.\r\n\r\nStatements :       All buses are cars.\r\n                             Some buses are trucks.\r\nConclusions :   I. Some buses definitely not trucks\r\n                          II. At least some trucks are cars.', 2, NULL, '(i) All buses are cars => Universal Affirmative (A-type)\r\n(ii) Some buses are trucks => Particular Affirmative (I-type).\r\n(iii) No leaf is a root => Universal Negative (E-type).\r\n(iv) No leaf is a roots => Particular Negative (O-type).\r\n\r\nSome turcks are buses.\r\nAll buses are cars.\r\nI + A => I - type of Conclusion\r\n"Some trucks are cars."\r\nThis is Conclusion II.\r\nSometimes, Particular Affirmative premise tends to be Universal Affirmative. Threfore, Conclusion I does not follow.', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:17:43');
INSERT INTO `qrecord` VALUES(20, 1, 0, 'In each question below are two statements followed by two conclusions numbered I and II. You have to take the two given statements to be true even if they seem to be at variance from known facts and then decide which of the given conclusions logically commonly follows from the given statements disregarding commonly known facts.\r\n\r\nStatements :     No leaf is a root.\r\n                           All plants are roots.\r\nConclusions :  I. No leaf is a plant.\r\n                         II.  Some plants are leaves.', 1, NULL, 'All plants are roots.\r\nNo root is a leaf.\r\nA+E => E-type of Conclusion \r\n"No plant is a leaf."\r\nConclusion I is Converse of this Conclusion.', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:17:43');
INSERT INTO `qrecord` VALUES(21, 1, 0, 'In each question below are two statements followed by two conclusions numbered I and II. You have to take the two given statements to be true even if they seem to be at variance from known facts and then decide which of the given conclusions logically commonly follows from the given statements disregarding commonly known facts.\r\n\r\nStatements :     Some chapters are units.\r\n                           Some units are topics.\r\nConclusions :    I.  At least some topics are chapters.\r\n                           II. Some topics are definitely not units.', 4, NULL, 'Both the Premises are Particular Affirmative. No conclusion follows from the two Particular premises.', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:17:43');
INSERT INTO `qrecord` VALUES(22, 1, 0, 'In each question below are two statements followed by two conclusions numbered I and II. You have to take the two given statements to be true even if they seem to be at variance from known facts and then decide which of the given conclusions logically commonly follows from the given statements disregarding commonly known facts.\r\n\r\nStatements :     Some chapters are units.\r\n                           Some units are topics.\r\nConclusions :   I. At least some topics are chapters.\r\n                          II. Some topics are definitely not units.', 4, NULL, 'All spoons are bowls.\r\nSome bowls are dishes.\r\nA+I => No Conclusion', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:21:00');
INSERT INTO `qrecord` VALUES(23, 1, 0, 'In each question below are two statements followed by two conclusions numbered I and II. You have to take the two given statements to be true even if they seem to be at variance from known facts and then decide which of the given conclusions logically commonly follows from the given statements disregarding commonly known facts.\r\n\r\nStatements :     Some gates are doors.\r\n                           No gate is window\r\nConclusions :    I.  No door is window.\r\n                           II. Some doors are definitely not windows.', 2, NULL, 'Some doors are gates.\r\nNo gate is window.\r\nI + E => O-type of Conclusion\r\n"Some doors are not windows ". \r\nThis is Conclusion II.', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:21:00');
INSERT INTO `qrecord` VALUES(24, 1, 0, 'In these questions, relationships between different elements is shown in the statements. These statements are followed by two conclusions.\r\n\r\nStatements :     A < F > T = E < R\r\n                          \r\nConclusions :    I.    A < F\r\n                           II.   R  >  F', 4, NULL, 'A < F > T = E < R\r\n                          \r\nConclusions :    I.   R <    F  : Not True\r\n                               II.   R  >  F  : Not True', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:21:00');
INSERT INTO `qrecord` VALUES(25, 1, 0, 'In these questions, relationships between different elements is shown in the statements. These statements are followed by two conclusions.\r\n\r\nStatements :     R > I < G < H > T\r\n                          \r\nConclusions :    I.    T <  I\r\n                           II.   H > I', 2, NULL, 'R > I < G < H > T\r\n                          \r\nConclusions :    I.   T <    I  : Not True\r\n                               II.   H  >  I  : True', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:21:00');
INSERT INTO `qrecord` VALUES(26, 1, 0, 'In these questions, relationships between different elements is shown in the statements. These statements are followed by two conclusions.\r\n\r\nStatements :    T = A < K > E = S\r\n                          \r\nConclusions :    I.    K <  T\r\n                              II.   S >  K', 2, NULL, 'T = A < K > E = S\r\n                          \r\nConclusions :    I.    K <  T  : Not True\r\n                              II.   S  <  K  : True', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:21:00');
INSERT INTO `qrecord` VALUES(27, 1, 0, 'In these questions, relationships between different elements is shown in the statements. These statements are followed by two conclusions.\r\n\r\nStatements :    P < O = I  <  N > T\r\n                          \r\nConclusions :    I.    P <  N\r\n                              II.   O  >  T', 1, NULL, 'Statements :    P < O = I  <  N > T\r\n                          \r\nConclusions :    I.    P <  N  :  True\r\n                              II.   O  >  T  :  Not True', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:21:00');
INSERT INTO `qrecord` VALUES(28, 1, 0, 'In these questions, relationships between different elements is shown in the statements. These statements are followed by two conclusions.\r\n\r\nStatements :    D > E >  L  > A > Y\r\n                          \r\nConclusions :    I.    Y <  D\r\n                              II.   A  >  E', 4, NULL, 'In these questions, relationships between different elements is shown in the statements. These statements are followed by two conclusions.\r\n\r\nStatements :    D > E >  L  > A > Y\r\n                          \r\nConclusions :    I.    Y <  D  :   Not True\r\n                              II.   A  >  E  :  Not True', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:21:00');
INSERT INTO `qrecord` VALUES(29, 1, 0, 'Study the following information carefully and answer the questions given below :\r\n        Among five friends P, Q R, S and T each having different height, T is the second tallest. P is taller than only S. R and T are taller than Q. P is taller than S but shorter than Q.\r\n\r\nWho among the following is the tallest in the group ?', 3, NULL, 'R is the tallest in the group.', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:21:00');
INSERT INTO `qrecord` VALUES(30, 1, 0, 'Study the following information carefully and answer the questions given below :\r\n        Among five friends P, Q R, S and T each having different height, T is the second tallest. P is taller than only S. R and T are taller than Q. P is taller than S but shorter than Q.\r\n\r\nWho among the following is the taller than T ?', 1, NULL, 'Only R is the taller than T.', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:21:00');
INSERT INTO `qrecord` VALUES(31, 1, 0, 'Each of the following questions below consists of a question and two statements numbered I and II given below it. You have to decide whether the data provided in the statements are sufficient to answer the question. Read both the statements and ___\r\nWhat is the total number of students in Course ''A'' in College ''X'' ?\r\nI. The respective ratio of girls and boys is 2 : 3.\r\nII. The number of students has grown by 5 percent this year as compared to 4 percent last year from the number 1000 which it was year before last.', 2, NULL, 'From statement II \r\nTotal number of students\r\n= 1000 + 40 + 52 = 1092', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:21:00');
INSERT INTO `qrecord` VALUES(32, 1, 0, 'Each of the following questions below consists of a question and two statements numbered I and II given below it. You have to decide whether the data provided in the statements are sufficient to answer the question. Read both the statements and ___\r\nWhat was the grand total of Falcon Team of College ''X'' ?\r\nI. Mayank correctly remembers that Falcon Team scored a grand total of above 82 but below 91.\r\nII. Animesh correctly remembers than Falcon Team scored a grand total of above 77 and below 84.', 5, NULL, 'From statement I \r\nGrand total of Falcon Team\r\n= 83,  84,  85,  86,   87,   88,  89 or 90\r\nFrom Statement II\r\nGrand Total of Falcon Team\r\n= 78,  79,  80,   81,  82,  or  83', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:21:00');
INSERT INTO `qrecord` VALUES(33, 1, 0, 'How many such pairs of letters are there in the word are there in the word FINANCIAL, each of which has as many letters between them in the word as in the English alphabetical series (in both for ward and backward directions) ?', 3, NULL, '6    9     14    1   14   3  9   1     12\r\nF    I       N    A   N   C   I    A     L', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:23:02');
INSERT INTO `qrecord` VALUES(34, 1, 0, 'Statement : Many students died in a collision of their bus and a truk near the school premise because the driver of truck lost his balance owing to high speed of the truck.\r\nCourses of Action :\r\n(A) The Government should immediatelyii cancel the licenses of all the trucks operating in the city.\r\n(B) The Government should prohibit the moverment of all the vehicles near the school premise.\r\n(C) The Government should set up a high level task force to suggest measures to prevent such incidents in the future.\r\nA course of action is a step or administrative decision to be taken for improvement. follow-up or further action in regard to ther problem, policy given in the statement, decide which of the suggested courses of action logically follow (s) for pursuing.', 3, NULL, 'Only course of action (C) seems to be suitable for pursuing. Course of action (A) seems to be very harsh. On the basis of an accident it is not prudent to cancel the licenses of all the trucks operating in the city. Course of action (B) is not feasible practically. It is not possible to prohibit the movement of all the vehicles near the school premise.', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:23:02');
INSERT INTO `qrecord` VALUES(35, 1, 0, 'Study the following information carefully and answer the questions given below :\r\n            The Government has decided to continue providing subsidy to consumers for cooking gas for three more years. This is not good news from the point of view of reining in the fiscal deficit. Mounting subvention for subsidies means diversion of savings by the government from investment to consumption, raising the cost of capital in the process. The Government must cut expenditure on subsidies to creat more fiscal space for investments in both physical and social infrastrcuture. It should outline a plan for comprehensive reform in major subsidies including petroleum. food and fertilizers and set a final deadline.\r\nWhich of the following is a Conclusion which can be drawn from the facts stated in the above paragraph ?', 4, NULL, 'Clearly option (4) can be derived from the facts stated in the paragraph.', NULL, 'en', NULL, NULL, 'IBPS BANK CLERK CWE', '16/12/12', 0, '2015-02-11 04:23:02');
INSERT INTO `qrecord` VALUES(36, 2, 0, 'Which of the phrases (1), (2), (3) and (4) given below should replace the phrase given in caps lock in the following sentencess to make the sentence grammatically correct? If the sentence is correct as it is and there is no correction required mark (5) i.e. is no correction required as the answer. ''No correction required'' as the answer.\r\n\r\nDuring the recession many companies will be FORCED TO lay off workers.', 5, NULL, '', NULL, 'en', NULL, NULL, '', '16/12/12', 0, '2015-02-11 04:23:02');
INSERT INTO `qrecord` VALUES(37, 2, 0, 'Which of the phrases (1), (2), (3) and (4) given below should replace the phrase given in caps lock in the following sentencess to make the sentence grammatically correct? If the sentence is correct as it is and there is no correction required mark (5) i.e. is no correction required as the answer. ''No correction required'' as the answer.\r\n\r\nHe wanted NOTHING ELSE EXPECTING to sleep after a stressful day at work.', 1, NULL, '', NULL, 'en', NULL, NULL, '', '16/12/12', 0, '2015-02-11 04:23:02');

-- --------------------------------------------------------

--
-- Table structure for table `questioncategory`
--

CREATE TABLE `questioncategory` (
  `QuesCatId` int(11) NOT NULL AUTO_INCREMENT,
  `QuesCat` text CHARACTER SET latin1,
  PRIMARY KEY (`QuesCatId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `questioncategory`
--

INSERT INTO `questioncategory` VALUES(1, 'Reasoning');
INSERT INTO `questioncategory` VALUES(2, 'English language');
INSERT INTO `questioncategory` VALUES(3, 'Quantitative aptitude');
INSERT INTO `questioncategory` VALUES(4, 'General Awareness');
INSERT INTO `questioncategory` VALUES(5, 'Computer Knowledge');

-- --------------------------------------------------------

--
-- Table structure for table `qusappmapping`
--

CREATE TABLE `qusappmapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `QuesId` int(11) NOT NULL,
  `AppId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `qusappmapping`
--

INSERT INTO `qusappmapping` VALUES(1, 1, 1);
INSERT INTO `qusappmapping` VALUES(2, 2, 1);
INSERT INTO `qusappmapping` VALUES(3, 3, 1);
INSERT INTO `qusappmapping` VALUES(4, 4, 1);
INSERT INTO `qusappmapping` VALUES(5, 5, 1);
INSERT INTO `qusappmapping` VALUES(6, 6, 1);
INSERT INTO `qusappmapping` VALUES(7, 7, 1);
INSERT INTO `qusappmapping` VALUES(8, 8, 1);
INSERT INTO `qusappmapping` VALUES(9, 9, 1);
INSERT INTO `qusappmapping` VALUES(10, 10, 1);
INSERT INTO `qusappmapping` VALUES(11, 11, 1);
INSERT INTO `qusappmapping` VALUES(12, 12, 1);
INSERT INTO `qusappmapping` VALUES(13, 13, 1);
INSERT INTO `qusappmapping` VALUES(14, 14, 1);
INSERT INTO `qusappmapping` VALUES(15, 15, 1);
INSERT INTO `qusappmapping` VALUES(16, 16, 1);
INSERT INTO `qusappmapping` VALUES(17, 17, 1);
INSERT INTO `qusappmapping` VALUES(18, 18, 1);
INSERT INTO `qusappmapping` VALUES(19, 19, 1);
INSERT INTO `qusappmapping` VALUES(20, 20, 1);
INSERT INTO `qusappmapping` VALUES(21, 21, 1);
INSERT INTO `qusappmapping` VALUES(22, 22, 1);
INSERT INTO `qusappmapping` VALUES(23, 23, 1);
INSERT INTO `qusappmapping` VALUES(24, 24, 1);
INSERT INTO `qusappmapping` VALUES(25, 25, 1);
INSERT INTO `qusappmapping` VALUES(26, 26, 1);
INSERT INTO `qusappmapping` VALUES(27, 27, 1);
INSERT INTO `qusappmapping` VALUES(28, 28, 1);
INSERT INTO `qusappmapping` VALUES(29, 29, 1);
INSERT INTO `qusappmapping` VALUES(30, 30, 1);
INSERT INTO `qusappmapping` VALUES(31, 31, 1);
INSERT INTO `qusappmapping` VALUES(32, 32, 1);
INSERT INTO `qusappmapping` VALUES(33, 33, 1);
INSERT INTO `qusappmapping` VALUES(34, 34, 1);
INSERT INTO `qusappmapping` VALUES(35, 35, 1);
INSERT INTO `qusappmapping` VALUES(36, 36, 1);
INSERT INTO `qusappmapping` VALUES(37, 37, 1);
