-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: 166.62.8.41
-- Generation Time: Aug 22, 2015 at 03:30 AM
-- Server version: 5.5.43
-- PHP Version: 5.1.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `xblueDB`
--
CREATE DATABASE `xblueDB` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `xblueDB`;

-- --------------------------------------------------------

--
-- Table structure for table `user_information`
--

CREATE TABLE `user_information` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `phone_number` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `message` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `user_information`
--

INSERT INTO `user_information` VALUES(1, 'Varshini Ailavajhala', '+91 9013591546', 'av.varshini@gmail.com', 'Hi,\r\nI saw your comment on a post in the Delhi Startups group and would love to intern in your company.\r\n\r\nDear Ma''am/Sir,\r\nI am currently a third year student pursuing Bachelor of Technology in Information Technology (B.Tech IT) from Guru Gobind Singh Indraprastha University, New Delhi. \r\n\r\nI would like to intern in your company  from June 2015 for 6-8 weeks. My proficiency lies in C,C++, Java and website development but I am open to any other related field.\r\n\r\nI have dabbled my hand in various languages like Python and PHP too. I am a self motivated person and believe that I could be an asset to your company.\r\n\r\nI would love to send my resume to you. Kindly, give me an email id through which I can contact you.\r\n\r\nThanking You');
INSERT INTO `user_information` VALUES(2, '', '', '', '');
INSERT INTO `user_information` VALUES(3, 'Delphine', 'Delphine', 'sgtjrxpci@yahoo.fr', 'Hi, my name is Delphine and I am the marketing manager at SwingSEO Solutions. I was just looking at your -- website and see that your site has the potential to become very popular. I just want to tell you, In case you don''t already know... There is a website service which already has more than 16 million users, and the majority of the users are interested in niches like yours. By getting your website on this service you have a chance to get your site more visitors than you can imagine. It is free to sign up and you can find out more about it here: http://zoy.bz/4nm - Now, let me ask you... Do you need your website to be successful to maintain your way of life? Do you need targeted traffic who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your website? If your answer is YES, you can achieve these things only if you get your website on the service I am talking about. This traffic network advertises you to thousands, while also giving you a chance to test the service before paying anything. All the popular websites are using this service to boost their traffic and ad revenue! Why arenâ€™t you? And what is better than traffic? Itâ€™s recurring traffic! That''s how running a successful website works... Here''s to your success! Find out more here: http://s.marcusmo.co.uk/5ot - or to unsubscribe please go here: http://innovad.ws/8h9dp');
INSERT INTO `user_information` VALUES(4, 'raj mudai', '9928487190', 'rmudai@gmail.com', 'Require a News paper web site for my new paper');
INSERT INTO `user_information` VALUES(5, '', '', '', '');
INSERT INTO `user_information` VALUES(6, '', '', '', '');
INSERT INTO `user_information` VALUES(7, 'Laetitia', 'Laetitia', 'yyfbzrgs@dayrep.com', 'Hi, my name is Laetitia and I am the marketing manager at CorpSEO marketing. I was just looking at your -- site and see that your website has the potential to get a lot of visitors. I just want to tell you, In case you didn''t already know... There is a website service which already has more than 16 million users, and the majority of the users are looking for niches like yours. By getting your website on this network you have a chance to get your site more popular than you can imagine. It is free to sign up and you can read more about it here: http://cabkit.in/e137 - Now, let me ask you... Do you need your site to be successful to maintain your way of life? Do you need targeted traffic who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your website? If your answer is YES, you can achieve these things only if you get your site on the network I am describing. This traffic service advertises you to thousands, while also giving you a chance to test the network before paying anything at all. All the popular blogs are using this service to boost their traffic and ad revenue! Why arenâ€™t you? And what is better than traffic? Itâ€™s recurring traffic! That''s how running a successful site works... Here''s to your success! Read more here: https://spna.ca/1pvm');
INSERT INTO `user_information` VALUES(8, '', '', '', '');
INSERT INTO `user_information` VALUES(9, '', '', '', '');
INSERT INTO `user_information` VALUES(10, 'Donna', 'Donna', 'wuxlqivgs@tom.com', 'I was just looking at your -- site and see that your website has the potential to get a lot of visitors. I just want to tell you, In case you didn''t already know... There is a website service which already has more than 16 million users, and the majority of the users are interested in websites like yours. By getting your site on this network you have a chance to get your site more visitors than you can imagine. It is free to sign up and you can read more about it here: http://www.arvut.org/1/dft - Now, let me ask you... Do you need your site to be successful to maintain your business? Do you need targeted visitors who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your site? If your answer is YES, you can achieve these things only if you get your website on the service I am describing. This traffic network advertises you to thousands, while also giving you a chance to test the network before paying anything at all. All the popular blogs are using this service to boost their traffic and ad revenue! Why arenâ€™t you? And what is better than traffic? Itâ€™s recurring traffic! That''s how running a successful website works... Here''s to your success! Read more here: http://cabkit.in/e13f');
INSERT INTO `user_information` VALUES(11, '', '', '', '');
INSERT INTO `user_information` VALUES(12, 'Priya', '', '', '');
INSERT INTO `user_information` VALUES(13, 'Donna', 'Donna', 'xnqzfry@tom.com', 'I was just looking at your -- website and see that your site has the potential to get a lot of visitors. I just want to tell you, In case you didn''t already know... There is a website service which already has more than 16 million users, and most of the users are looking for websites like yours. By getting your site on this service you have a chance to get your site more visitors than you can imagine. It is free to sign up and you can find out more about it here: http://gf10.com.br/url/iq2f - Now, let me ask you... Do you need your website to be successful to maintain your business? Do you need targeted visitors who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your website? If your answer is YES, you can achieve these things only if you get your site on the service I am talking about. This traffic service advertises you to thousands, while also giving you a chance to test the service before paying anything. All the popular websites are using this service to boost their readership and ad revenue! Why arenâ€™t you? And what is better than traffic? Itâ€™s recurring traffic! That''s how running a successful website works... Here''s to your success! Find out more here: http://www.arvut.org/1/dft');
INSERT INTO `user_information` VALUES(14, 'Valerie', 'Valerie', 'jztmaaxqwks@tom.com', 'I was just looking at your -- website and see that your site has the potential to become very popular. I just want to tell you, In case you don''t already know... There is a website service which already has more than 16 million users, and most of the users are looking for websites like yours. By getting your site on this service you have a chance to get your site more popular than you can imagine. It is free to sign up and you can find out more about it here: https://spna.ca/1pvm - Now, let me ask you... Do you need your website to be successful to maintain your business? Do you need targeted traffic who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your site? If your answer is YES, you can achieve these things only if you get your website on the service I am describing. This traffic service advertises you to thousands, while also giving you a chance to test the service before paying anything at all. All the popular websites are using this network to boost their readership and ad revenue! Why arenâ€™t you? And what is better than traffic? Itâ€™s recurring traffic! That''s how running a successful site works... Here''s to your success! Find out more here: http://ittsy.com/it/3x');
INSERT INTO `user_information` VALUES(15, '', '', '', '');
INSERT INTO `user_information` VALUES(16, '', '', '', '');
INSERT INTO `user_information` VALUES(17, 'Valerie', 'Valerie', 'eahmfzixp@tom.com', 'I was just looking at your -- website and see that your site has the potential to become very popular. I just want to tell you, In case you don''t already know... There is a website service which already has more than 16 million users, and most of the users are interested in topics like yours. By getting your site on this service you have a chance to get your site more visitors than you can imagine. It is free to sign up and you can read more about it here: http://www.arvut.org/1/dft - Now, let me ask you... Do you need your site to be successful to maintain your way of life? Do you need targeted traffic who are interested in the services and products you offer? Are looking for exposure, to increase sales, and to quickly develop awareness for your site? If your answer is YES, you can achieve these things only if you get your website on the network I am talking about. This traffic service advertises you to thousands, while also giving you a chance to test the network before paying anything at all. All the popular sites are using this service to boost their traffic and ad revenue! Why arenâ€™t you? And what is better than traffic? Itâ€™s recurring traffic! That''s how running a successful site works... Here''s to your success! Read more here: http://tgi.link/dcf2\r\nValerie http://bbqr.me/4fj5');
