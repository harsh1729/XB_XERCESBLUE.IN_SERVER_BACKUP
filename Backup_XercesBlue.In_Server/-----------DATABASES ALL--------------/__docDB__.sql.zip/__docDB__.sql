-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: 166.62.8.43
-- Generation Time: Aug 22, 2015 at 03:33 AM
-- Server version: 5.5.43
-- PHP Version: 5.1.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `docDB`
--
CREATE DATABASE `docDB` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `docDB`;

-- --------------------------------------------------------

--
-- Table structure for table `appointment_person`
--

CREATE TABLE `appointment_person` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doc_id` int(11) NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `contact` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=55 ;

--
-- Dumping data for table `appointment_person`
--

INSERT INTO `appointment_person` VALUES(6, 6, 'DR SATYAM SHARMA', '9929980176');
INSERT INTO `appointment_person` VALUES(7, 7, 'DR SATYAM SHARMA', '9929980176');
INSERT INTO `appointment_person` VALUES(8, 8, 'DR SATYAM SHARMA', '9929980176');
INSERT INTO `appointment_person` VALUES(9, 10, 'DR ASHISH CHHABRA', '9414209915');
INSERT INTO `appointment_person` VALUES(10, 11, 'RAJOTIA HOSPITAL', '01542970000');
INSERT INTO `appointment_person` VALUES(16, 19, 'AMIR CHAND', '8560801422');
INSERT INTO `appointment_person` VALUES(18, 21, 'SANDEEP SAIN', '9571372808');
INSERT INTO `appointment_person` VALUES(19, 23, 'MAHESH', '9571845222');
INSERT INTO `appointment_person` VALUES(21, 25, 'RAJNI', '9351716380');
INSERT INTO `appointment_person` VALUES(23, 2, 'Rajender Ji', '0154265055');
INSERT INTO `appointment_person` VALUES(24, 24, 'SANJAY GAIDER', '8946824898');
INSERT INTO `appointment_person` VALUES(25, 30, 'SUMESH MIDDHA', '9414246414');
INSERT INTO `appointment_person` VALUES(28, 1, 'Chaman ji', '9928245886');
INSERT INTO `appointment_person` VALUES(29, 32, 'MAHESH', '9571845222');
INSERT INTO `appointment_person` VALUES(30, 33, 'DR SUNIL BENIWAL', '9214556002');
INSERT INTO `appointment_person` VALUES(31, 35, 'ATUL AGGARWAL', '9887677927');
INSERT INTO `appointment_person` VALUES(32, 12, 'GAGANDEEP', '9782727787');
INSERT INTO `appointment_person` VALUES(33, 16, 'PINKY', '9828074191');
INSERT INTO `appointment_person` VALUES(36, 17, 'HARI SINGH', '9828460762');
INSERT INTO `appointment_person` VALUES(37, 4, 'Gayanjeet singh', '9799352619');
INSERT INTO `appointment_person` VALUES(38, 13, 'ANKIT', '9694928920');
INSERT INTO `appointment_person` VALUES(39, 3, 'Dr. Sanjeev Jindal', '01542460899');
INSERT INTO `appointment_person` VALUES(40, 26, 'AMAR ARORA', '9782655237');
INSERT INTO `appointment_person` VALUES(41, 5, 'Raman Makkar', '9636445401');
INSERT INTO `appointment_person` VALUES(42, 20, 'RAJENDER KUMAR', '9461900007');
INSERT INTO `appointment_person` VALUES(43, 15, 'LAKHVINDER SINGH', '9782556616');
INSERT INTO `appointment_person` VALUES(44, 36, 'DR GOVIND KANT', '9414332999');
INSERT INTO `appointment_person` VALUES(45, 37, 'MRS VEENA CHHABRA', '0154-2464230');
INSERT INTO `appointment_person` VALUES(46, 38, 'BALVINDER', '7597589589');
INSERT INTO `appointment_person` VALUES(47, 39, 'Mrs INDU SHARMA', '154-2474700');
INSERT INTO `appointment_person` VALUES(49, 40, 'RECEPTIONIST', '9460988661');
INSERT INTO `appointment_person` VALUES(50, 14, 'DR NEERAJ MITTAL', '9829906025');
INSERT INTO `appointment_person` VALUES(52, 42, 'RECEPTION', '0154-2485004');
INSERT INTO `appointment_person` VALUES(53, 43, 'DR ADITYA', '9414332266');
INSERT INTO `appointment_person` VALUES(54, 41, 'DR ADITYA MARKANDAY', '9414332266');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL,
  `pincode` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pincode` (`pincode`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `city`
--

INSERT INTO `city` VALUES(1, 'Sri Ganganagar', 19, 335001);
INSERT INTO `city` VALUES(2, 'Hanumangarh', 19, 335512);
INSERT INTO `city` VALUES(6, 'Jaipur', 19, 302001);

-- --------------------------------------------------------

--
-- Table structure for table `clinic_image`
--

CREATE TABLE `clinic_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` text COLLATE utf8_unicode_ci NOT NULL,
  `doc_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=98 ;

--
-- Dumping data for table `clinic_image`
--

INSERT INTO `clinic_image` VALUES(3, '14394707231439471038.jpg', 3);
INSERT INTO `clinic_image` VALUES(4, '14394707251439471115.jpg', 3);
INSERT INTO `clinic_image` VALUES(5, '14394707271439470880.jpg', 3);
INSERT INTO `clinic_image` VALUES(6, '14394707291439471039.jpg', 3);
INSERT INTO `clinic_image` VALUES(7, '14394707311439470987.jpg', 3);
INSERT INTO `clinic_image` VALUES(8, '14394727131439473102.jpg', 4);
INSERT INTO `clinic_image` VALUES(9, '14394727151439473046.jpg', 4);
INSERT INTO `clinic_image` VALUES(10, '14394727171439472915.jpg', 4);
INSERT INTO `clinic_image` VALUES(11, '14394742731439474591.jpg', 5);
INSERT INTO `clinic_image` VALUES(12, '14394742751439474455.jpg', 5);
INSERT INTO `clinic_image` VALUES(13, '14394742771439474673.jpg', 5);
INSERT INTO `clinic_image` VALUES(14, '14395353051439535430.jpg', 6);
INSERT INTO `clinic_image` VALUES(15, '14395353071439535765.jpg', 6);
INSERT INTO `clinic_image` VALUES(16, '14395353091439535530.jpg', 6);
INSERT INTO `clinic_image` VALUES(17, '14395353131439535505.jpg', 6);
INSERT INTO `clinic_image` VALUES(18, '14395353051439535430.jpg', 7);
INSERT INTO `clinic_image` VALUES(19, '14395353071439535765.jpg', 7);
INSERT INTO `clinic_image` VALUES(20, '14395353091439535530.jpg', 7);
INSERT INTO `clinic_image` VALUES(21, '14395353131439535505.jpg', 7);
INSERT INTO `clinic_image` VALUES(22, '14395353051439535430.jpg', 8);
INSERT INTO `clinic_image` VALUES(23, '14395353071439535765.jpg', 8);
INSERT INTO `clinic_image` VALUES(24, '14395353091439535530.jpg', 8);
INSERT INTO `clinic_image` VALUES(25, '14395353131439535505.jpg', 8);
INSERT INTO `clinic_image` VALUES(26, '14395368891439537187.JPG', 9);
INSERT INTO `clinic_image` VALUES(27, '14395368911439537034.JPG', 9);
INSERT INTO `clinic_image` VALUES(28, '14395368941439537071.JPG', 9);
INSERT INTO `clinic_image` VALUES(29, '14395368961439537299.JPG', 9);
INSERT INTO `clinic_image` VALUES(30, '', 10);
INSERT INTO `clinic_image` VALUES(31, '', 10);
INSERT INTO `clinic_image` VALUES(32, '', 10);
INSERT INTO `clinic_image` VALUES(33, '', 10);
INSERT INTO `clinic_image` VALUES(34, '14395376431439538135.PNG', 10);
INSERT INTO `clinic_image` VALUES(35, '14395376481439537941.PNG', 10);
INSERT INTO `clinic_image` VALUES(36, '14395377211439537994.PNG', 10);
INSERT INTO `clinic_image` VALUES(37, '14395377401439538227.jpg', 10);
INSERT INTO `clinic_image` VALUES(38, '14395377451439538016.PNG', 10);
INSERT INTO `clinic_image` VALUES(40, '14395388581439539223.JPG', 11);
INSERT INTO `clinic_image` VALUES(41, '14395389051439539191.JPG', 11);
INSERT INTO `clinic_image` VALUES(42, '14395389461439539325.JPG', 11);
INSERT INTO `clinic_image` VALUES(43, '14395389761439539427.JPG', 11);
INSERT INTO `clinic_image` VALUES(44, '14395389781439539092.JPG', 11);
INSERT INTO `clinic_image` VALUES(45, '14395406681439541040.JPG', 12);
INSERT INTO `clinic_image` VALUES(46, '14395406701439540989.JPG', 12);
INSERT INTO `clinic_image` VALUES(47, '14395406711439541085.JPG', 12);
INSERT INTO `clinic_image` VALUES(48, '14395406731439540998.JPG', 12);
INSERT INTO `clinic_image` VALUES(49, '14395406751439540875.JPG', 12);
INSERT INTO `clinic_image` VALUES(57, '14395419761439542369.JPG', 14);
INSERT INTO `clinic_image` VALUES(58, '14395419791439542237.JPG', 14);
INSERT INTO `clinic_image` VALUES(59, '14395420151439542430.JPG', 14);
INSERT INTO `clinic_image` VALUES(60, '14395420171439542411.JPG', 14);
INSERT INTO `clinic_image` VALUES(61, '14395491551439549452.JPG', 21);
INSERT INTO `clinic_image` VALUES(62, '14395491561439549256.JPG', 21);
INSERT INTO `clinic_image` VALUES(63, '14395491581439549581.JPG', 21);
INSERT INTO `clinic_image` VALUES(64, '14395491591439549533.JPG', 21);
INSERT INTO `clinic_image` VALUES(65, '14395491611439549574.JPG', 21);
INSERT INTO `clinic_image` VALUES(66, '14395532421439553430.jpg', 22);
INSERT INTO `clinic_image` VALUES(68, '14395532451439553453.jpg', 22);
INSERT INTO `clinic_image` VALUES(69, '14395532481439553542.jpg', 22);
INSERT INTO `clinic_image` VALUES(70, '14395532501439553640.jpg', 22);
INSERT INTO `clinic_image` VALUES(71, '14397052031439705470.jpg', 2);
INSERT INTO `clinic_image` VALUES(72, '14397052781439705452.jpg', 2);
INSERT INTO `clinic_image` VALUES(73, '14397052791439705602.jpg', 2);
INSERT INTO `clinic_image` VALUES(74, '14397052811439705769.jpg', 2);
INSERT INTO `clinic_image` VALUES(75, '14397065331439706848.jpg', 24);
INSERT INTO `clinic_image` VALUES(76, '14397065351439706751.jpg', 24);
INSERT INTO `clinic_image` VALUES(77, '14397065361439706933.jpg', 24);
INSERT INTO `clinic_image` VALUES(78, '14397079111439708120.jpg', 1);
INSERT INTO `clinic_image` VALUES(79, '14397079121439708197.jpg', 1);
INSERT INTO `clinic_image` VALUES(80, '14397079141439708308.jpg', 1);
INSERT INTO `clinic_image` VALUES(81, '14397079171439708126.jpg', 1);
INSERT INTO `clinic_image` VALUES(82, '14397079191439708200.jpg', 1);
INSERT INTO `clinic_image` VALUES(83, '14397223411439722479.jpg', 13);
INSERT INTO `clinic_image` VALUES(84, '14397256961439726028.jpg', 26);
INSERT INTO `clinic_image` VALUES(85, '14397257181439726147.jpg', 26);
INSERT INTO `clinic_image` VALUES(86, '14397257201439726189.jpg', 26);
INSERT INTO `clinic_image` VALUES(87, '14397257231439725878.jpg', 26);
INSERT INTO `clinic_image` VALUES(88, '14397257251439726015.jpg', 26);
INSERT INTO `clinic_image` VALUES(89, '14397274961439727907.jpg', 20);
INSERT INTO `clinic_image` VALUES(90, '14397275001439727864.jpg', 20);
INSERT INTO `clinic_image` VALUES(91, '14397275021439727980.jpg', 20);
INSERT INTO `clinic_image` VALUES(92, '14397275041439727619.jpg', 20);
INSERT INTO `clinic_image` VALUES(93, '14397427941439743076.jpg', 27);
INSERT INTO `clinic_image` VALUES(94, '14398106211439810894.JPG', 41);
INSERT INTO `clinic_image` VALUES(95, '14398106311439811088.jpg', 41);
INSERT INTO `clinic_image` VALUES(96, '14398106791439810823.jpg', 41);
INSERT INTO `clinic_image` VALUES(97, '14398107001439810939.jpg', 41);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `contact` text COLLATE utf8_unicode_ci NOT NULL,
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `qualification` text COLLATE utf8_unicode_ci NOT NULL,
  `fees` int(11) NOT NULL,
  `housetiming` text COLLATE utf8_unicode_ci NOT NULL,
  `clinictiming` text COLLATE utf8_unicode_ci NOT NULL,
  `holidaytiming` text COLLATE utf8_unicode_ci NOT NULL,
  `doc_addrs_house_no` text COLLATE utf8_unicode_ci NOT NULL,
  `doc_addrs_colony` text COLLATE utf8_unicode_ci NOT NULL,
  `doc_image` text COLLATE utf8_unicode_ci NOT NULL,
  `clinic_name` text COLLATE utf8_unicode_ci NOT NULL,
  `clinic_facility` text COLLATE utf8_unicode_ci NOT NULL,
  `clinic_addrs_house_no` text COLLATE utf8_unicode_ci NOT NULL,
  `clinic_addrs_colony` text COLLATE utf8_unicode_ci NOT NULL,
  `addrs_state_id` int(11) NOT NULL,
  `addrs_city_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=44 ;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` VALUES(1, 5, 1, 'Dr Suresh Goyal', '9660340660', 'drsumitmds@gmail.com', 'M.S (Ortho)', 150, '', '10:30 AM TO 3.00 PM\r\n5.00 PM TO 7.00 PM', '10:30 AM TO 3.00 PM\r\n5.00 PM TO 7.00 PM', '1-E-13', 'Sukhrianagar', '14397085641439708739.jpg', 'Garg Hospital', 'KNEE & HIP JOINT REPLACEMENT\r\nFULLY EQUIPPED LAB\r\nX-RAY\r\nA/C - ROOMS ', '2-A-15 ', 'Sukhrianagar', 19, 1);
INSERT INTO `doctor` VALUES(2, 4, 2, 'Dr Vivek Gupta', '9414087055', 'drvivek1995@gmail.com', 'MD (Pedia)', 200, '', '10:00: AM TO 2.00 PM\r\n5.00 PM TO 7.00 PM\r\n', '10:00 AM TO 12.00 PM', '87', 'Vrindavan Vihar', '14397043051439704728.jpg', 'Delhi child hospital & premature care center', 'Neonatal intensive care unit\r\nOPD\r\nA/C Rooms\r\nWards', '98', 'Vrindavan Vihar ', 19, 1);
INSERT INTO `doctor` VALUES(3, 9, 3, 'Dr. Sanjeev Jindal', '9214425999', 'drjindaleye@gmail.com', 'MS.(Optho.)', 200, '', '10:00:00', '', '104', 'Vrindavan Vihar, Gagan Path', '14397240791439724336.jpg', 'Jindal Eye Care', 'OCT\r\nTopical Faco\r\nलेसिक लेज़र \r\nकला मोतीआ का ऑपरेशन ', '104', 'Vrindavan Vihar, Gagan Path', 19, 1);
INSERT INTO `doctor` VALUES(4, 6, 4, 'Dr Praveen Kumar Gupta', '9414089086', 'guptapraveendr@gmail.com', 'M.S.,FICS, D.Pel (Germany)', 200, '', '09:00 AM TO 3ː00 PM', '', '1-B-5', 'Sukhria Nagar', '14397197391439720122.jpg', 'Adarsh Nursing Home & Stone Clinic (P) LTD', 'दूरबीन से पित्ताशय की पथरी का ऑप्रेशन\r\nबिना पेट चीरे बच्चेदानी का ऑप्रेशन \r\nगदुद का बुर्मे से ऑप्रेशन ', '1-B-5', 'Sukhria Nagar', 19, 1);
INSERT INTO `doctor` VALUES(5, 10, 5, 'Dr Ramawatar Dayama', '8740083400', 'dr.ramawatardayama@gmail.com', 'M.S. (ENT)', 200, '', '10:00 AM TO 3.00 PM\r\n5.00 PM TO 7.00 PM', '10:00 AM TO 3.00 PM\r\n5.00 PM TO 7.00 PM', '88', 'Purani Abadi , ward no 10', '14397264311439726560.jpg', 'Dayama hospital', 'कान के परदे का बिना टांके का ऑप्रेशन\r\nचक्कर , एलर्जी, एंडोस्कोपी स्पेसलिस्ट ', '120-121 ', 'Sukhria Shoping Center', 19, 1);
INSERT INTO `doctor` VALUES(6, 15, 1, 'Dr. SATYAM SHARMA', '9929980176', 'drsatyamsharma@yahoo.com', 'Mch. UROLOGIST & TRANSPLANT SURGEON', 300, '08:00:00', '10:00:00', '05:00:00', '8-A-20', 'JAWAHAR NAGAR', '14395351351439535585.jpg', 'AASTHA KIDNEY & GENERAL HOSPITAL', 'ALL UROLOGICAL SURGERIES\r\nGENERAL SURGERIES\r\nKIDNEY TRANSPLANT & DIALYSIS', '2-D-1', 'SUKHARIA NAGAR', 19, 1);
INSERT INTO `doctor` VALUES(7, 15, 2, 'Dr. SATYAM SHARMA', '9929980176', 'drsatyamsharma@yahoo.com', 'Mch. UROLOGIST & TRANSPLANT SURGEON', 300, '08:00:00', '10:00:00', '05:00:00', '8-A-20', 'JAWAHAR NAGAR', '14395351351439535585.jpg', 'AASTHA KIDNEY & GENERAL HOSPITAL', 'ALL UROLOGICAL SURGERIES\r\nGENERAL SURGERIES\r\nKIDNEY TRANSPLANT & DIALYSIS', '2-D-1', 'SUKHARIA NAGAR', 19, 1);
INSERT INTO `doctor` VALUES(8, 15, 3, 'Dr. SATYAM SHARMA', '9929980176', 'drsatyamsharma@yahoo.com', 'Mch. UROLOGIST & TRANSPLANT SURGEON', 300, '08:00:00', '10:00:00', '05:00:00', '8-A-20', 'JAWAHAR NAGAR', '14395351351439535585.jpg', 'AASTHA KIDNEY & GENERAL HOSPITAL', 'ALL UROLOGICAL SURGERIES\r\nGENERAL SURGERIES\r\nKIDNEY TRANSPLANT & DIALYSIS', '2-D-1', 'SUKHARIA NAGAR', 19, 1);
INSERT INTO `doctor` VALUES(9, 5, 2, 'DR K.K. JAKHAR', '9414509926', 'drkkjakhar98@gmail.com', 'MS ORTHO\r\nSPL BONE & JOINT', 100, '00:00:00', '12:00:00', '08:00:00', 'G-5', 'MODEL TOWN I', '14397156921439716075.jpg', 'DR K K JAKHAR HOSPITAL', 'O.P.D.\r\nPLASTERS\r\nX RAY\r\nMEDICAL STORE', 'G-5', 'MODEL TOWN I', 19, 1);
INSERT INTO `doctor` VALUES(10, 5, 3, 'DR ASHISH CHHABRA', '9414209915', '', 'DNB ORTHO\r\nCONSULTANT ORTHOPAEDICS SURGEON', 200, '00:00:00', '10:00:00', '00:00:00', '3/101 ', 'HOUSING BOARD', '', 'TANTIA GENERAL HOSPITAL', 'TRAUMA CARE\r\nARTHROSCOPY\r\nC-ARM\r\nKNEE & HIP REPLACEMENT', '', 'SUKHARIA MARG', 19, 1);
INSERT INTO `doctor` VALUES(11, 5, 4, 'SUBHASH RAJOTIA', '9829071881', 'dr.subhashrajotia@gmail.com', 'MS ORTHO \r\nBONE & JOINT SPECIALIST', 100, '00:00:00', '10:00:00', '00:00:00', 'F 13-14', 'MODEL TOWN', '', 'RAJOTIA HOSPITAL', 'COMPLETE MODULAR STEEL OPERATION THEATER FOR JOINT REPLACEMENT\r\nARTHROSCOPY\r\nFACILITY OF PHYSIOTHERAPIST\r\n', 'F 13-14 ', 'Model Town', 19, 1);
INSERT INTO `doctor` VALUES(12, 12, 1, 'DR AMIT GOYAL', '8764320199', 'dramitgoyal24@gmail.com', 'DM GASTROENTEROLOGY\r\n', 250, '', '', '', 'VATSALYA RC 11-12', 'RIDHI- SIDHI I   HANUMANGARH ROAD', '14395404811439540925.jpg', 'GANGARAM BANSAL SUPERSPECIALITY HOSPITAL', 'MULTISPECIALITY HOSPITAL & TRAUMA CENTRE\r\nGASTROENTEROLOGY\r\nRADIOLOGY\r\nICU OT\r\nNEUROSURGERY\r\nMEDICINE\r\nDERMATOLOGY', 'MEERA MARG', 'JAWAHAR NAGAR', 19, 1);
INSERT INTO `doctor` VALUES(13, 7, 1, 'DR SANDEEP CHAUHAN', '9414093355', 'drsandeepdm@yahoo.com', 'DM NEPHROLOGY', 300, '', '', '', '2-D-1 ', 'SUKHADIA NAGAR', '14397222681439722436.jpg', 'AASTHA KIDNEY & GENERAL HOSPITAL', '', '2-D-1', 'SUKHARIA NAGAR', 19, 1);
INSERT INTO `doctor` VALUES(14, 6, 5, 'DR NEERAJ MITTAL', '9829906025', '', 'MBBS, MS, Mch', 300, '', '9ː 00 AM TO 5ː00 PM', '9ː AM TO 1ː00 PM', '7-A-30', 'JAWAHAR NAGAR', '14397932331439793453.JPG', 'BAHL HOSPITAL', 'PLASTIC & RECONSTRUCTIVE SURGEON\r\n', 'HANUANGARH ROAD', '', 19, 1);
INSERT INTO `doctor` VALUES(15, 1, 2, 'DR L.D. BHARADWAJ', '9414093989', 'drldbh@gmail.com', 'MD PHYSICIAN\r\nGOLD MEDALIST', 200, '3ː00 PM TO 6ː00 PM', '9ː00 AM TO 1ː00 PM', '', '5-K-1 ', 'JAWAHAR NAGAR', '14397150161439715301.jpg', 'JINDAL HOSPITAL', 'ICU\r\nX RAY\r\nTMT\r\nPATHOLOGY LAB\r\nSPIROMETERY\r\nAUDIOMETERY\r\nINDOOR', '4-E-1', 'JAWAHAR NAGAR', 19, 1);
INSERT INTO `doctor` VALUES(16, 1, 3, 'DR ARUN KALRA', '9414088777', 'arun_kalra@rediffmail.com', 'MD (MEDICINE) PHYSICIAN\r\nCARDIAC & RESPIRATORY DISEASES', 300, '9ː30 AM TO 2ː00 PM', '', '', '82', 'L BLOCK', '14397145931439714959.jpg', '', '', '', '', 19, 1);
INSERT INTO `doctor` VALUES(17, 1, 4, 'DR RAKESH GOYAL', '', 'rgoyal62@gmail.com', 'MD PHYSICIAN', 200, '', '10ː00 AM TO 3ː00 PM                                 5ː00 PM TO 6ː00 PM', '', '.', '.', '14397168231439717029.jpg', 'GOYAL HOSPITAL', 'INDOOR\r\nLABORATORY', 'OPP RAILWAY  STATION', '', 19, 1);
INSERT INTO `doctor` VALUES(18, 1, 1, 'DR ATUL GUPTA', '9814229730,9783739730', 'atulgpt87@gmail.com', 'MD PHYSICIAN', 200, '', '9ː30 AM TO 2ː30 PM           5ː00 PM TO 7ː00 PM', '10ː00 AM TO 12ː00 PM', '1-A-11', 'SUKHARIA NAGAR', '', 'ARPAN HOSPITAL', 'ICU\r\nECG\r\nTMT\r\nX RAY\r\nSPIROMETERY\r\nBRONCHOSCOPY\r\nGESTROSCOPY\r\nLABORATORY', '1 B 2 ', 'SUKHARIA NAGAR', 19, 1);
INSERT INTO `doctor` VALUES(19, 1, 5, 'DR SHVETA GARG', '7742293842', 'drshvetagarg@gmail.com', 'MD PHYSICIAN', 150, '', '10ː30 AM TO 3ː30 PM', '10ː30 AM TO 1ː00 PM', '180 ', 'AGRSEN ANAGR', '', 'SANJIVNI HOSPITAL', 'ICU\r\nLABORATORY\r\nECG\r\nEEG\r\nWELL FURNISHED ROOMS', 'GAGAN PATH ', '', 19, 1);
INSERT INTO `doctor` VALUES(20, 10, 6, 'DR RAMESH CHANDER JINDAL', '9414088789', 'jindalenthospital@gmail.com', 'M.S. E.N.T.', 200, '', '10ː00 AM TO 6ː00 PM', '11ː00 AM TO 01ː00 PM', '4-E-1 ', '  II FLOOR , JAWAHAR NAGAR', '', 'JINDAL E.N.T. HOSPITAL & MEDICAL RESEARCH CENTRE', 'X-RAY\r\nAUDIOMETORY\r\nBERA\r\n', '4-E-1', 'JAWAHAR NAGAR', 19, 1);
INSERT INTO `doctor` VALUES(21, 1, 6, 'DR PRAHLAD GUPTA', '9352700918', 'sandeepsaincnh@gmail.com', 'MD PHYSICIAN', 200, '', '9ː00 AM TO 3ː00 PM             5ː00 PM TO 8ː00 PM', '9ː00 AM TO 3ː00 PM', '31', 'N BLOCK', '', 'CHANDIGARH NURSING HOME', 'OPD\r\nINDOOR\r\nLABORATORY\r\nEECP - CARDIAC NONMVASIVE REVASCULARISATION \r\nFREE KITCHEN SERVICE FOR PATIENT & ONE ATTENDANT', '46 E BLOCK', 'SITLA PARK', 19, 1);
INSERT INTO `doctor` VALUES(22, 17, 1, 'DR NEHA KHUNGER', '9782919000', 'neha.gandhi24@gmail.com', 'BDS, MIDA\r\nDENTAL SURGEON', 50, '', '10ː00 AM TO 2ː00 PM          5ː00 PM TO 8ː00 PM', '', 'INDIRA COLONY', 'STREET NO 10', '14397419211439742305.jpg', 'DR KHUNGERS DENTAL & GENERAL HEALTH CARE', 'ALL TYPE OF DENTAL TREATMENT', 'KHURANA PALACE ROAD', 'INDIRA COLONY STREET NO 10 ', 19, 1);
INSERT INTO `doctor` VALUES(23, 17, 2, 'DR. HIMANSHU GUPTA', '9799744464,01542471464', 'himanshudr2th@gmail.com', 'MDS\r\n CONSULTANT PROSTHODONTIST & IMPLANTOLOGIST', 150, '10ː00 AM TO 1ː00 PM', '4ː00 PM TO 7ː00 PM', '10ː00 AM TO 1ː00 PM', '32', 'B BLOCK', '14397024341439702535.jpg', 'L.D''S DENTAL & IMPLANT CARE', 'IMPLANTS\r\nFIXED TEETH\r\nCOSMETICS\r\nPEDIATRIC DENTISTRY\r\nADVANCED RCT', '32 B BLOCK', '', 19, 1);
INSERT INTO `doctor` VALUES(24, 26, 1, 'DR SANJEEV KUMAR CHUGH', '7891591872', 'drsanjeevtbcd@yahoo.com', 'MD CHEST & TB', 200, '', '9ː00 AM TO 3ː00 PM\r\n5ː00 PM TO 7ː00 PM', '10ː00AM TYO 2ː00 PM', '125', 'L BLOCK , NEAR HANUMAN MANDIR', '14397064161439706916.jpg', 'SANJIVNI CHEST HOSPITAL', 'PFT\r\nBIPAP\r\nCDAP\r\nOXYGEN\r\nALL CHEST RELATIVE PROCEDURE ', '3/111 HOUSING BOARD', 'OPP GUPTA NURSING HOME', 19, 1);
INSERT INTO `doctor` VALUES(25, 6, 6, 'DR.P.S. KHURANA', '9351464777 , 01542460460,01542460560', 'drpskhurana@gmail.com', 'MS', 200, '', '11ː00 AM T0 2ː00 PM\r\n5ː30 PM TO 7ː30 PM', '11ː00 AM TO 2ː00 PM', '7-J-2', 'JAWAHAR NAGAR, MEERA MARG', '', 'SIHAG HOSPITAL', 'OPERATION THEATRE\r\nLAPAROSCOPIC SURGERY\r\nUROLOGY\r\nCANCER SURGERY\r\nICU\r\nULTRASOUND\r\nLAB.', '2 A 18-19 ', 'JAWAHAR NAGAR', 19, 1);
INSERT INTO `doctor` VALUES(26, 9, 4, 'DR RAJESH CHALANA', '9414953200,01542462102', 'drrajeshchalana@yahoo.com', 'MS OPTHO', 200, '', '10ː00 AM TO 7ː00 PM', '', '5-M-19', 'JAWAHAR NAGAR', '14397256651439725970.jpg', 'NAYAN MANDIR - ANAKHO KA HASPATAL PHACO & RATINA CENT', 'ALL FACALITIES AS CAT.OP., SEQUENT\r\nOP, EXAMINATION WITH LATEST MDC', '5-M-19', 'JAWAHAR NAGAR', 19, 1);
INSERT INTO `doctor` VALUES(27, 20, 1, 'DR .MANOJ DUA', '9610298635,8946824445,01542461888', 'drmanojdua49@gmail.com', 'MCH PAEDIATRICS', 250, '', '10ː00 AM to 3ː00 PM\r\n5ː00 PM TO 7ː00 PM\r\n', '10ː00 AM TO 2ː00 PM', '6-C PREM NAGAR', 'NEAR PAYAL CINEMA', '14397427101439742891.jpg', 'DUA HOSPITAL', 'MODREN SNICU & OPERATION THEATRE\r\nVENTILATOR\r\nGENERAL WARD & A.C. PRIVATE ROOMS\r\nLAB AND PHARMACY\r\n24 EMERGENCY SERVICE', '102-103 VRINDAVAN VIHAR, GAGAN PATH', 'NEAR SHIAG HOSPITAL', 19, 1);
INSERT INTO `doctor` VALUES(28, 4, 3, 'DR PRITPAL SINGH CHUGH', '9414281952,01542471852,01542471853', 'drpschugh@gmail.com', 'D.C.H. , MD PEDIATRICS\r\nCHILD SPECIALIST', 200, '', '10ː00 AM  TO 2ː00 PM\r\n5ː00 PM TO 8ː00 PM ', '10ː00 AM TO 2ː00 PM', '144 ', 'H BLOCK', '14397062001439706461.jpg', 'CHUGH HOSPITAL', '', '148', 'H BLOCK', 19, 1);
INSERT INTO `doctor` VALUES(29, 10, 1, 'DR MANOJ MITTAL', '9414088551', 'mittalmk551@gmail.com', 'MS ENT & FACIOMAXILLARY SURGEON', 200, '', '', '', '', '', '', 'AANCHAL HOSPITAL', '', '3-B-4  JAWAHAR NAGAR', 'NEAR PRATAP KESRI OFFICE', 19, 1);
INSERT INTO `doctor` VALUES(30, 2, 1, 'DR ROOP SIDANA', '9414087359 ,01542472359,01542486389', 'drroop67@gmail.com', 'MD PSYCHIATRIST & DEADDICTION', 250, '', '10ː00 AM TO 6ː00 PM\r\n', '', '', '', '', 'TEK CHAND SIDANA MEMORIAL PSYCHIATRIC HOSPITAL & DE ADDICTION CENTRE', 'rTMS\r\nEEG & BRAIN MAPPING\r\nSEX THERAPY\r\nECG MACHINE\r\nMULTI BEHAVOUR THERAPY', '1-B-4 SUKHARIA NAGAR', '', 19, 1);
INSERT INTO `doctor` VALUES(31, 2, 2, 'DR SANTOSH KUMAR TRIPATHI', '9414658256', 'drsktripathi@yahoo.com', 'CLINICAL PSYCHOLOGIST', 200, '8ː00 AM TO 10ː00 AM\r\n5ː00PM TO 8ː00 PM', '10ː00 AM TO 5ː00 PM\r\n', '12ː00 AM TO 2ː00 PM', '', '', '', 'TANTIA GENERAL HOSPITAL', 'EEG\r\nMRI\r\nCT SCAN\r\nECCHO\r\nVENTILATOR\r\nMODULAR ICU\r\nTAT & I.Q. TEST\r\nX RAY\r\nLAB & PHARMACY', 'SUKHARIA MARG', '', 19, 1);
INSERT INTO `doctor` VALUES(32, 17, 1, 'DR NEHA GUPTA', '9887047551', 'himanshudr2th@gmail.com', 'PREVENTIVE AND PEDIATRIC DENTISTRY', 150, '10ː00 TO 1ː00 PM', '4ː00 PM TO 7ː00 PM', '10ː00 AM TO 1ː00 PM', '', '', '14397098691439710112.jpg', 'L.D. MULTISPECIALITY DENTAL AND IMPLANT CARE', 'PEDIATRICS DENTISTRY LASER, COSMETICS ADAVANCED RCT', '32 B BLOCK', '', 19, 1);
INSERT INTO `doctor` VALUES(33, 13, 1, 'DR SUNIL BENIWAL', '9214556002', 'drsunilsms@gmail.com', 'DM CARDIOLOGIST', 500, '', '9ː00 AM TO 5ː00 PM', '', '103 RAJKIYA AWAS, NEAR TRIMURTI APARTMENT', 'MODEL TOWN ,MALVIYA NAGAR ', '14397103261439710676.JPG', 'FORTIS ESCORT HOSPITAL JAIPUR & SRI GANGANAGAR', 'CATH LAB\r\nCCU\r\nPACEMAKER\r\nANGIOPLASTY', '', '', 19, 6);
INSERT INTO `doctor` VALUES(34, 17, 3, 'DR NEEL GAGAN', '9414955762', 'drneel83@gmail.com', 'B.D.S DENTAL SURGEON', 100, '', '10ː00 AM TO 2ː00 PM\r\n4ː00 PM TO 8ː00 PM', '10ː00 AM TO 2ː00 PM', '161', 'VINOBA BASTI', '', 'DR.NEEL''S DENTAL CLINIC', 'RCT\r\nORTHODONTICS\r\nIMPLANT\r\nDENTURE FIXED TEETH \r\nETC.', '161', 'VINOBA BASTI', 19, 1);
INSERT INTO `doctor` VALUES(35, 17, 4, 'DR ATUL AGGARWAL', '9887677927', 'atulaggarwaldr@gmail.com', 'B.D.S.', 100, '', '10ː00 AM TO 2ː00 PM\r\n5ː00 PM TO 8ː00 PM', '10ː00 AM TO 2ː00 PM', '1', 'VRINDAVAN VIHAR , GAGANT PATH', '', 'FAMILY DENTAL CARE', 'ULTRASONIC ROOT CANAL TREATMENT\r\nALL TYPE OF DENTAL TREATMENT', '2-C-10', 'JAWAHAR NAGAR', 19, 1);
INSERT INTO `doctor` VALUES(36, 17, 5, 'DR GOVIND KANT', '9414332999', 'doc_govind@yahoo.com', 'BDS DENTAL SURGEON\r\n', 100, '', '10ː00 AM TO 2ː30 PM\r\n 5ː00 PM TO 8ː00 PM', '', '124', 'H BLOCK', '', '', 'ALL TYPE OF DENTAL TREATMENTS\r\n', '124 ', 'H BLOCK', 19, 1);
INSERT INTO `doctor` VALUES(37, 10, 2, 'DR MANOJ MITTAL', '9414088551', 'mittalmk551@gmail.com', ' MS ENT MICRO EAR AND ENDOSCOPIC NASAL SURGEON\r\n', 200, '', '11ː00 AM TO 2ː00 PM\r\n6ː30 PM TO 7ː30 PM', '', '', '', '', 'ANCHAL HOSPITAL', 'OT\r\nICU\r\nWARD\r\nLAB\r\nCANTEEN\r\n', '3-B ', 'JAWAHAR NAGAR', 19, 1);
INSERT INTO `doctor` VALUES(38, 17, 6, 'DR. PARAMPAL SINGH  DHILLON', '9001248784', 'drjasvinder30@gmail.com', 'DENTAL SURGEON\r\n', 100, '8ː30 AM TO 10ː00 AM\r\n7ː00 PM TO 8ː00 PM', '9ː00 AM TO 7ː00 PM', '10ː00 AM TO 2ː00 PM', '301', 'SECTOR NO 1 HOUSING BOARD JAWAHAR NAGAR', '', 'PARBRAHMA DENTAL CLINIC', 'SINGLE SITTING RCT\r\nCOSMETIC FILLINGS\r\nSCALING & CURRETAGE\r\nFIXED PROSTHESIS.\r\n50 RS FEES ON EVERY TUES DAY\r\n', ' 132 ', 'SUKHARIA SHOPPING CENTER', 19, 1);
INSERT INTO `doctor` VALUES(39, 1, 7, 'DR RAKESH BAWEJA', '9414088606', 'dr.rakeshbaweja@yahoo.com', 'MD MEDICINE\r\n', 300, '', '10ː00 AM TO 2ː00 PM\r\n5ː00 PM TO 7ː00 PM', 'ONLY EMERGENCY', '142', 'P BLOCK', '', 'SHRI GOVINDAM MULTI SPECIALITY HOSPITAL', 'ICU\r\nOT\r\nSURGERY\r\nMEDICINE\r\nGYN\r\nDENTAL\r\nLAB\r\nMEDICAL STORE AND 24 HRS EMERGENCY FACILITIES.\r\nFEES 150 Rs FOR POOR PATIENT & FOR BPL FREE\r\n', '142', 'P BLOCK', 19, 1);
INSERT INTO `doctor` VALUES(40, 3, 1, 'UPASNA SETIA', '9414246596', 'upasna_kamra@yahoo.com', 'OBSTETRICIAN AND GYNECOLOGIST\r\n', 200, '', '10ː00 AM TO 7ː00 PM', '11ː00 AM TO 4ː00 PM', '1-E-30', 'SUKHARIA NAGAR', '', 'DIVOJ HOSPITAL', 'FULLY AC OT\r\nWARD\r\nDELIVERY\r\nPAINLESS DELIVERY \r\nANTENATAL CARE\r\nMTP , FAMILY PLANING\r\nLABOUR ROOM\r\nALL KIND OF OPERATIONS RELATED TO GYNECOLOGY\r\n\r\n', '1-E-30', 'SUKHARIA NAGAR', 19, 1);
INSERT INTO `doctor` VALUES(41, 17, 7, 'DR ADITYA MARKANDAY', '9828388889', 'aditya_dentist@yahoo.com', 'DENTIST\r\n', 200, '', '9ː00 AM TO 2ː00 PM\r\n5ː00 PM TO 7ː00 PM', '', '2-B-18', 'SUKHARIA NAGAR', '14398105151439810993.jpg', 'BAHL HOSPITAL', 'DENTAL IMPLANTS\r\nSINGLE VISIT ROOT CANAL TREATMENT\r\nBLEACHING\r\nCOSMETICS DENTISTRY\r\nORTHODONTIC TREATMENT\r\n', 'CHAL CHOWK , NEAR PETROL PUMP', 'HANUMANGARH ROAD', 19, 1);
INSERT INTO `doctor` VALUES(42, 17, 8, 'DR SANJAY JASUJA', '9828358004', 'jasujatooth@gmail.com', 'DENTIST\r\n', 100, '', '10ː00 AM TO 2ː30 PM\r\n4ː00 PM TO 8ː00 PM', 'ON APPOINTMENT', '5-B-14', 'JAWAHAR NAGAR', '', 'JASUJA CLINIC', 'CORRECTION OF MALALIGNED TEETH\r\nIMPLANTS\r\n', '118-119 SUKHARIA SHOPING CENTER', '', 19, 1);
INSERT INTO `doctor` VALUES(43, 17, 9, 'DR SHALINI MARKANDAY', '9799332266', 'shalini786v@gmail.com', 'DENTIST', 200, '10ː00 AM TO 7ː00 PM', '10ː00 AM TO 7ː00 PM', '11ː00 AM TO 2ː00 PM', '2-B-18', 'SUKHARIA NAGAR', '', '2-B-18', 'DENTAL IMPLANTS\r\nSINGLE VISIT ROOT CANAL TREATMENT\r\nBLEACHING\r\nCOSMETICS DENTISTRY\r\nORTHODONTIC TREATMENT.\r\n', 'SUKHARIA NAGAR', '', 19, 1);

-- --------------------------------------------------------

--
-- Table structure for table `doctor_category`
--

CREATE TABLE `doctor_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=27 ;

--
-- Dumping data for table `doctor_category`
--

INSERT INTO `doctor_category` VALUES(1, 'Physician');
INSERT INTO `doctor_category` VALUES(2, 'Psychiatrist');
INSERT INTO `doctor_category` VALUES(3, 'Gynecologist');
INSERT INTO `doctor_category` VALUES(4, 'Pediatrician');
INSERT INTO `doctor_category` VALUES(5, 'Orthopedician');
INSERT INTO `doctor_category` VALUES(6, 'Surgeon');
INSERT INTO `doctor_category` VALUES(7, 'Nephrologist');
INSERT INTO `doctor_category` VALUES(8, 'Neurologist');
INSERT INTO `doctor_category` VALUES(9, 'Ophthalmologist');
INSERT INTO `doctor_category` VALUES(10, 'ENT Specialist');
INSERT INTO `doctor_category` VALUES(11, 'Dermatologist');
INSERT INTO `doctor_category` VALUES(12, 'Gastroenterologist');
INSERT INTO `doctor_category` VALUES(13, 'Cardiologist');
INSERT INTO `doctor_category` VALUES(14, 'Endocrinologist');
INSERT INTO `doctor_category` VALUES(15, 'Urologist');
INSERT INTO `doctor_category` VALUES(16, 'Oncologist');
INSERT INTO `doctor_category` VALUES(17, 'Dentist');
INSERT INTO `doctor_category` VALUES(18, 'General Practitioner');
INSERT INTO `doctor_category` VALUES(19, 'Diagnostic Laboratory');
INSERT INTO `doctor_category` VALUES(20, 'Pediatric Surgeon');
INSERT INTO `doctor_category` VALUES(21, 'Blood bank');
INSERT INTO `doctor_category` VALUES(22, 'Physiotherapist');
INSERT INTO `doctor_category` VALUES(23, 'Ayurvedic');
INSERT INTO `doctor_category` VALUES(24, 'Homeopathy');
INSERT INTO `doctor_category` VALUES(25, 'Veterinanian');
INSERT INTO `doctor_category` VALUES(26, 'Chest Physician');

-- --------------------------------------------------------

--
-- Table structure for table `holidays`
--

CREATE TABLE `holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doc_id` int(11) NOT NULL,
  `sunday` int(11) NOT NULL,
  `monday` int(11) NOT NULL,
  `tuesday` int(11) NOT NULL,
  `wednesday` int(11) NOT NULL,
  `thursday` int(11) NOT NULL,
  `friday` int(11) NOT NULL,
  `saturday` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=74 ;

--
-- Dumping data for table `holidays`
--

INSERT INTO `holidays` VALUES(6, 6, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `holidays` VALUES(7, 7, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `holidays` VALUES(8, 8, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `holidays` VALUES(10, 10, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(11, 11, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(18, 18, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(19, 19, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(21, 21, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(25, 23, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(27, 25, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(29, 2, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(31, 28, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(32, 24, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(33, 29, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(34, 30, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(35, 31, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(38, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(39, 32, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(40, 33, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(43, 34, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(44, 35, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(45, 12, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(46, 16, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(48, 9, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(50, 17, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(51, 4, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(52, 13, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(53, 3, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(54, 26, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(55, 5, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(56, 20, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(57, 15, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(59, 22, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(62, 27, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(63, 36, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(64, 37, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(65, 38, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(66, 39, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(68, 40, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(69, 14, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(71, 42, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(72, 43, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `holidays` VALUES(73, 41, 1, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=37 ;

--
-- Dumping data for table `state`
--

INSERT INTO `state` VALUES(1, 'ANDHRA PRADESH');
INSERT INTO `state` VALUES(2, 'ASSAM');
INSERT INTO `state` VALUES(3, 'ARUNACHAL PRADESH');
INSERT INTO `state` VALUES(4, 'BIHAR');
INSERT INTO `state` VALUES(5, 'GUJRAT');
INSERT INTO `state` VALUES(6, 'HARYANA');
INSERT INTO `state` VALUES(7, 'HIMACHAL PRADESH');
INSERT INTO `state` VALUES(8, 'JAMMU & KASHMIR');
INSERT INTO `state` VALUES(9, 'KARNATAKA');
INSERT INTO `state` VALUES(10, 'KERALA');
INSERT INTO `state` VALUES(11, 'MADHYA PRADESH');
INSERT INTO `state` VALUES(12, 'MAHARASHTRA');
INSERT INTO `state` VALUES(13, 'MANIPUR');
INSERT INTO `state` VALUES(14, 'MEGHALAYA');
INSERT INTO `state` VALUES(15, 'MIZORAM');
INSERT INTO `state` VALUES(16, 'NAGALAND');
INSERT INTO `state` VALUES(17, 'ORISSA');
INSERT INTO `state` VALUES(18, 'PUNJAB');
INSERT INTO `state` VALUES(19, 'RAJASTHAN');
INSERT INTO `state` VALUES(20, 'SIKKIM');
INSERT INTO `state` VALUES(21, 'TAMIL NADU');
INSERT INTO `state` VALUES(22, 'Telangana');
INSERT INTO `state` VALUES(23, 'TRIPURA');
INSERT INTO `state` VALUES(24, 'UTTAR PRADESH');
INSERT INTO `state` VALUES(25, 'WEST BENGAL');
INSERT INTO `state` VALUES(26, 'DELHI');
INSERT INTO `state` VALUES(27, 'GOA');
INSERT INTO `state` VALUES(28, 'PONDICHERY');
INSERT INTO `state` VALUES(29, 'LAKSHDWEEP');
INSERT INTO `state` VALUES(30, 'DAMAN & DIU');
INSERT INTO `state` VALUES(31, 'DADRA & NAGAR');
INSERT INTO `state` VALUES(32, 'CHANDIGARH');
INSERT INTO `state` VALUES(33, 'ANDAMAN & NICOBAR');
INSERT INTO `state` VALUES(34, 'UTTARANCHAL');
INSERT INTO `state` VALUES(35, 'JHARKHAND');
INSERT INTO `state` VALUES(36, 'CHATTISGARH');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` VALUES(1, 'jaspal singh', 'jaspals', '5f4dcc3b5aa765d61d8327deb882cf99');
INSERT INTO `user` VALUES(2, 'vikrant sharma', 'vikrant.s', '3dc1e4c3bc5b2ae63520627ea44df7fd');
