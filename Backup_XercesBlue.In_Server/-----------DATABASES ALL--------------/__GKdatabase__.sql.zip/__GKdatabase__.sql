-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: 166.62.8.46
-- Generation Time: Aug 22, 2015 at 03:27 AM
-- Server version: 5.5.43
-- PHP Version: 5.1.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `GKdatabase`
--
CREATE DATABASE `GKdatabase` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `GKdatabase`;

-- --------------------------------------------------------

--
-- Table structure for table `Turorials`
--

CREATE TABLE `Turorials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CatId` int(11) NOT NULL,
  `text` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `LangId` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `reference` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `userid` int(11) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `Turorials`
--


-- --------------------------------------------------------

--
-- Table structure for table `app_table`
--

CREATE TABLE `app_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `app_table`
--

INSERT INTO `app_table` VALUES(1, 'Bank PO');
INSERT INTO `app_table` VALUES(2, 'SSC EXAM');
INSERT INTO `app_table` VALUES(3, 'GATE EXAM');
INSERT INTO `app_table` VALUES(4, 'Bank Clerical');
INSERT INTO `app_table` VALUES(5, 'GK');
INSERT INTO `app_table` VALUES(6, 'only Bank po');

-- --------------------------------------------------------

--
-- Table structure for table `category_table`
--

CREATE TABLE `category_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `AppId` int(11) NOT NULL,
  `parentId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `category_table`
--

INSERT INTO `category_table` VALUES(1, 'Reasoning', 1, 0);
INSERT INTO `category_table` VALUES(2, 'English', 1, 0);
INSERT INTO `category_table` VALUES(3, 'Math', 1, 0);
INSERT INTO `category_table` VALUES(4, 'Gk', 1, 0);
INSERT INTO `category_table` VALUES(5, 'Computer', 1, 0);
INSERT INTO `category_table` VALUES(6, 'Sitting Arrangement', 1, 1);
INSERT INTO `category_table` VALUES(7, 'Tabulation', 1, 1);
INSERT INTO `category_table` VALUES(8, 'Logical Reasoning', 1, 1);
INSERT INTO `category_table` VALUES(9, 'Syllogism', 1, 1);
INSERT INTO `category_table` VALUES(10, 'Blood Relations', 1, 1);
INSERT INTO `category_table` VALUES(11, 'Input Output', 1, 1);
INSERT INTO `category_table` VALUES(12, 'Coding Decoding', 1, 1);
INSERT INTO `category_table` VALUES(13, 'Alphanumeric Series', 1, 1);
INSERT INTO `category_table` VALUES(14, 'Ranking', 1, 1);
INSERT INTO `category_table` VALUES(15, 'Direction', 1, 1);
INSERT INTO `category_table` VALUES(16, 'Data sufficiency', 1, 1);
INSERT INTO `category_table` VALUES(17, 'Coded Inequalities', 1, 1);
INSERT INTO `category_table` VALUES(18, 'puzzle', 1, 1);
INSERT INTO `category_table` VALUES(19, 'Reading Comprehension', 1, 2);
INSERT INTO `category_table` VALUES(20, 'Antonyms', 1, 2);
INSERT INTO `category_table` VALUES(21, 'Grammatical Error', 1, 2);
INSERT INTO `category_table` VALUES(22, 'Fill in the Blanks', 1, 2);
INSERT INTO `category_table` VALUES(23, 'Synonyms', 1, 2);
INSERT INTO `category_table` VALUES(24, 'Sentence Rearrangement', 1, 2);
INSERT INTO `category_table` VALUES(25, 'Simplification', 1, 3);
INSERT INTO `category_table` VALUES(26, 'Number System', 1, 3);
INSERT INTO `category_table` VALUES(27, 'Ratio & proportion', 1, 3);
INSERT INTO `category_table` VALUES(28, 'Percentage', 1, 3);
INSERT INTO `category_table` VALUES(29, 'Average', 1, 3);
INSERT INTO `category_table` VALUES(30, 'Profit & loss', 1, 3);
INSERT INTO `category_table` VALUES(31, 'Mixture & Alligation', 1, 3);
INSERT INTO `category_table` VALUES(32, 'Simple Intrest', 1, 3);
INSERT INTO `category_table` VALUES(33, 'Compound Intrest', 1, 3);
INSERT INTO `category_table` VALUES(34, 'Work & time', 1, 3);
INSERT INTO `category_table` VALUES(35, 'Time & Distance', 1, 3);
INSERT INTO `category_table` VALUES(36, 'Mensuration', 1, 3);
INSERT INTO `category_table` VALUES(37, 'Permutation', 1, 3);
INSERT INTO `category_table` VALUES(38, 'Combination', 1, 3);
INSERT INTO `category_table` VALUES(39, 'Probability', 1, 3);
INSERT INTO `category_table` VALUES(40, 'Data Interpretion', 1, 3);
INSERT INTO `category_table` VALUES(41, 'Banking Awareness', 1, 4);
INSERT INTO `category_table` VALUES(42, 'Current Affairs', 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `dataentryusers`
--

CREATE TABLE `dataentryusers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `dataentryusers`
--

INSERT INTO `dataentryusers` VALUES(11, 'pankaj', 'pankaj', 'pankaj');
INSERT INTO `dataentryusers` VALUES(10, 'user1', 'user1', 'user1');
INSERT INTO `dataentryusers` VALUES(3, 'admin', 'admin', 'admin');
INSERT INTO `dataentryusers` VALUES(4, 'jaspal', 'jaspal', 'jaspal');

-- --------------------------------------------------------

--
-- Table structure for table `language`
--

CREATE TABLE `language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Lang` text COLLATE utf8_unicode_ci NOT NULL,
  `Code` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `language`
--

INSERT INTO `language` VALUES(1, 'English', 'en');
INSERT INTO `language` VALUES(2, 'Hindi', 'hi');
INSERT INTO `language` VALUES(3, 'Punjabi', 'pa');
INSERT INTO `language` VALUES(4, 'Bangla', 'bn');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `OptionId` int(11) NOT NULL AUTO_INCREMENT,
  `QuesId` int(11) NOT NULL,
  `OptionText` text COLLATE utf8_unicode_ci,
  `OptionNo` int(11) NOT NULL,
  `image` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`OptionId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=214 ;

--
-- Dumping data for table `options`
--

INSERT INTO `options` VALUES(1, 1, 'Violates their property rights', 1, '');
INSERT INTO `options` VALUES(2, 1, 'Get compensation as free or ultra-cheap land', 2, '');
INSERT INTO `options` VALUES(3, 1, 'Land ownership is a big status issue in villages', 3, '');
INSERT INTO `options` VALUES(4, 1, 'Land ownership helps to attract desirable grooms for daughters', 4, '');
INSERT INTO `options` VALUES(5, 1, 'All of the Above', 5, '');
INSERT INTO `options` VALUES(6, 2, 'To buy land on market price', 1, '');
INSERT INTO `options` VALUES(7, 2, 'Annuity model', 2, '');
INSERT INTO `options` VALUES(8, 2, 'To buy land as Agricultural land', 3, '');
INSERT INTO `options` VALUES(9, 2, 'To buy land as Industrial Land', 4, '');
INSERT INTO `options` VALUES(10, 3, 'agriculture', 1, '');
INSERT INTO `options` VALUES(11, 3, 'industrial', 2, '');
INSERT INTO `options` VALUES(12, 3, 'both', 3, '');
INSERT INTO `options` VALUES(13, 3, 'either (A) or (B)', 4, '');
INSERT INTO `options` VALUES(18, 5, '100 million hectares', 1, '');
INSERT INTO `options` VALUES(19, 5, '160 million hectares', 2, '');
INSERT INTO `options` VALUES(20, 5, '200 million hectares', 3, '');
INSERT INTO `options` VALUES(21, 5, '800 million hectares', 4, '');
INSERT INTO `options` VALUES(22, 6, 'authority', 1, '');
INSERT INTO `options` VALUES(23, 6, 'opponent', 2, '');
INSERT INTO `options` VALUES(24, 6, 'assistant', 3, '');
INSERT INTO `options` VALUES(25, 6, 'friend', 4, '');
INSERT INTO `options` VALUES(26, 7, 'calender', 1, '');
INSERT INTO `options` VALUES(27, 7, 'time table', 2, '');
INSERT INTO `options` VALUES(28, 7, 'efforts', 3, '');
INSERT INTO `options` VALUES(29, 7, 'dated', 4, '');
INSERT INTO `options` VALUES(35, 9, 'A', 1, '');
INSERT INTO `options` VALUES(36, 9, 'B', 2, '');
INSERT INTO `options` VALUES(37, 9, 'C', 3, '');
INSERT INTO `options` VALUES(38, 9, 'D', 4, '');
INSERT INTO `options` VALUES(39, 9, 'E', 5, '');
INSERT INTO `options` VALUES(40, 10, 'A', 1, '');
INSERT INTO `options` VALUES(41, 10, 'B', 2, '');
INSERT INTO `options` VALUES(42, 10, 'C', 3, '');
INSERT INTO `options` VALUES(43, 10, 'D', 4, '');
INSERT INTO `options` VALUES(44, 10, 'E', 5, '');
INSERT INTO `options` VALUES(45, 11, 'A', 1, '');
INSERT INTO `options` VALUES(46, 11, 'B', 2, '');
INSERT INTO `options` VALUES(47, 11, 'C', 3, '');
INSERT INTO `options` VALUES(48, 11, 'D', 4, '');
INSERT INTO `options` VALUES(49, 11, 'E', 5, '');
INSERT INTO `options` VALUES(50, 12, 'A', 1, '');
INSERT INTO `options` VALUES(51, 12, 'B', 2, '');
INSERT INTO `options` VALUES(52, 12, 'C', 3, '');
INSERT INTO `options` VALUES(53, 12, 'D', 4, '');
INSERT INTO `options` VALUES(54, 12, 'E', 5, '');
INSERT INTO `options` VALUES(55, 13, 'A', 1, '');
INSERT INTO `options` VALUES(56, 13, 'B', 2, '');
INSERT INTO `options` VALUES(57, 13, 'C', 3, '');
INSERT INTO `options` VALUES(58, 13, 'D', 4, '');
INSERT INTO `options` VALUES(59, 13, 'E', 5, '');
INSERT INTO `options` VALUES(60, 14, '1', 1, '');
INSERT INTO `options` VALUES(61, 14, '2', 2, '');
INSERT INTO `options` VALUES(62, 14, '3', 3, '');
INSERT INTO `options` VALUES(63, 14, '4', 4, '');
INSERT INTO `options` VALUES(64, 14, '5', 5, '');
INSERT INTO `options` VALUES(65, 15, '1', 1, '');
INSERT INTO `options` VALUES(66, 15, '2', 2, '');
INSERT INTO `options` VALUES(67, 15, '3', 3, '');
INSERT INTO `options` VALUES(68, 15, '4', 4, '');
INSERT INTO `options` VALUES(69, 15, '5', 5, '');
INSERT INTO `options` VALUES(70, 16, '1', 1, '');
INSERT INTO `options` VALUES(71, 16, '2', 2, '');
INSERT INTO `options` VALUES(72, 16, '3', 3, '');
INSERT INTO `options` VALUES(73, 16, '4', 4, '');
INSERT INTO `options` VALUES(74, 16, '5', 5, '');
INSERT INTO `options` VALUES(75, 17, '1', 1, '');
INSERT INTO `options` VALUES(76, 17, '2', 2, '');
INSERT INTO `options` VALUES(77, 17, '3', 3, '');
INSERT INTO `options` VALUES(78, 17, '4', 4, '');
INSERT INTO `options` VALUES(79, 17, '5', 5, '');
INSERT INTO `options` VALUES(80, 18, '1', 1, '');
INSERT INTO `options` VALUES(81, 18, '2', 2, '');
INSERT INTO `options` VALUES(82, 18, '3', 3, '');
INSERT INTO `options` VALUES(83, 18, '4', 4, '');
INSERT INTO `options` VALUES(84, 18, '5', 5, '');
INSERT INTO `options` VALUES(90, 20, 'à¤…à¤¦à¥à¤«à¥à¤¦à¥à¤¸à¥à¤«à¥', 1, '');
INSERT INTO `options` VALUES(91, 20, 'à¤…à¤¸à¥à¤«à¥à¤¸à¥à¤¦à¥à¤«à¥', 2, '');
INSERT INTO `options` VALUES(92, 20, 'à¤…à¤¸à¥à¤«à¥à¤¸à¥à¤¦à¥à¤«à¥', 3, '');
INSERT INTO `options` VALUES(93, 20, 'à¤…à¤¸à¥à¤«à¥à¤¸à¥à¤¦à¥à¤«à¥', 4, '');
INSERT INTO `options` VALUES(94, 21, 'affordability, acceptable taste, emphasising freshness & healthy', 1, '');
INSERT INTO `options` VALUES(95, 21, 'affordability, acceptable taste, nutrition or calorific value, ease of use and ready availability', 2, '');
INSERT INTO `options` VALUES(96, 21, 'acceptable taste, nutrition or calorific value, emphasising freshness & healthy', 3, '');
INSERT INTO `options` VALUES(97, 21, 'emphasising freshness, healthy, attractive packing and ready availability', 4, '');
INSERT INTO `options` VALUES(98, 22, 'resistant it and love to eat', 1, '');
INSERT INTO `options` VALUES(99, 22, 'love to eat and resist it', 2, '');
INSERT INTO `options` VALUES(100, 22, 'never try it and resist it', 3, '');
INSERT INTO `options` VALUES(101, 22, 'try it for once and love to eat', 4, '');
INSERT INTO `options` VALUES(102, 23, 'Maggi, Glucose biscuit and Macroni', 1, '');
INSERT INTO `options` VALUES(103, 23, 'Noddles, Banana and Glucose Biscuit', 2, '');
INSERT INTO `options` VALUES(104, 23, 'Maggi, Banana and Pasta', 3, '');
INSERT INTO `options` VALUES(105, 23, 'Glucose Biscuit, Maggi and Banan', 4, '');
INSERT INTO `options` VALUES(106, 24, '5%', 1, '');
INSERT INTO `options` VALUES(107, 24, '60%', 2, '');
INSERT INTO `options` VALUES(108, 24, '40%', 3, '');
INSERT INTO `options` VALUES(109, 24, '25%', 4, '');
INSERT INTO `options` VALUES(110, 25, '1980', 1, '');
INSERT INTO `options` VALUES(111, 25, '1981', 2, '');
INSERT INTO `options` VALUES(112, 25, '1982', 3, '');
INSERT INTO `options` VALUES(113, 25, '1983', 4, '');
INSERT INTO `options` VALUES(114, 26, 'fast', 1, '');
INSERT INTO `options` VALUES(115, 26, 'recurrent', 2, '');
INSERT INTO `options` VALUES(116, 26, 'slow', 3, '');
INSERT INTO `options` VALUES(117, 26, 'most', 4, '');
INSERT INTO `options` VALUES(118, 27, 'collect', 1, '');
INSERT INTO `options` VALUES(119, 27, 'run', 2, '');
INSERT INTO `options` VALUES(120, 27, 'push', 3, '');
INSERT INTO `options` VALUES(121, 27, 'pull', 4, '');
INSERT INTO `options` VALUES(122, 28, 'heavy', 1, '');
INSERT INTO `options` VALUES(123, 28, 'magnetic', 2, '');
INSERT INTO `options` VALUES(124, 28, 'rough', 3, '');
INSERT INTO `options` VALUES(125, 28, 'rocky', 4, '');
INSERT INTO `options` VALUES(126, 29, 'atoms', 1, '');
INSERT INTO `options` VALUES(127, 29, 'magnets', 2, '');
INSERT INTO `options` VALUES(128, 29, 'fingers', 3, '');
INSERT INTO `options` VALUES(129, 29, 'arrows', 4, '');
INSERT INTO `options` VALUES(130, 30, 'atom', 1, '');
INSERT INTO `options` VALUES(131, 30, 'electron', 2, '');
INSERT INTO `options` VALUES(132, 30, 'proton', 3, '');
INSERT INTO `options` VALUES(133, 30, 'magnet', 4, '');
INSERT INTO `options` VALUES(134, 31, 'weaker', 1, '');
INSERT INTO `options` VALUES(135, 31, 'electric', 2, '');
INSERT INTO `options` VALUES(136, 31, 'green', 3, '');
INSERT INTO `options` VALUES(137, 31, 'stronger', 4, '');
INSERT INTO `options` VALUES(138, 32, 'repel', 1, '');
INSERT INTO `options` VALUES(139, 32, 'attract', 2, '');
INSERT INTO `options` VALUES(140, 32, 'sing', 3, '');
INSERT INTO `options` VALUES(141, 32, 'oppose', 4, '');
INSERT INTO `options` VALUES(142, 33, 'carbon', 1, '');
INSERT INTO `options` VALUES(143, 33, 'aluminium', 2, '');
INSERT INTO `options` VALUES(144, 33, 'oxygen', 3, '');
INSERT INTO `options` VALUES(145, 33, 'iron', 4, '');
INSERT INTO `options` VALUES(146, 34, 'Electromagnets', 1, '');
INSERT INTO `options` VALUES(147, 34, 'Magnets', 2, '');
INSERT INTO `options` VALUES(148, 34, 'Domains', 3, '');
INSERT INTO `options` VALUES(149, 34, 'Electrochemical', 4, '');
INSERT INTO `options` VALUES(150, 35, 'light', 1, '');
INSERT INTO `options` VALUES(151, 35, 'television', 2, '');
INSERT INTO `options` VALUES(152, 35, 'radio', 3, '');
INSERT INTO `options` VALUES(153, 35, 'electricity', 4, '');
INSERT INTO `options` VALUES(154, 36, 'magnetic', 1, '');
INSERT INTO `options` VALUES(155, 36, 'magical', 2, '');
INSERT INTO `options` VALUES(156, 36, 'physical', 3, '');
INSERT INTO `options` VALUES(157, 36, 'chemical', 4, '');
INSERT INTO `options` VALUES(158, 37, 'easier', 1, '');
INSERT INTO `options` VALUES(159, 37, 'long', 2, '');
INSERT INTO `options` VALUES(160, 37, 'miserable', 3, '');
INSERT INTO `options` VALUES(161, 37, 'hard', 4, '');
INSERT INTO `options` VALUES(162, 38, 'bad', 1, '');
INSERT INTO `options` VALUES(163, 38, 'smooth', 2, '');
INSERT INTO `options` VALUES(164, 38, 'good', 3, '');
INSERT INTO `options` VALUES(165, 38, 'aggressive', 4, '');
INSERT INTO `options` VALUES(166, 39, 'long', 1, '');
INSERT INTO `options` VALUES(167, 39, 'light', 2, '');
INSERT INTO `options` VALUES(168, 39, 'strict', 3, '');
INSERT INTO `options` VALUES(169, 39, 'unusual', 4, '');
INSERT INTO `options` VALUES(170, 40, 'destroy', 1, '');
INSERT INTO `options` VALUES(171, 40, 'inadequate', 2, '');
INSERT INTO `options` VALUES(172, 40, 'harmonise', 3, '');
INSERT INTO `options` VALUES(173, 40, 'lighten', 4, '');
INSERT INTO `options` VALUES(174, 41, 'truculent', 1, '');
INSERT INTO `options` VALUES(175, 41, 'obstreperous', 2, '');
INSERT INTO `options` VALUES(176, 41, 'morose', 3, '');
INSERT INTO `options` VALUES(177, 41, 'discreet', 4, '');
INSERT INTO `options` VALUES(178, 42, 'dilettante', 1, '');
INSERT INTO `options` VALUES(179, 42, 'supernumerary', 2, '');
INSERT INTO `options` VALUES(180, 42, 'chimera', 3, '');
INSERT INTO `options` VALUES(181, 42, 'catalyst', 4, '');
INSERT INTO `options` VALUES(182, 43, 'mortifying', 1, '');
INSERT INTO `options` VALUES(183, 43, 'appeasing', 2, '');
INSERT INTO `options` VALUES(184, 43, 'curtailing', 3, '');
INSERT INTO `options` VALUES(185, 43, 'instigating', 4, '');
INSERT INTO `options` VALUES(186, 44, 'exonerated', 1, '');
INSERT INTO `options` VALUES(187, 44, 'expatriated', 2, '');
INSERT INTO `options` VALUES(188, 44, 'augmented', 3, '');
INSERT INTO `options` VALUES(189, 44, 'subjugated', 4, '');
INSERT INTO `options` VALUES(190, 45, '', 1, '');
INSERT INTO `options` VALUES(191, 45, '', 2, '');
INSERT INTO `options` VALUES(192, 45, '', 3, '');
INSERT INTO `options` VALUES(193, 45, '', 4, '');
INSERT INTO `options` VALUES(194, 11, 'à¥‡à¤•à¤¿à¤¹à¤•à¤¿ à¥‡à¤•à¤¹', 1, '');
INSERT INTO `options` VALUES(195, 11, 'à¥‡à¤•à¤¹à¤•à¤¿ à¤•à¥‡à¤¿à¤¹', 2, '');
INSERT INTO `options` VALUES(196, 11, 'à¥‡à¤•à¤¹à¤•à¥‡à¤¿à¤¹ à¤•à¤¿à¤¹ à¥‡à¤•à¤¿à¤¹à¤•', 3, '');
INSERT INTO `options` VALUES(197, 11, 'à¤•à¥‡à¤¹à¥‡à¤• à¤¹à¥‡à¤•à¤¹', 4, '');
INSERT INTO `options` VALUES(198, 12, 'à¥‡à¤‚à¤¿à¥‡à¤•à¤¿', 1, '');
INSERT INTO `options` VALUES(199, 12, 'à¥‡à¤‚à¤¿à¥‡à¤•à¤¿', 2, '');
INSERT INTO `options` VALUES(200, 12, 'à¤‚à¥‡à¤¿à¥‡à¤•à¤¿', 3, '');
INSERT INTO `options` VALUES(201, 12, 'à¥‡à¤‚à¤¿à¥‡à¤•à¤¿', 4, '');
INSERT INTO `options` VALUES(202, 13, 'à¥‡à¤‚à¤¿à¥‡à¤•à¤¿', 1, '');
INSERT INTO `options` VALUES(203, 13, 'à¥‡à¤‚à¤¿à¥‡à¤•à¤¿', 2, '');
INSERT INTO `options` VALUES(204, 13, 'à¤‚à¥‡à¤¿à¥‡à¤•à¤¿', 3, '');
INSERT INTO `options` VALUES(205, 13, 'à¥‡à¤‚à¤¿à¥‡à¤•à¤¿', 4, '');
INSERT INTO `options` VALUES(206, 14, 'à¥‡à¤‚à¤¿à¥‡à¤•à¤¿', 1, '');
INSERT INTO `options` VALUES(207, 14, 'à¥‡à¤‚à¤¿à¥‡à¤•à¤¿', 2, '');
INSERT INTO `options` VALUES(208, 14, 'à¤‚à¥‡à¤¿à¥‡à¤•à¤¿', 3, '');
INSERT INTO `options` VALUES(209, 14, 'à¥‡à¤‚à¤¿à¥‡à¤•à¤¿', 4, '');
INSERT INTO `options` VALUES(210, 15, 'à¥‡à¤‚à¤¿à¥‡à¤•à¤¿', 1, '');
INSERT INTO `options` VALUES(211, 15, 'à¥‡à¤‚à¤¿à¥‡à¤•à¤¿', 2, '');
INSERT INTO `options` VALUES(212, 15, 'à¤‚à¥‡à¤¿à¥‡à¤•à¤¿', 3, '');
INSERT INTO `options` VALUES(213, 15, 'à¥‡à¤‚à¤¿à¥‡à¤•à¤¿', 4, '');

-- --------------------------------------------------------

--
-- Table structure for table `pretext`
--

CREATE TABLE `pretext` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `image` text NOT NULL,
  `ispost` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `pretext`
--

INSERT INTO `pretext` VALUES(1, 'The Joint Parliamentary Committee reviewing the proposed land acquisition law has asked for suggestions from the public. I suggest that the lawâ€™s thrust must shift from compulsory acquisition to leasing. This will benefit all concerned â€” farmers, governments and project authorities.\r\nYet for linear infrastructure projects like roads, railways, canals and pipelines, compulsion may be justified to ensure contiguous land availability for the provision of public goods. Industries, however, should be asked to buy land from willing sellers.\r\nFarmers oppose land acquisition because it violates their property rights, and often yields sub-market prices. Land is in theory acquired above the going market price. But the market price itself depends on whether it is classified as agricultural or industrial. Just converting the classification from agricultural to industrial can increase the price of land five-fold. Thus farmers whose land is just outside the acquired zone gain hugely, but those in the acquired zone lose out.\r\nHistorically, land acquisition has been a terrible deal for farmers. Often state governments have acquired land for a long and then sold it to industries at prices ten or even fifty times higher. Many states have offered free or ultra-cheap land to attract industries and jobs. Such competition between states is common place in most countries, and can be healthy overall for the economy. But the cost should not fall disproportionately on farmers losing their land.\r\nMany farmers complain that, after acquisition, they have no other occupation to shift to. Some small farmers go on a spending spree with compensation money, and after a few years have nothing left. To overcome this, some states have proposed an annuity model: a down payment plus monthly payment.\r\nThe 2013 land acquisition law aimed to remove the worst features of compulsion. But it had so much red tape that all land acquisition â€” and hence all new infrastructure â€” came to a complete halt. States of all political hues said they had found the new law virtually unimplementable.\r\nThe best way forward is for state governments to simply lease land from farmers, not acquire it. This can take the form of 33-year, 50-year or 99-year leases, with a down payment, monthly rent, and renegotiation at the end of the lease period. This improves on the annuity model: the farmer gets similar benefits but remains the owner, with the added right of renegotiation.\r\nLand ownership is a big status issue in villages. A landless person loses status, and this carries not just humiliation but other social costs, like the inability to attract desirable grooms for daughters. But landowners who lease out land have a high status: they are landlords earning rents. Many rural grandees are absentee landowners with tenants.\r\nIf land is compulsorily leased and not acquired, the farmer in question becomes the landlord of the government agency, or Tata, or Birla, or whoever runs the new project. Losing your land to Tata or Birla is humiliating exploitation. But gaining Tata or Birla as your tenant at a high rent gives you social status.\r\nRight now, politicians have created a situation where farmers view industry as an enemy. This is terrible. India has just 160 million hectares of cultivated land for a rural population of over 800 million, or just one-fifth of a hectare per capita. This is a recipe for endless poverty. Millions of farmers must be enabled to move out of agriculture into industry and services. Farmers should see industrialists as allies and potential saviours, not foes.\r\nYet compulsory land acquisition makes farmers view industrialists as foes. To end this, farmers must have a stake in industry too. Some industrialists have tried offering shares in their companies to farmers, but share values are notoriously volatile and uncertain. Besides, industries can go bankrupt, and not pay their rents.\r\nThe safest solution is for state governments, which cannot go bust because of their tax powers, to lease the land and sub-lease it to industrialists where required. The states must be responsible for all payments to farmers. Farmer preferring to sell outright should have that option too. Part of the developed land should be returned to farmers as part of the compensation package. \r\nLeasing will give farmers a stake in incoming industries. These will no longer be seen as intruders or expropriators but as tenants paying vastly higher rents than imaginable earlier. Industries will create new opportunities to supply goods and services, including domestic services. It will be a win-win-situation.\r\nWith such an approach, no social impact reports, rehab schemes or majority votes are needed, since farmers are not actually losing land. This will speed up projects amicably, ensure rapid economic growth, and create millions of new jobs. It will make farmers partners in industrialization, not victims.\r\n', '', 0);
INSERT INTO `pretext` VALUES(2, '\r\n', '', 0);
INSERT INTO `pretext` VALUES(3, 'Direction(Q.1 - 5): Rearrange the following sentences (A),(B),(C),(D) and (E) to make meaningful paragraph and answer the question that follows:\r\nA.	Some rely on personal transformation; others rely on small collectives\r\nB.	A reform movement is a kind of social movement that aims to make gradual change, or change in certain aspects of society, rather than rapid or fundamental changes.\r\nC.	Reformists'' ideas are often grounded in liberalism, although they may be rooted in socialist or religious concepts. \r\nD.	The greatest success of the Reformers was the Reform Act 1832, which provided the rising middle classes with more political power in urban areas\r\nE.	A reform movement is distinguished from more radical social movements such as revolutionary movements.\r\n', '', 0);
INSERT INTO `pretext` VALUES(4, 'Direction: Rearrange the following sentences (A),(B),(C),(D) and (E) to make meaningful paragraph and answer the question that follows:\r\nA.	Some rely on personal transformation; others rely on small collectives\r\nB.	A reform movement is a kind of social movement that aims to make gradual change, or change in certain aspects of society, rather than rapid or fundamental changes.\r\nC.	Reformists'' ideas are often grounded in liberalism, although they may be rooted in socialist or religious concepts. \r\nD.	The greatest success of the Reformers was the Reform Act 1832, which provided the rising middle classes with more political power in urban areas\r\nE.	A reform movement is distinguished from more radical social movements such as revolutionary movements.\r\n\r\n', '', 0);
INSERT INTO `pretext` VALUES(5, 'Directions : Read each sentence to find out whether there is any grammatical error in it. The error, if any, will be in one part of the sentence. The number of that part is the answer. If there is no error, the answer is 5), ie â€˜No errorâ€™. (Ignore the errors of punctuation, if any.)', '', 0);
INSERT INTO `pretext` VALUES(6, 'There are probably only two â€” make it three â€” readily available food products that cut through the various layers of our multidimensional society. Glucose biscuits. Maggi. The banana. And they are immensely popular for several important reasons that include affordability, acceptable taste, nutrition or calorific value, ease of use and ready availability\r\nSo, in a country where there are reports that 40% of all fruit and vegetables get destroyed before they reach a human mouth, where 21 million tonnes of wheat â€” equal to all the wheat that is produced in Australia â€” gets spoilt every year, where the bottom 5% of rural India gets less than 60% of their required 2,100 calories of energy, is the Maggi-is poison debate that is currently raging in the media and airwaves avoiding the real issue?\r\nMarketers tell us that the Indian consumer is very resistant to adopting new products, especially when it comes to food. Unlike in the US, where it is reported that almost all American families have a Kraft macaroni and cheese dinner at least once a week, as a nation, we resist eating things off a box or pouch.\r\nMaggi is, in fact, the only brand to have broken through this barrier. NestlÃ© apparently did not see Maggi instant noodles as a commercial success for over a decade after its launch.\r\nIt was a success because it ticked many boxes correctly. It was tasty, easy to make, very affordable, allowed you to add your own little garnishing touches and was readily available. Though its initial advertising focused on children with the â€˜Bhook lagi hai, Maâ€™ and â€˜Sirf Do Minitâ€™ story, the brand cut right through many layers of society making it a â€œPERENNIALâ€ favourite among students, bachelors and working couples.\r\nIf I were looking at the macroeconomic food challenges of this country, I would want to know how the Maggi story could be replicated with instant chapatis, dal-chawal, etc, thereby preventing valuable food from getting spoilt before reaching a hungry stomach.\r\nThis would probably call for some preservatives. Some additives. However, if the bigger cause of providing affordable nutrition to the middle and lower classes can be served with some not-so-harmful additions, so be it.\r\nAs we debate the ingredients in Maggi, do we have any idea of what our drinking water contains? Or what is dished out by the very tasty vada pav or chaat vendor? Who checks the ingredient levels in all those items we consume? If they contain dangerous levels of lead, who can we haul up?\r\nIt is amusing to read that celebrities are being hauled over the coals for endorsing Maggi. To start with, they were endorsing a product that was given a licence to be manufactured and marketed in the country by the government of India.\r\nSo if they are being blamed, what next? The shop that sold it? The television channel that carried the advertisement?\r\nThere is a textbook case on how a brand should handle a crisis worse than this: Johnson & Johnson Tylenol-tampering story that happened in Chicago in 1982. A mentally challenged person decided to walk into some random drug stores, open up bottles of Tylenol and put a Tylenols laced with potassium cyanide. On September 29, 1982, the first death was reported, followed by a few more in the same area.\r\nThe company knew that the acetaminophen, or paracetamol, tablets could not cause death. But it did not know what could be the source. So, Jim Burke, the then-CEO of Johnson & Johnson, decided to recall all packs of Tylenol to have them destroyed. The executive decision was taken on October 5, 1982, and the cost to the company was $100 million.\r\nThe brand advised consumers to return packs of Tylenol lying in their homes, stopped drug stores from selling the brand and Tylenol went off the shelves for several months, losing valuable business.\r\nHowever, Burkeâ€™s decision made him possibly one of the most respected CEOs of all time.\r\nThe story has an interesting ending after all. Tylenol brandâ€™s packaging was made tamper-proof and when it re-entered the market, it went on to get back its entire market share and some more.\r\nIn India, too, we have seen brands facing attack from many quarters and there are case studies of Cadbury Dairy Milk, Pepsi, Coke and UTI 64. But the situation is a little different now and one doesnâ€™t know which tweet to believe any more.\r\n', '', 0);
INSERT INTO `pretext` VALUES(7, 'Directions: In the following passage there are blanks A to J. These alphabets are given below the passage and against each, four words are suggested, one of which fits the blank appropriately. Find out the appropriate word in each case. \r\nMagnets are materials that attract pieces of iron or steel. In ancient times, people first discovered magnetism when they found some naturally ____(A)_____ pieces of rock in the earth. They called these rocks lodestone. Loadstones have a lot of iron in them, but we now know that other materials can be magnetized as well. Nickel, cobalt, certain types of ceramics and certain blends of metals can also make good magnets.\r\nIf you could look at a magnet at the atomic level, you would notice that the magnet was divided into a number of smaller regions called domains. All of the ____(B)_____ in a domain point in the same direction and, since each atom acts like a little ___(C)______, all of their little magnetic fields add together to make a larger, ____(D)_____ field. A magnet can be weakened if some of its atoms are thrown out of alignment. Hitting or heating a magnet is usually enough to scramble some of its atoms.\r\nMagnets have north and south poles. The north pole of one magnet will repel, or push away, the north pole of another magnet, and the south pole of one magnet will repel the south pole of another magnet. But, if you put the north pole of one magnet near the south pole of another magnet, you''ll feel an attractive force. You may have heard the saying "opposites ____(E)_____." This is just one of the rules of nature that scientists have discovered.\r\nEveryone knows that magnets stick to refrigerators, but did you know that magnets are used in all sorts of things? Most of the magnets we are used to seeing are made from metals rich in ___(F)______. The kind we use to hold our school work to the refrigerator are called permanent magnets. They are magnets today and they''ll be magnets tomorrow. They just hang there and continue to be magnets without us doing anything to them. Can you think of anywhere else you might find permanent magnets in your house? Did you know there''s a magnet in the seal on the inside of your refrigerator door? You don''t use that one to hold your school work, but it does hold the door closed when you''re not looking for a snack or a cold drink. Some cabinet doors have magnetic latches too. Can you think of any other places where magnets have practical uses?\r\nPermanent magnets are one kind of magnet, but there''s another kind of magnet called an electromagnet.____(G)_____ are made from metal and electricity! When the ____(H)_____ is on, you have a magnet, but turn the power off, and you just have a hunk of metal and some wire. Unlike permanent magnets, the strength of an electromagnet is easy to change. One way to do this is to change the amount of current used. Another way is to change the amount of wire you have wrapped around the metal core. You see, when you wind wire in coils around a piece of metal that has a lot of iron in it, and then you run electricity through the wire, it creates a magnetic field. More coils of wire or more electric current creates a stronger magnetic field. This magnetic field causes the atoms in the core to align, giving the metal ____(I)_____ properties.\r\nElectromagnets are used in many devices. Think of things that use power and have moving parts. Chances are, an electromagnet is causing the motion! Power windows in a car, automatic doors at the grocery store, and the little motor in a CD player that makes the CD spin so you can listen to your favorite music all contain electromagnets! Electromagnets really make our lives ____(J)_____, and more fun, too!\r\n', '', 0);
INSERT INTO `pretext` VALUES(8, 'E.	Pick out opposite meaning', '', 0);
INSERT INTO `pretext` VALUES(9, 'After each sentence, select the word which best fills in the blank left in that sentence.', '', 0);
INSERT INTO `pretext` VALUES(10, '', '', 0);
INSERT INTO `pretext` VALUES(11, '', '', 0);
INSERT INTO `pretext` VALUES(12, '', '', 0);
INSERT INTO `pretext` VALUES(13, '', '', 0);
INSERT INTO `pretext` VALUES(14, 'à¤‚à¥‡à¤¿à¤•', '', 0);
INSERT INTO `pretext` VALUES(15, 'à¤‚à¥‡à¤¿à¤•', '', 0);
INSERT INTO `pretext` VALUES(16, 'à¤‚à¥‡à¤¿à¤•', '', 0);
INSERT INTO `pretext` VALUES(17, 'à¤‚à¥‡à¤¿à¤•', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `qrecord`
--

CREATE TABLE `qrecord` (
  `QuesId` int(11) NOT NULL AUTO_INCREMENT,
  `QuesCatId` int(11) NOT NULL,
  `Question` text COLLATE utf8_unicode_ci NOT NULL,
  `CorrectOption` int(11) NOT NULL,
  `Hint` text COLLATE utf8_unicode_ci,
  `Solution` text COLLATE utf8_unicode_ci,
  `solutionImage` text COLLATE utf8_unicode_ci,
  `LangId` text COLLATE utf8_unicode_ci NOT NULL,
  `IsFav` int(11) DEFAULT NULL,
  `image` text COLLATE utf8_unicode_ci,
  `bankName` text COLLATE utf8_unicode_ci,
  `Year` text COLLATE utf8_unicode_ci,
  `reference` text COLLATE utf8_unicode_ci,
  `userid` int(11) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `rate` float NOT NULL,
  `level` int(11) NOT NULL,
  `pretext_id` int(11) NOT NULL,
  PRIMARY KEY (`QuesId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=46 ;

--
-- Dumping data for table `qrecord`
--

INSERT INTO `qrecord` VALUES(1, 19, 'Q. 1 Why Farmers oppose land acquisition ?', 5, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-10 17:19:16', 0, 2, 1);
INSERT INTO `qrecord` VALUES(2, 19, 'Q. 6 To overcome the of land acquisition Law, what some states have proposed?', 2, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-10 17:21:06', 0, 2, 1);
INSERT INTO `qrecord` VALUES(3, 19, 'Q. 3 Market price depends on.....', 4, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-10 17:24:26', 0, 2, 1);
INSERT INTO `qrecord` VALUES(5, 19, 'Q. 4  How much area of India is being cultivated?\r\nA.	200 million hectares\r\nB.	800 million hectares\r\nC.	160 million hectares\r\nD.	100 million hectares', 2, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-10 17:29:20', 0, 2, 1);
INSERT INTO `qrecord` VALUES(6, 19, 'DirectionsË In the following questions, choose the word/group of words which is MOST SIMILAR in meaning to the word/group of words printed in bold as used in the passage.\r\nFOE \r\nA.	\r\nB.	\r\nC.	assistant\r\nD.	friend', 2, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-11 11:18:31', 0, 1, 2);
INSERT INTO `qrecord` VALUES(7, 19, 'Directions: In the following questions, choose the word/group of words which is MOST SIMILAR in meaning to the word/group of words printed in bold as used in the passage.\r\nSPREE', 4, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-11 11:52:54', 0, 1, 1);
INSERT INTO `qrecord` VALUES(9, 24, 'Which of the following sentences should be the SECOND after rearrangement?', 5, NULL, 'BECAD', '', 'en', NULL, '', '', '', '', 3, '2015-06-11 12:15:56', 0, 1, 4);
INSERT INTO `qrecord` VALUES(10, 24, 'Which of the following sentences should be the FIFTH after rearrangement?', 4, NULL, 'BECAD', '', 'en', NULL, '', '', '', '', 3, '2015-06-11 12:17:05', 0, 1, 4);
INSERT INTO `qrecord` VALUES(11, 24, 'Which of the following sentences should be the FIRST after rearrangement?', 2, NULL, 'BECAD', '', 'en', NULL, '', '', '', '', 3, '2015-06-11 12:18:08', 0, 1, 4);
INSERT INTO `qrecord` VALUES(12, 24, 'Which of the following sentences should be the FOURTH after rearrangement?', 1, NULL, 'BECAD', '', 'en', NULL, '', '', '', '', 3, '2015-06-11 12:19:26', 0, 1, 0);
INSERT INTO `qrecord` VALUES(13, 24, 'Which of the following sentences should be the THIRD after rearrangement?', 3, NULL, 'BECAD', '', 'en', NULL, '', '', '', '', 3, '2015-06-11 12:20:15', 0, 1, 0);
INSERT INTO `qrecord` VALUES(14, 21, 'Worldwide, high-level waste 1) /is currently stored above ground 2)/ and no government had 3)/ a clear policy on its eventual disposal 4)/ No Error 5).', 3, NULL, 'and no government had', '', 'en', NULL, '', '', '', '', 3, '2015-06-11 12:30:04', 0, 1, 5);
INSERT INTO `qrecord` VALUES(15, 21, 'since there is no conclusive evidence for any 1)/major climatic change in historic times 2)/ to explain this deterioration, we must conclude the eroding of the total environment 3)/ has been due primarily to thoughtless destruction of the vegetative cover 4)/ No Error 5)', 3, NULL, 'to explain this deterioration, we must conclude that the eroding of the total environment', '', 'en', NULL, '', '', '', '', 3, '2015-06-11 13:00:51', 0, 1, 5);
INSERT INTO `qrecord` VALUES(16, 21, 'Q.3 All living things must drink, and they require 1)/ a fresh supply of water often. A person 2)/ can go without food for many days 3)/ but he or she cannot go for long without water 4)/ No Error 5)', 5, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-11 13:01:22', 0, 1, 0);
INSERT INTO `qrecord` VALUES(17, 21, 'Q.4 It is a man who lived 1)/ before the time of Christopher Columbus 2)/ that was the world''s 3)/ first great traveller 4)/ No Error 5)', 1, NULL, 'It was a man who lived', '', 'en', NULL, '', '', '', '', 3, '2015-06-11 13:01:59', 0, 1, 0);
INSERT INTO `qrecord` VALUES(18, 21, 'Q. 5 The Spaniards found these Indians living 1)/ in apartment houses, some of them at 2)/ the side of a cliff in order that they 3)/ could be reached only by ladders 4)/ No Error 5)\r\nAns: (2)\r\napartment houses, some of them on', 2, NULL, 'apartment houses, some of them on', '', 'en', NULL, '', '', '', '', 3, '2015-06-11 13:03:08', 0, 1, 5);
INSERT INTO `qrecord` VALUES(21, 19, 'Why readily available food products  are immensely popular in our society ?\r\na.	\r\nb.	affordability, acceptable taste, nutrition or calorific value, ease of use and ready availability\r\nc.	acceptable taste, nutrition or calorific value, emphasising freshness & healthy\r\nd.	emphasising freshness, healthy, attractive packing and ready availability\r\nans: b', 2, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-13 21:57:15', 0, 1, 6);
INSERT INTO `qrecord` VALUES(22, 19, 'What is difference between Indian Consumer and US Consumer about new product (packed food) respectively?', 1, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-13 21:59:12', 0, 1, 6);
INSERT INTO `qrecord` VALUES(23, 6, 'As per the passage the most readily available food products are?', 4, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-13 22:27:53', 0, 1, 6);
INSERT INTO `qrecord` VALUES(24, 19, 'what % of fruits and vegetables get destroyed?', 3, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-14 17:08:21', 0, 1, 6);
INSERT INTO `qrecord` VALUES(25, 19, 'when Johnson and Johnson Tylenol story happened?', 3, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-14 17:09:17', 0, 1, 6);
INSERT INTO `qrecord` VALUES(26, 19, 'Directions: In the following questions, choose the word/group of words which is MOST SIMILAR in meaning to the word/group of words printed in Upper case with inverted comma  as used in the passage.\r\nPERENNIAL', 2, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-14 17:17:33', 0, 1, 6);
INSERT INTO `qrecord` VALUES(27, 19, 'Directions: In the following questions, choose the word/group of words which is MOST SIMILAR in meaning to the word/group of words written in upper case with inverted comma as used in the passage.\r\nHAULED', 4, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-14 17:24:27', 0, 1, 6);
INSERT INTO `qrecord` VALUES(28, 22, 'which word replace the alphabet A ?', 2, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-15 06:31:38', 0, 1, 7);
INSERT INTO `qrecord` VALUES(29, 22, 'which word replace the alphabet B?', 1, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-15 06:33:06', 0, 1, 7);
INSERT INTO `qrecord` VALUES(30, 22, 'which word replace the alphabet C ?', 4, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-15 06:36:19', 0, 1, 7);
INSERT INTO `qrecord` VALUES(31, 22, 'which word replace the alphabet D?', 4, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-15 06:51:49', 0, 1, 7);
INSERT INTO `qrecord` VALUES(32, 22, 'which word replace the alphabet E?', 2, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-15 06:53:16', 0, 1, 7);
INSERT INTO `qrecord` VALUES(33, 22, 'which word replace the alphabet F ?', 4, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-15 06:54:53', 0, 1, 7);
INSERT INTO `qrecord` VALUES(34, 22, 'which word replace the alphabet G ?\r\nA.	Electromagnets \r\nB.	Magnets\r\nC.	Domains\r\nD.	Electrochemical', 1, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-15 06:56:26', 0, 1, 7);
INSERT INTO `qrecord` VALUES(35, 22, 'which word replace the alphabet H?', 4, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-15 06:59:05', 0, 1, 7);
INSERT INTO `qrecord` VALUES(36, 22, 'which word replace the alphabet I ?', 1, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-15 07:00:23', 0, 1, 7);
INSERT INTO `qrecord` VALUES(37, 22, 'which word replace the alphabet J?', 1, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-15 07:01:41', 0, 1, 7);
INSERT INTO `qrecord` VALUES(38, 20, 'Working mothers who feel contrite about leaving their child.', 3, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-15 07:08:42', 0, 1, 8);
INSERT INTO `qrecord` VALUES(39, 20, 'he was often sharp and rather succinct with her.', 1, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-15 07:13:55', 0, 1, 8);
INSERT INTO `qrecord` VALUES(40, 20, 'regular socializing foster a good working team spirit.', 1, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-15 07:16:34', 0, 1, 8);
INSERT INTO `qrecord` VALUES(41, 22, 'The children were so ____________ that the teacher had to yell to be heard.', 2, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-15 07:30:23', 0, 1, 9);
INSERT INTO `qrecord` VALUES(42, 22, 'Roberto pretended to know a lot about the opera, but he was really just a ___________ .', 1, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-15 07:31:54', 0, 1, 9);
INSERT INTO `qrecord` VALUES(43, 22, 'The older child had a reputation for ________ trouble in high school, but he calmed down in college.', 4, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-15 07:33:18', 0, 1, 9);
INSERT INTO `qrecord` VALUES(44, 22, '10.  The jury ___________ the mayor of all wrongdoing.', 1, NULL, '', '', 'en', NULL, '', '', '', '', 3, '2015-06-15 07:34:28', 0, 1, 9);
INSERT INTO `qrecord` VALUES(45, 6, '', 2, NULL, '', '', 'hi', NULL, '', '', '', '', 3, '2015-06-20 17:12:40', 0, 1, 10);

-- --------------------------------------------------------

--
-- Table structure for table `qusappmapping`
--

CREATE TABLE `qusappmapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `QuesId` int(11) NOT NULL,
  `AppId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=68 ;

--
-- Dumping data for table `qusappmapping`
--

INSERT INTO `qusappmapping` VALUES(1, 2, 5);
INSERT INTO `qusappmapping` VALUES(2, 3, 5);
INSERT INTO `qusappmapping` VALUES(3, 4, 5);
INSERT INTO `qusappmapping` VALUES(4, 5, 5);
INSERT INTO `qusappmapping` VALUES(5, 6, 5);
INSERT INTO `qusappmapping` VALUES(6, 7, 5);
INSERT INTO `qusappmapping` VALUES(7, 8, 5);
INSERT INTO `qusappmapping` VALUES(8, 0, 5);
INSERT INTO `qusappmapping` VALUES(9, 9, 5);
INSERT INTO `qusappmapping` VALUES(10, 10, 5);
INSERT INTO `qusappmapping` VALUES(11, 11, 5);
INSERT INTO `qusappmapping` VALUES(12, 1, 1);
INSERT INTO `qusappmapping` VALUES(13, 1, 1);
INSERT INTO `qusappmapping` VALUES(14, 2, 1);
INSERT INTO `qusappmapping` VALUES(15, 3, 1);
INSERT INTO `qusappmapping` VALUES(16, 4, 1);
INSERT INTO `qusappmapping` VALUES(17, 5, 1);
INSERT INTO `qusappmapping` VALUES(18, 6, 1);
INSERT INTO `qusappmapping` VALUES(19, 7, 1);
INSERT INTO `qusappmapping` VALUES(20, 8, 1);
INSERT INTO `qusappmapping` VALUES(21, 9, 1);
INSERT INTO `qusappmapping` VALUES(22, 10, 1);
INSERT INTO `qusappmapping` VALUES(23, 11, 1);
INSERT INTO `qusappmapping` VALUES(24, 12, 1);
INSERT INTO `qusappmapping` VALUES(25, 13, 1);
INSERT INTO `qusappmapping` VALUES(26, 14, 1);
INSERT INTO `qusappmapping` VALUES(27, 15, 1);
INSERT INTO `qusappmapping` VALUES(28, 16, 1);
INSERT INTO `qusappmapping` VALUES(29, 17, 1);
INSERT INTO `qusappmapping` VALUES(30, 18, 1);
INSERT INTO `qusappmapping` VALUES(31, 19, 1);
INSERT INTO `qusappmapping` VALUES(32, 20, 1);
INSERT INTO `qusappmapping` VALUES(33, 21, 1);
INSERT INTO `qusappmapping` VALUES(34, 22, 1);
INSERT INTO `qusappmapping` VALUES(35, 23, 1);
INSERT INTO `qusappmapping` VALUES(36, 24, 1);
INSERT INTO `qusappmapping` VALUES(37, 25, 1);
INSERT INTO `qusappmapping` VALUES(38, 26, 1);
INSERT INTO `qusappmapping` VALUES(39, 27, 1);
INSERT INTO `qusappmapping` VALUES(40, 28, 1);
INSERT INTO `qusappmapping` VALUES(41, 29, 1);
INSERT INTO `qusappmapping` VALUES(42, 30, 1);
INSERT INTO `qusappmapping` VALUES(43, 31, 1);
INSERT INTO `qusappmapping` VALUES(44, 32, 1);
INSERT INTO `qusappmapping` VALUES(45, 33, 1);
INSERT INTO `qusappmapping` VALUES(46, 34, 1);
INSERT INTO `qusappmapping` VALUES(47, 35, 1);
INSERT INTO `qusappmapping` VALUES(48, 36, 1);
INSERT INTO `qusappmapping` VALUES(49, 37, 1);
INSERT INTO `qusappmapping` VALUES(50, 38, 1);
INSERT INTO `qusappmapping` VALUES(51, 39, 1);
INSERT INTO `qusappmapping` VALUES(52, 40, 1);
INSERT INTO `qusappmapping` VALUES(53, 41, 1);
INSERT INTO `qusappmapping` VALUES(54, 42, 1);
INSERT INTO `qusappmapping` VALUES(55, 43, 1);
INSERT INTO `qusappmapping` VALUES(56, 44, 1);
INSERT INTO `qusappmapping` VALUES(57, 45, 1);
INSERT INTO `qusappmapping` VALUES(58, 11, 1);
INSERT INTO `qusappmapping` VALUES(59, 12, 1);
INSERT INTO `qusappmapping` VALUES(60, 13, 1);
INSERT INTO `qusappmapping` VALUES(61, 14, 1);
INSERT INTO `qusappmapping` VALUES(62, 15, 1);
INSERT INTO `qusappmapping` VALUES(63, 0, 1);
INSERT INTO `qusappmapping` VALUES(64, 0, 1);
INSERT INTO `qusappmapping` VALUES(65, 0, 1);
INSERT INTO `qusappmapping` VALUES(66, 16, 1);
INSERT INTO `qusappmapping` VALUES(67, 17, 1);
